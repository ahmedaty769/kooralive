<?php
/**
 * Widgets Helper Class
 * VnxSport  :: Widget.
 *
 * @since   0.4.3 (2018-02-18)
 * @package Vnx_Sport_Plugin
 *
 * Inspired by - https://carlalexander.ca/polymorphism-wordpress-abstract-classes/
 *
 * Based on:
 * - https://github.com/woocommerce/woocommerce/blob/master/includes/abstracts/abstract-wc-widget.php
 * - WordPress Widget Boilerplate - https://github.com/tommcfarlin/WordPress-Widget-Boilerplate
 * - WordPress Widgets Helper Class - https://github.com/alessandrotesoro/wp-widgets-helper by Alessandro Tesoro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * VnxSport  :: Widget class.
 *
 * @since 0.4.3 (2018-02-18)
 * @extends WP_Widget
 */
abstract class VnxSport_Widget extends WP_Widget {

	/**
	 * Constructor.
	 *
	 * @since  0.4.3
	 */
	public function __construct() {

		parent::__construct(
			$this->get_widget_slug(),
			$this->get_widget_name(),
			[
				'classname'                   => $this->get_widget_css_classes(),
				'description'                 => $this->get_widget_description(),
				'customize_selective_refresh' => true, // TODO test "true"
			]
		);

	
	}

	/**
	 * Get widget name.
	 *
	 * @return string
	 * @since  0.4.3
	 */
	abstract protected function get_widget_name();

	/**
	 * Get widget description.
	 *
	 * @return string
	 * @since  0.4.3
	 */
	abstract protected function get_widget_description();

	/**
	 * Get widget slug.
	 *
	 * @return string
	 * @since  0.4.3
	 */
	abstract protected function get_widget_slug();

	/**
	 * Get widget CSS classes.
	 *
	 * @return string
	 * @since  0.4.3
	 */
	abstract protected function get_widget_css_classes();

	/**
	 * Get widget fields.
	 *
	 * @return array
	 * @since  0.4.3
	 */
	abstract protected function get_widget_fields();

	/**
	 * Flush widget cache.
	 *
	 * @since  0.4.3
	 */
	public function flush_widget_cache() {
		wp_cache_delete( $this->get_widget_slug(), 'widget' );
	}

	/**
	 * Generates the administration form for the widget.
	 *
	 * @param array instance The array of keys and values for the widget.
	 *
	 * @since  0.4.3
	 */
	public function form( $instance ) {

		$widget_fields = $this->get_widget_fields();

		if ( !empty( $widget_fields ) || is_array( $widget_fields ) ) {



			$class = ( $this->get_widget_css_classes() ) ? ' '. $this->get_widget_css_classes() : '';
	
			echo '<div class=" aspwp-widgets aspwp-fields'. esc_attr( $class ) .'">';
	
			foreach ( $widget_fields as $field ) {
	
				$field_unique = '';
				if ( ! empty( $field['id'] ) ) {
					$field_unique = 'widget-' . $this->get_widget_slug() . '[' . $this->number . ']';
				}
	
				$value = isset( $instance[ $field['id'] ] ) ? $instance[ $field['id'] ] : $field['default'];

				VnxSport_Admin::field( $field, $value, $field_unique );
	
			}
	
			echo '</div>';
	
		}


	}

	/**
	 * Front-end display of widget.
	 *
	 * @param  array $args     The widget arguments set up when a sidebar is registered.
	 * @param  array $instance The widget settings as set by user.
	 *
	 * @since  0.4.3 (2018-02-18)
	 */
	public function widget( $args, $instance ) {

		$atts = array_merge(
			$instance,
			[
				'before_widget' => $args['before_widget'],
				'after_widget'  => $args['after_widget'],
				'before_title'  => $args['before_title'],
				'after_title'   => $args['after_title'],
			]
		);

		// Display the widget.
		echo $this->get_widget( $atts ); // WPCS XSS OK.
	}

	/**
	 * Return the widget output
	 *
	 * @param  array $atts Array of widget attributes/args.
	 *
	 * @return string      Widget output
	 * @since  0.4.3 (2018-02-18)
	 */
	public function get_widget( $atts ) {

		// Prepare widget name
		$widget_name = str_replace( 'aspwp-widget-', '', $this->get_widget_slug() );

		return Vnx_Sport_Plugin()->template->widget_loader( $widget_name, $atts );
	}

	/**
	 * Update form values as they are saved.
	 *
	 * @param  array $new_instance New settings for this instance as input by the user.
	 * @param  array $old_instance Old settings for this instance.
	 *
	 * @return array Settings to save or bool false to cancel saving.
	 * @since  0.4.3 (2018-02-18)
	 */
	public function update( $new_instance, $old_instance ) {

		// Previously saved values.
		$widget_fields = $this->get_widget_fields();

		if ( empty( $widget_fields ) ) {
			return $old_instance;
		}

		// auto sanitize
		foreach ( $widget_fields as $field ) {
			if ( ! empty( $field['id'] ) && ( ! isset( $new_instance[$field['id']] ) || is_null( $new_instance[$field['id']] ) ) ) {
				$new_instance[$field['id']] = '';
			}
		}
		
		// Flush cache.
		//$this->flush_widget_cache();

		return $new_instance;

	}
}
