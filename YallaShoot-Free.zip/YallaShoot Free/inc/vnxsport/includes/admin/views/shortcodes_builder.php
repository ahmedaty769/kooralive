<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
	wp_die( esc_html__( 'You do not have sufficient permissions to access this page.') );
}

?>
<style>#shb-row{display:flex;flex-wrap:wrap}#shb-content{width:100%;background:#f0f0f1;padding-right:20px;padding-top:50px;padding-bottom:80px}#shb-content .aspwp-field{background:#fff}#shb-composed{background:#f0f0f1;padding:50px 20px 80px;overflow:hidden;width:45%;display:flex;flex-direction:column}.p-2.bg-white.border{    background: #fff;
    border: 1px solid #dee2e6!important;
    box-sizing: border-box;
    padding: 0.5rem;
    height: 100%;
    margin: 0;
    width: 100%;
    text-align: center;}#aspwp-shortcode-builder__copy{width:100%;height:30px}.aspwp-tok-table.aspwp-onload{display:flex;flex-wrap:wrap}#aspwp__copy{margin:15px 4px 4px;font-weight:700;color:#6c757d}.VnxSportFixture.aspwp_dark_style .title{color:#fff}.AspTopSliderMatch.aspwp_dark_style .AspMatchSlider,.AspTopSliderMatch.aspwp_dark_style .AspSliderInner{background:#19232d;border-color:rgba(0,0,0,0.29)}.AspTopSliderMatch.aspwp_dark_style .AspMatchItem,.AspTopSliderMatch.aspwp_dark_style  .gotoDay:not(.active){background:#202a34;color:#fff;border-color:rgba(255,255,255,0.03)!important}.AspTopSliderMatch.aspwp_dark_style .AspMatchItem .teamA span,.AspTopSliderMatch.aspwp_dark_style .AspMatchItem .teamB span,.AspTopSliderMatch.aspwp_dark_style .AspMatchItem .resultDiv .result{color:#fff}.AspTopSliderMatch.aspwp_dark_style .AspMatchItem:hover{background:#19232d}.VnxSportFixture.vnxsport_is_md .result{display:none}.VnxSportFixture.vnxsport_is_md .AF_Data .AF_EvTime{font-size:22px;letter-spacing:0;margin-bottom:3px}.VnxSportFixture.vnxsport_is_md .AF_Team .team{flex-direction:column;height:85px}.VnxSportFixture.vnxsport_is_md .AF_EvItem .AF_Team .AF_TeamLogo img{max-width:45px;max-height:45px}.VnxSportFixture.vnxsport_is_md .AF_TeamName{font-size:14px}.VnxSportFixture.vnxsport_is_md .AF_Title select{min-width:auto}.VnxSportFixture.vnxsport_is_md .AF_Title .title{font-size:16px}.VnxSportFixture.vnxsport_is_md .AF_Filters{margin:8px 0;padding:0 10px}.VnxSportFixture.vnxsport_is_md .AF_Filters .tablinks{height:38px;font-size:12px}.VnxSportFixture.vnxsport_is_md .AF_EvInfo span{font-size:10px}.VnxSportFixture.vnxsport_is_md .AF_EvInfo span .vnxicon{background-size:12px 12px!important;width:12px;height:12px}.VnxSportFixture.small .AF_EvStat .status .AF_StaText{padding:0 8px 2px;line-height:13px;font-size:10px}.VnxSportFixture.small .AF_Title{height:41px}.VnxSportFixture.small .AF_Title select{font-size:10px;height:17px!important;min-height:20px}.VnxSportFixture.small .match-data .asp-city{font-size:9px}.asp-font{font-family:"asp-font-kufi"!important}.VnxSportFixture.small .AF_Title .asp-title{margin:0!important;padding:0!important}</style>
   <link rel='stylesheet' id='VnxSport-css' href='<?php echo  VNXSPORT_URL;?>/public/css/VnxSport.css?ver=14.2' type='text/css' media='all' />
   <div class="aspe-admin-page-heading" style="text-align: center;">
      <h2><?php echo __('Shortcode Builder', VNXSPORT_TEXTDOMAIN);?></h2>
   </div>
   <div style="padding: 20px;text-align: center;">
      <select id="shortcode_bulder_type" data-aspwp-toggle=".aspwp-tok" class="aspwp-toggle-select" style="min-width: 300px;height: 40px;">
         <option value="table" selected="selected"><?php echo esc_html__('Match Center', VNXSPORT_TEXTDOMAIN);?></option>
         <option value="slider" class="aspwp-slider-hidden"><?php echo esc_html__('Matches Slider', VNXSPORT_TEXTDOMAIN);?></option>
      </select>
   </div>
   <div id="shb-row">
      <div id="shb-content">
         <div class="aspwp-onload" style="display: flex;flex-wrap: wrap;">
            <div class="aspwp-field aspwp-field-text aspwp-50 VnxDark aspwp-tok aspwp-tok-table">
               <div class="aspwp-title"><label><?php echo esc_html__('Title', VNXSPORT_TEXTDOMAIN);?></label></div>
               <div class="aspwp-fieldset"><input type="text" id="shortcode_title" value="<?php echo esc_html__('Matches Center', VNXSPORT_TEXTDOMAIN);?>" data-depend-id="title"></div>
               <div class="clear"></div>
            </div>
            <div class="aspwp-field aspwp-field-select aspwp-50 VnxDark aspwp-tok aspwp-tok-table">
               <div class="aspwp-title"><label><?php echo esc_html__('Tabs Type', VNXSPORT_TEXTDOMAIN);?></label></div>
               <div class="aspwp-fieldset">
                  <select id="shortcode_tabs_type" data-depend-id="tabs_type">
                     <option value="tabs"><?php echo esc_html__('tabs', VNXSPORT_TEXTDOMAIN);?></option>
                     <option value="links"><?php echo esc_html__('links', VNXSPORT_TEXTDOMAIN);?></option>
                  </select>
               </div>
               <div class="clear"></div>
            </div>
            <div class="aspwp-field aspwp-field-switcher aspwp-50 aspwp-tok aspwp-tok-table">
               <div class="aspwp-title"><label><?php echo esc_html__('show title', VNXSPORT_TEXTDOMAIN);?></label></div>
               <div class="aspwp-fieldset"><input id="has_title" class="vnxspw-switcher" checked="checked" type="checkbox" value="1"><label for="has_title" class="aspwp-switcher"><i></i></label></div>
               <div class="clear"></div>
            </div>

            <div class="aspwp-field aspwp-field-switcher aspwp-50 aspwp-tok aspwp-tok-table" id="small_style-field">
               <div class="aspwp-title"><label><?php echo esc_html__('Small', VNXSPORT_TEXTDOMAIN);?></label></div>
               <div class="aspwp-fieldset"><input id="small_style" class="vnxspw-switcher" type="checkbox" value="1"><label for="small_style" class="aspwp-switcher"><i></i></label></div>
               <div class="clear"></div>
            </div>

  

        


            <div class="aspwp-field aspwp-field-switcher aspwp-33">
               <div class="aspwp-title"><label><?php echo esc_html__('Yesterday Button', VNXSPORT_TEXTDOMAIN);?></label></div>
               <div class="aspwp-fieldset"><input id="yesterday" class="vnxspw-switcher" checked="checked" type="checkbox" value="1"><label for="yesterday" class="aspwp-switcher"><i></i></label></div>
               <div class="clear"></div>
            </div>
            <div class="aspwp-field aspwp-field-switcher aspwp-33">
               <div class="aspwp-title"><label><?php echo esc_html__('Today Button', VNXSPORT_TEXTDOMAIN);?></label></div>
               <div class="aspwp-fieldset"><input id="today" class="vnxspw-switcher" checked="checked" type="checkbox" value="1"><label for="today" class="aspwp-switcher"><i></i></label></div>
               <div class="clear"></div>
            </div>
            <div class="aspwp-field aspwp-field-switcher aspwp-33">
               <div class="aspwp-title"><label><?php echo esc_html__('Tomorrow Button', VNXSPORT_TEXTDOMAIN);?></label></div>
               <div class="aspwp-fieldset"><input id="tomorrow" class="vnxspw-switcher" checked="checked" type="checkbox" value="1"><label for="tomorrow" class="aspwp-switcher"><i></i></label></div>
               <div class="clear"></div>
            </div>

            
               <div class="aspwp-field aspwp-field-number aspwp-50 ftw-50">
                  <div class="aspwp-title"><label><?php echo esc_html__('Matches Limit (0 - for all)', VNXSPORT_TEXTDOMAIN);?></label></div>
                  <div class="aspwp-fieldset"><input type="text" id="matches_limit" value="" style="max-width: 25rem;"></div>
                  <div class="clear"></div>
               </div>

                  <div class="aspwp-field aspwp-field-select aspwp-50 ftw-50">
                     <div class="aspwp-title" ><label><?php echo esc_html__('Match Day', VNXSPORT_TEXTDOMAIN);?></label></div>
                     <div class="aspwp-fieldset" >
                        <select id="shortcode_mday" data-depend-id="mday">
                           <option value="yesterday"><?php echo esc_html__('Yesterday', VNXSPORT_TEXTDOMAIN);?></option>
                           <option value="today" selected='selected'><?php echo esc_html__('Today', VNXSPORT_TEXTDOMAIN);?></option>
                           <option value="tomorrow"><?php echo esc_html__('Tomorrow', VNXSPORT_TEXTDOMAIN);?></option>
                        </select>
                     </div>
                     <div class="clear"></div>
                  </div>
            <div class="aspwp-depend-hidden" data-controller="tabs_type" data-condition="==" data-value="links" style="width: 100%;display: flex;flex-wrap: wrap;">

               <div class="aspwp-field aspwp-field-text aspwp-33">
                  <div class="aspwp-title"><label><?php echo esc_html__('Yesterday url', VNXSPORT_TEXTDOMAIN);?></label></div>
                  <div class="aspwp-fieldset"><input type="text" dir="ltr" id="shortcode_ysurl" value="" data-depend-id="ysurl"></div>
                  <div class="clear"></div>
               </div>
               <div class="aspwp-field aspwp-field-text aspwp-33">
                  <div class="aspwp-title"><label><?php echo esc_html__('Today url', VNXSPORT_TEXTDOMAIN);?></label></div>
                  <div class="aspwp-fieldset"><input type="text" dir="ltr" id="shortcode_tdurl" value="" data-depend-id="tdurl"></div>
                  <div class="clear"></div>
               </div>
               <div class="aspwp-field aspwp-field-text aspwp-33">
                  <div class="aspwp-title"><label><?php echo esc_html__('Tommorow url', VNXSPORT_TEXTDOMAIN);?></label></div>
                  <div class="aspwp-fieldset"><input type="text" dir="ltr" id="shortcode_tmurl" value="" data-depend-id="tmurl"></div>
                  <div class="clear"></div>
               </div>
            </div>
         </div>
      </div>
      
               <textarea id="builder__composed" readonly="readonly" class="p-2 bg-white border mt-1" style="white-space: normal;direction: ltr;" onclick="this.select();" onfocus="this.select();">[VnxSportTable]</textarea>

   </div>

   