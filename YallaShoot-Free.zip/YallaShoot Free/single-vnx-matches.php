<?php
get_header();
?>

<div class="vnx-single">
  <?php while ( have_posts() ) : the_post(); ?>
    <section class="main-content clearfix">
      <div id="entry">

        <?php get_match_card_here( null, get_the_ID() ); ?>
        <article class="SINGLECard art" id="the-post">

    <header class="EntryHeader"><h1 class="EntryTitle"> <?php the_title(); ?></h1></header>

        <div class="content_entry ">
    
          <?php the_content(); ?>
        </div>

      </div>
          </article>
    </section>
  <?php endwhile; ?>
</div>
<?php
get_footer();