<?php
/**
 * The Template for displaying Match >> Line Ups Section.
 *
 * This template can be overridden by copying it to yourtheme/VnxSport/match/match-content.php.
 *
 * @var object $data - Object with args.
 *
 * @author        VNX Web <vnxweb.com>
 * @package       VnxSport/Templates
 * @since         0.0.1
 *
 * @version       0.14.14
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$data = (object) wp_parse_args(
	$data,
	[
		'post_content'       		=> '',
	]
);

echo '<div class="aspwp-section aspi_tabs_content" id="aspi_content">';

	echo  (AspwpOption('serv_pos') == '2') ? do_shortcode('[VnxSport_serv_conetnt]') : '';

	echo $data->post_content;

	echo  (AspwpOption('serv_pos') == '1') ? do_shortcode('[VnxSport_serv_conetnt]') : '';

echo '</div>';
