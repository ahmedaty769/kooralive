<?php
/**
 * VnxSport  :: Widget >> Matches.
 *
 * @since   0.4.3
 * @package VnxSport_Plugin
 */

/**
 * VnxSport  :: Matches
 *
 * @since 0.4.3
 */
class VnxSport_Widget_Slider extends VnxSport_Widget {

	/**
	 * Get unique identifier for this widget.
	 *
	 * @return string
	 */
	protected function get_widget_slug() {
		return 'aspwp_widget_slider';
	}

	/**
	 * Get widget name, displayed in Widgets dashboard.
	 *
	 * @return string
	 */
	protected function get_widget_name() {
		return esc_html__('VnxSport | Matches Slider', VNXSPORT_TEXTDOMAIN);
	}

	/**
	 * Get widget description.
	 *
	 * @return string
	 */
	protected function get_widget_description() {
		return esc_html__( 'Show Matches in Slider.', VNXSPORT_TEXTDOMAIN);
	}

	/**
	 * Get widget CSS classes.
	 *
	 * @return string
	 */
	protected function get_widget_css_classes() {
		return 'aspwp_widget_slider';
	}


	/**
	 * Front-end display of widget.
	 *
	 * @param  array $args     The widget arguments set up when a sidebar is registered.
	 * @param  array $instance The widget settings as set by user.
	 *
	 * @since  0.4.3 (2018-02-18)
	 */
	public function widget( $args, $instance ) {

		// Prevent errors with new params
$data = wp_parse_args(
	$instance,
	[
		'before_widget' => $args['before_widget'],
		'after_widget'  => $args['after_widget'],
		'yesterday'     => '1',
		'today'         => '1',
		'tomorrow'      => '1',
		'dark_style'    => '',
		'limit'         => '',
		'matches_day'   => 'today',
	]
);

			// Validate shortcode attr
		$data['matches_day']    	= in_array( $data['matches_day'] , ['yesterday', 'today', 'tomorrow' ] ) ?  $data['matches_day'] : '';
		$data['yesterday'] 			= empty($data['yesterday']) 	? '0' : '1';
		$data['today'] 				= empty($data['today']) 		? '0' : '1';
		$data['tomorrow'] 			= empty($data['tomorrow']) 		? '0' : '1';
		
		// Start an output buffer.
		//ob_start();
		// Start widget markup.
		echo $data['before_widget'];

		echo do_shortcode('[VnxSportSlider yesterday="'.$data['yesterday'].'" today="'.$data['today'].'" tomorrow="'.$data['tomorrow'].'" limit="'.$data['limit'].'" dark_style="'.$data['dark_style'].'" matches_day="'.$data['matches_day'].'"]');

		// End the widget markup.
		echo $data['after_widget'];

		// Return the output buffer.
		//return ob_get_clean();
	}

	/**
	 * Get widget options fields.
	 *
	 * @return array
	 */
	protected function get_widget_fields() {
		return VnxSport_Data_Helper::widget_slider_fields();
	}
}
