<?php get_header(); 
   /**
   * Template Name: مباريات الامس
   *
   * @package WordPress
   * @subpackage Twenty_Fourteen
   * @since Twenty Fourteen 1.0
   */

?>

<?php if ( AspwpOption('ad_under_header_enable') ) : ?>
    <?php $ad_under_header = AspwpOption('ad_under_header'); ?>
    <?php if ( ! empty($ad_under_header) ) : ?>
        <div class="ad-under-header">
            <?php echo do_shortcode( wp_kses_post($ad_under_header) ); ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php dynamic_sidebar( 'home_widget_top' ); ?>
<div class="main-wrapper">
    
<?php 
if (function_exists('Vnx_Sport_Plugin') && Vnx_Sport_Plugin()) {
  echo do_shortcode('[VnxSportTable show_timezone="0" title="أهم مباريات الأمس" tabs_type="links" matches_day="yesterday" yesterday_url="/matches-yesterday/" today_url="/matches-today/" tomorrow_url="/matches-tomorrow/"]');
}
?>
<?php if (have_posts()): ?>
<main id="main" class="VnxSportFixture VnxSport-main yp-news-block">
    <div class="AF_Title ">
      <h2 class="vnx-btn"><?php echo __('الاخبار','vnx');?></h2>

    </div>
	<?php
$paged = 1;

$args = array(
    'post_type'      => 'post',
    'posts_per_page' => 8,
    'paged'          => $paged,
);

$articles_query = new WP_Query( $args );
?>

<div id="ap-articles-wrap" class="ap-news-list">
    <?php if ( $articles_query->have_posts() ) : ?>
        <?php while ( $articles_query->have_posts() ) : $articles_query->the_post(); ?>
            <?php get_template_part( 'content' ); ?>
        <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>
    <?php endif; ?>
</div>

<?php if ( $articles_query->max_num_pages > 1 ) : ?>
    <button class="ap-load-more" data-page="1" data-max="<?php echo esc_attr( $articles_query->max_num_pages ); ?>">
        <?php echo __('عرض المزيد','vnx');?>
    </button>
<?php endif; ?>
	
	
</main>
		
	
	<main id="main" class="VnxSportFixture VnxSport-main yp-news-block">
    <div class="AF_Title ">
      <h2 class="vnx-btn"><?php the_title(); ?></h2>

    </div>

<div style="padding: 10px;">
 <?php the_content();?>
</div>

	
</main>
	</div>
<?php endif;?>
<?php dynamic_sidebar( 'home_widget' ); ?>
<?php if ( AspwpOption('ad_before_footer_enable') ) : ?>
    <?php $ad_before_footer = AspwpOption('ad_before_footer'); ?>
    <?php if ( ! empty($ad_before_footer) ) : ?>
        <div class="ad-before-footer">
            <?php echo do_shortcode( wp_kses_post($ad_before_footer) ); ?>
        </div>
    <?php endif; ?>
<?php endif; ?>
<?php get_footer();