<?php
get_header();

global $wp_query;

/* حفظ الكويري الأصلي */
$old_wp_query = $wp_query;

/* رقم الصفحة الحالية */
$paged = max( 1, get_query_var( 'paged' ) );

/* نفس شروط الأرشيف الحالي + تحديد العدد */
$archive_args = $wp_query->query_vars;
$archive_args['posts_per_page'] = 12;
$archive_args['paged'] = $paged;

/* جلب المقالات */
$archive_query = new WP_Query( $archive_args );

/* مهم عشان الباجينيشن يشتغل مع الكويري الجديد */
$wp_query = $archive_query;
?>

<div class="vnx-archive">
    <div id="primary" class="content-area">
        <main id="main" class="site-main box">

            <?php if ( $archive_query->have_posts() ) : ?>

                <div class="box-title">
                    <?php the_archive_title( '<h1 class="title">', '</h1>' ); ?>
                </div>

                <?php the_archive_description( '<div class="taxonomy-description">', '</div>' ); ?>

                <div class="ap-news-list">

                    <?php while ( $archive_query->have_posts() ) : $archive_query->the_post(); ?>

                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'ap-news-card' ); ?>>
                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">

                                <div class="ap-thumb">
                                    <?php if ( has_post_thumbnail() ) : ?>
                                        <img
                                            width="800"
                                            height="450"
                                            data-img="<?php echo esc_url( get_the_post_thumbnail_url( get_the_ID(), 'large' ) ); ?>"
                                            alt="<?php the_title_attribute(); ?>"
                                            class="attachment-large size-large wp-post-image imgLoaded"
                                            decoding="async"
                                        >
                                    <?php endif; ?>
                                </div>

                                <div class="ap-card-content">
                                    <h3 class="ap-title">
                                        <?php echo wp_trim_words( get_the_title(), 9, '...' ); ?>
                                    </h3>

                                    <div class="ap-time">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                            <circle cx="12" cy="12" r="9"></circle>
                                            <polyline points="12 7 12 12 15 15"></polyline>
                                        </svg>
                                        <span><?php echo get_the_date( 'Y-m-d' ); ?></span>
                                    </div>
                                </div>

                            </a>
                        </article>

                    <?php endwhile; ?>

                </div>

                <?php
                if ( function_exists( 'VnxSport_pagination' ) ) {
                    VnxSport_pagination();
                }
                ?>

            <?php else : ?>

                <section class="no-results not-found">
                    <header class="page-header">
                        <h1 class="page-title"><?php _e( 'لا يوجد شي ', 'vnx' ); ?></h1>
                    </header>
                </section>

            <?php endif; ?>

        </main>
    </div>
</div>

<?php
wp_reset_postdata();

/* رجوع الكويري الأصلي */
$wp_query = $old_wp_query;

get_footer();
?>