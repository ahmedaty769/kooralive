<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('vnxsport_theme_module_php83_notice')) {
    function vnxsport_theme_module_php83_notice() {
        if (!current_user_can('manage_options')) {
            return;
        }
        echo '<div class="notice notice-error"><p>VnxSport integrated module is currently enabled only on PHP 8.3.</p></div>';
    }
}

if (!defined('VNXSPORT_IN_THEME')) {
    define('VNXSPORT_IN_THEME', true);
}

if (!defined('VNXSPORT_VER')) {
    define('VNXSPORT_VER', '14.2-theme');
}
if (!defined('VNXSPORT_AUTHOR')) {
    define('VNXSPORT_AUTHOR', wp_get_theme()->get('Author') ? wp_get_theme()->get('Author') : 'YSNSportTheme');
}
if (!defined('VNXSPORT_TEXTDOMAIN')) {
    define('VNXSPORT_TEXTDOMAIN', 'vnxsport');
}
if (!defined('VNXSPORT_PATH')) {
    define('VNXSPORT_PATH', trailingslashit(get_template_directory()) . 'inc/vnxsport/');
}
if (!defined('VNXSPORT_URL')) {
    define('VNXSPORT_URL', trailingslashit(get_template_directory_uri()) . 'inc/vnxsport/');
}

/*
 * السماح فقط بإصدارات PHP 8.3.x
 */
if (version_compare(PHP_VERSION, '8.3.0', '<') || version_compare(PHP_VERSION, '8.4.0', '>=')) {
    add_action('admin_notices', 'vnxsport_theme_module_php83_notice');
    return;
}

load_textdomain(VNXSPORT_TEXTDOMAIN, VNXSPORT_PATH . 'languages/asp-' . get_locale() . '.mo');

require_once VNXSPORT_PATH . 'includes/vendor/83/class-vnxsport-admin.php';

if (function_exists('Vnx_Sport_Plugin') && Vnx_Sport_Plugin()) {
    Vnx_Sport_Plugin()->hooks();
}

if (class_exists('vnxadani_Sports_Events')) {
    $vnxsport_theme_events_bridge = new vnxadani_Sports_Events();
    $vnxsport_theme_events_bridge->RemoveVnxSportFilter();
}