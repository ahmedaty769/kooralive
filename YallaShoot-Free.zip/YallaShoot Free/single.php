<?php
   get_header();
   ?>
   

<div class="vnx-single  justify-content-center">
    
<div class="content-area SINGLECard art ">      <?php while (have_posts()): the_post();?>
          <section class="main-content clearfix box">
<div class="entry-header">
      <div class="entry-title">
        <h1><?php the_title(); ?></h1>
    </div>
    <div class="entry-thumbnail">
        <?php
        if ( has_post_thumbnail() ) {
            the_post_thumbnail( 'bgslide-thumb', array(
                'class'         => 'attachment-large size-large wp-post-image',
                'alt'           => get_the_title(),
                'decoding'      => 'async',
                'fetchpriority' => 'high',
            ) );
        }
        ?>
    </div>

  
</div>
<div class="entry-info">

    <div class="entry-author">
        <span>الكاتب : <?php the_author(); ?></span>
    </div>

    <span class="entry-separator">-</span>

    <div class="entry-category">
        <span>التصنيف : <?php echo get_the_category_list( '، ' ); ?></span>
    </div>

    <span class="entry-separator">-</span>

    <div class="entry-date">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
            <path d="M9 1V3H15V1H17V3H21C21.5523 3 22 3.44772 22 4V20C22 20.5523 21.5523 21 21 21H3C2.44772 21 2 20.5523 2 20V4C2 3.44772 2.44772 3 3 3H7V1H9ZM20 11H4V19H20V11ZM7 5H4V9H20V5H17V7H15V5H9V7H7V5Z"></path>
        </svg>
        <span>التاريخ : <?php echo get_the_date( 'j F Y' ); ?></span>
    </div>

</div>
            <div class="content_entry">
               <?php the_content();?>
                <?php the_tags('<div class="post_tags">', ' ', '</div>');?>
                <?php
$post_url   = get_permalink();
$post_title = get_the_title();

$encoded_url   = rawurlencode( $post_url );
$encoded_title = rawurlencode( $post_title );
?>

<div class="share-buttons">
    <div class="button-group">


        <a class="twitter-link bg-twitter"
           target="_blank"
           rel="noopener noreferrer"
           href="https://twitter.com/intent/tweet?url=<?php echo esc_attr( $encoded_url ); ?>&text=<?php echo esc_attr( $encoded_title ); ?>">
            <svg width="20" height="20" xmlns="http://www.w3.org/2000/svg" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" image-rendering="optimizeQuality" fill-rule="evenodd" clip-rule="evenodd" viewBox="0 0 512 462.799"><path d="M403.229 0h78.506L310.219 196.04 512 462.799H354.002L230.261 301.007 88.669 462.799h-78.56l183.455-209.683L0 0h161.999l111.856 147.88L403.229 0zm-27.556 415.805h43.505L138.363 44.527h-46.68l283.99 371.278z" fill="#707488"></path></svg>
            تويتر
        </a>

        <a class="facebook-link bg-facebook"
           target="_blank"
           rel="noopener noreferrer"
           href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_attr( $encoded_url ); ?>">
           <svg width="28.525" height="22.218" viewBox="-5 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <title>facebook [#176]</title> <desc>Created with Sketch.</desc> <defs> </defs> <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> <g id="Dribbble-Light-Preview" transform="translate(-385.000000, -7399.000000)" fill="#ffffff"> <g id="icons" transform="translate(56.000000, 160.000000)"> <path d="M335.821282,7259 L335.821282,7250 L338.553693,7250 L339,7246 L335.821282,7246 L335.821282,7244.052 C335.821282,7243.022 335.847593,7242 337.286884,7242 L338.744689,7242 L338.744689,7239.14 C338.744689,7239.097 337.492497,7239 336.225687,7239 C333.580004,7239 331.923407,7240.657 331.923407,7243.7 L331.923407,7246 L329,7246 L329,7250 L331.923407,7250 L331.923407,7259 L335.821282,7259 Z" id="facebook-[#176]"> </path> </g> </g> </g> </g></svg>
            فيسبوك
        </a>

        <a class="whatsapp-link bg-whatsapp"
           target="_blank"
           rel="noopener noreferrer"
           href="https://wa.me/?text=<?php echo esc_attr( $encoded_url ); ?>">
            <svg fill="#ffffff" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" stroke="#ffffff"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="M11.42 9.49c-.19-.09-1.1-.54-1.27-.61s-.29-.09-.42.1-.48.6-.59.73-.21.14-.4 0a5.13 5.13 0 0 1-1.49-.92 5.25 5.25 0 0 1-1-1.29c-.11-.18 0-.28.08-.38s.18-.21.28-.32a1.39 1.39 0 0 0 .18-.31.38.38 0 0 0 0-.33c0-.09-.42-1-.58-1.37s-.3-.32-.41-.32h-.4a.72.72 0 0 0-.5.23 2.1 2.1 0 0 0-.65 1.55A3.59 3.59 0 0 0 5 8.2 8.32 8.32 0 0 0 8.19 11c.44.19.78.3 1.05.39a2.53 2.53 0 0 0 1.17.07 1.93 1.93 0 0 0 1.26-.88 1.67 1.67 0 0 0 .11-.88c-.05-.07-.17-.12-.36-.21z"></path><path d="M13.29 2.68A7.36 7.36 0 0 0 8 .5a7.44 7.44 0 0 0-6.41 11.15l-1 3.85 3.94-1a7.4 7.4 0 0 0 3.55.9H8a7.44 7.44 0 0 0 5.29-12.72zM8 14.12a6.12 6.12 0 0 1-3.15-.87l-.22-.13-2.34.61.62-2.28-.14-.23a6.18 6.18 0 0 1 9.6-7.65 6.12 6.12 0 0 1 1.81 4.37A6.19 6.19 0 0 1 8 14.12z"></path></g></svg>
            واتساب
        </a>

        <a class="linkedin-link bg-linkedin"
           target="_blank"
           rel="noopener noreferrer"
           href="https://t.me/share/url?url=<?php echo esc_attr( $encoded_url ); ?>&text=<?php echo esc_attr( $encoded_title ); ?>">
           <svg width="28.525" height="22.218" viewBox="0 0 496 512" xmlns="http://www.w3.org/2000/svg" fill="white">
      <path d="M248 8C111 8 0 119 0 256S111 504 248 504 496 393 496 256 385 8 248 8zM363 176.7c-3.7 39.2-19.9 134.4-28.1 178.3-3.5 18.6-10.3 24.8-16.9 25.4-14.4 1.3-25.3-9.5-39.3-18.7-21.8-14.3-34.2-23.2-55.3-37.2-24.5-16.1-8.6-25 5.3-39.5 3.7-3.8 67.1-61.5 68.3-66.7 .2-.7 .3-3.1-1.2-4.4s-3.6-.8-5.1-.5q-3.3 .7-104.6 69.1-14.8 10.2-26.9 9.9c-8.9-.2-25.9-5-38.6-9.1-15.5-5-27.9-7.7-26.8-16.3q.8-6.7 18.5-13.7 108.4-47.2 144.6-62.3c68.9-28.6 83.2-33.6 92.5-33.8 2.1 0 6.6 .5 9.6 2.9a10.5 10.5 0 0 1 3.5 6.7A43.8 43.8 0 0 1 363 176.7z"></path>
    </svg>
            تيليجرام
        </a>

    </div>
</div>
                </div>
                
          </section>


      <?php endwhile;?>
      </div>
      <?php
$paged = 1;

$args = array(
    'post_type'      => 'post',
    'posts_per_page' => 4,
    'paged'          => $paged,
    'orderby'        => 'rand',
);

$articles_query = new WP_Query( $args );
?>
<main id="main" class="VnxSportFixture VnxSport-main yp-news-block">
    <div class="AF_Title ">
      <h2 class="vnx-btn"><?php echo __('مقالات ذات صلة
','vnx');?></h2>

    </div>
<div id="ap-articles-wrap" class="ap-news-list">
    <?php if ( $articles_query->have_posts() ) : ?>
        <?php while ( $articles_query->have_posts() ) : $articles_query->the_post(); ?>
            <?php get_template_part( 'content' ); ?>
        <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>
    <?php endif; ?>
</div>
	
</main>
</div>
<?php
get_footer();
