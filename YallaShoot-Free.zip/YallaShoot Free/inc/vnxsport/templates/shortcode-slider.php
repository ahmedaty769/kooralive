<?php
/**
 * The Template for displaying Matches.
 *
 * This template can be overridden by copying it to yourtheme/VnxSport/shortcode-matches.php.
 *
 * @var object $data - Object with widget data.
 *
 * @author        VNX Web <vnxweb.com>
 * @package       VnxSport/Templates
 * @since         0.4.3
 *
 * @version       0.15.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$args = (object) wp_parse_args(
	$data,
	[
        'dark_style' 		=> '',
        'matches_day' 		=> 'today',
        'tabs_type' 		=> '',
        'yesterday'         => '',
        'today' 	        => '',
        'tomorrow'          => '',
        'limit'             => '',
        'all_matches_url'   => '',
	]
);

$tabs_days =  [
    [
        'slug'      => "yesterday",
        'name'      => __("Yestrday", VNXSPORT_TEXTDOMAIN),
        'curnt'     => ($data->matches_day == 'yesterday'),
    ],
    [
        'slug'      => "today",
        'name'      => __("Today", VNXSPORT_TEXTDOMAIN),
        'curnt'     => ($data->matches_day == '' || $data->matches_day == 'today'),
    ],
    [
        'slug'      => "tomorrow",
        'name'      => __("Tomorrow", VNXSPORT_TEXTDOMAIN),
        'curnt'     => ($data->matches_day == 'tomorrow'),
    ],
];

/* حل التحذير */
$wrapp_class = '';

/**
 * Hook: aspwp/tmpl-slider/before_slider
 */
do_action( 'aspwp/tmpl-slider/before_slider');

?>
<section class="AspTopSliderMatch asp-font <?php echo esc_attr( $wrapp_class ); ?>">
    <div class="asp-filter-day">
        <?php 
        foreach($tabs_days as $tab):

            if($args->{$tab['slug']} == '0'){
                continue ;
            }
            echo '<a href="#" class="gotoDay '.$tab['slug'].' '.($tab['curnt'] ? ' active' : ' ').'" data-day="'.$tab['slug'].'">'.$tab['name'].'</a>';

        endforeach;
        ?>
        <?php if(!empty($data->all_matches_url)):?>
            <a class="allMatchesBtn" href="<?php echo $data->all_matches_url;?>">جميع المباريات<svg viewBox="0 0 20 20"><path d="M15 20L4.7 10 15 0l.5.5L5.8 10l9.7 9.5z"></path></svg></a>
        <?php endif;?>
    </div>
    <div class="AspSliderInner ">
        <div class="AspMatchSlider">
            <?php 

            $match_count = (!empty($args->limit) && $args->limit != '0' ) ? $args->limit : '-1';
            $matches = Vnx_Sport_Plugin()->match->get_matches_by_day($args->matches_day,$match_count);
            if ( empty( $matches ) ) {     
                echo '<div class="nomatchinslide"><svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50">
    <path d="M-119.131,20h-41.249a1.376,1.376,0,0,0-1.375,1.375h0V51.625A1.376,1.376,0,0,0-160.381,53h41.249a1.376,1.376,0,0,0,1.375-1.375h0V21.375A1.376,1.376,0,0,0-119.131,20Zm-19.249,11.2a5.473,5.473,0,0,1,3.959,6.651,5.473,5.473,0,0,1-3.959,3.959Zm-20.625,0a5.473,5.473,0,0,1,3.959,6.651,5.473,5.473,0,0,1-3.959,3.959Zm17.875,10.61a5.473,5.473,0,0,1-3.959-6.651A5.473,5.473,0,0,1-141.13,31.2Zm0-13.431a8.241,8.241,0,0,0-6.759,9.494,8.24,8.24,0,0,0,6.759,6.759v5.623h-17.877V44.626a8.241,8.241,0,0,0,6.759-9.494,8.242,8.242,0,0,0-6.759-6.759V22.751h17.875Zm20.625,13.431a5.473,5.473,0,0,1-3.959-6.651,5.472,5.472,0,0,1,3.959-3.959Zm0-13.431a8.241,8.241,0,0,0-6.759,9.494,8.24,8.24,0,0,0,6.759,6.759v5.623h-17.875V44.626a8.241,8.241,0,0,0,6.759-9.494,8.242,8.242,0,0,0-6.759-6.759V22.751h17.874Z" transform="translate(163.877 -10.379)" fill="#64748b"></path>
    <line x2="44.5" y2="44" transform="translate(2.121 4.121)" fill="none" stroke="#64748b" stroke-linecap="round" stroke-width="3"></line>
</svg>'.__("There are no matches Today", VNXSPORT_TEXTDOMAIN).'</div>';
            }else{
                foreach ($matches as $match){
                    Vnx_Sport_Plugin()->load_partial($match, 'loops/loop-match-slider' );
                }
            }
            ?>
        </div>
        <div class="lSAction"><a class="lSPrev"><svg viewBox="0 0 20 20"><path d="M5.2 0l10.3 10L5.2 20l-.5-.5 9.7-9.5L4.7.5z"></path></svg></a><a class="lSNext"><svg viewBox="0 0 20 20"><path d="M15 20L4.7 10 15 0l.5.5L5.8 10l9.7 9.5z"></path></svg></a></div>
        <div class="aspwp-ajaxLoad"><img class="svg-loader" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/loader2.svg"></div>
   </div>
   <?php if(!empty($data->all_matches_url)):?>
        <a class="allMatchesBtn in_mobile" href="<?php echo $data->all_matches_url;?>">جميع المباريات<svg viewBox="0 0 20 20"><path d="M15 20L4.7 10 15 0l.5.5L5.8 10l9.7 9.5z"></path></svg></a>
    <?php endif;?>
</section>
<?php 
do_action( 'aspwp/tmpl-slider/after_slider');