<?php
/**
 * The Template for displaying Match card.
 *
 * This template can be overridden by copying it to yourtheme/vnxsport-template/match/match-card.php.
 *
 * @var object $data - Object with args.
 *
 * @author        VNX Web <vnxweb.com>
 * @package       VnxSport/Templates
 *
 * @version       0.0.1
 */

 if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$data  = (object) wp_parse_args(
    $data,[
        'match_id'          => '',
        'kickoff'           => '',
        'match_time'    	=> '',
        'home_name'         => '',
        'away_name'         => '',
        'home_logo'         => '',
        'away_logo'         => '',
        'home_goals'        => '',
        'away_goals'        => '',
        'home_penalty'  	=> '',
        'away_penalty'  	=> '',
        'status_meta'         => '',
        'status_id'         => '',
        'competition'      	=> '',
        'commentator'      	=> '',
        'channel_name'      => '',
    
    ]
);


/**
 * Hook: aspwp/tmpl-match/before_match_card
 *
 */
do_action( 'aspwp/tmpl-match/before_match_card');
?>
<?php $bg = get_template_directory_uri() . '/img/match-detail-stadium2.jpg'; ?>

<style>
.VnxSportCard:not(.AspSimpleCard) {
    background: url('<?php echo esc_url($bg); ?>') no-repeat center center #e3e5f0;
    background-size: cover;
}

html.dark .VnxSportCard:not(.AspSimpleCard) {
    background: url('<?php echo esc_url($bg); ?>') no-repeat center center #191c2a;
    background-size: cover;
}
</style>
<div class="SINGLECard">

<div class="asp-font VnxSportCard match-status__<?php echo esc_attr( $data->status_id ); ?>">
   <div class="AC_Inner">
      <div class="AC_FTeam card_AF_FTeam">
         <div class="AC_TeamImg">
			<img loading="lazy" width="80" height="80" src="<?php echo esc_url( $data->home_logo ); ?>" alt="<?php echo esc_attr( $data->home_name ); ?>">
		</div>
         <span class="AC_TeamTitle asp-font">
		 	<?php echo esc_html( $data->home_name ); ?>
		 </span>
      </div>
      <div class="AC_Data">
         <div class="vs">
	VS
         </div>

      </div>
      <div class="AC_FTeam AC_Team">
	  	<div class="AC_TeamImg">
			<?php if ( $data->away_logo ) : ?>
				<img loading="lazy" width="80" height="80" src="<?php echo esc_url( $data->away_logo ); ?>" alt="<?php echo esc_attr( $data->away_name ); ?>">
			<?php endif; ?>
		</div>         
		<div class="AC_TeamTitle asp-font">
		 	<?php echo esc_html( $data->away_name ); ?> 
		 </div>
      </div>
   </div>
   <?php do_action( 'aspwp/match/match-header-bottom', $data->match_id, $data );?>
	
</div>
</div>
<style>
.aspi_tabs_inner .aspi_matchTabs {
    display: block;
    background: #ffffff !important;
    border: 1px solid #eee;
    border-radius: 10px !important;
    margin-top: -2% !important;
    text-align: center !important;
    max-width: 1010px !important;
}
html.dark .aspi_tabs_inner .aspi_matchTabs {
    background: #1c2031 !important;
    border: 1px solid #1c2031;
}
</style>
<?php 
/**
 * Hook: aspwp/tmpl-match/after_match_card
 *
 */
do_action( 'aspwp/tmpl-match/after_match_card');