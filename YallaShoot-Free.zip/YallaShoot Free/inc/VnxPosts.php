<?php

if ( ! function_exists( 'register_VnxSport_news_widget' ) ) {
	function register_VnxSport_news_widget() {
		register_widget( 'VnxSport_news_widget' );
	}
}
add_action( 'widgets_init', 'register_VnxSport_news_widget' );

class VnxSport_news_widget extends WP_Widget {

	/* Constructor */
	public function __construct() {
		parent::__construct(
			'VnxSport_news_widget',
			__( 'VnxSport | قائمة المقالات', 'textdomain' ),
			array(
				'description' => __( 'عرض المواضيع على شكل مربعات', 'textdomain' ),
			)
		);
	}

	/* Widget */
	public function widget( $args, $instance ) {

		$title        = ! empty( $instance['title'] ) ? $instance['title'] : '';
		$Hidon        = ! empty( $instance['Hidon'] ) ? $instance['Hidon'] : '0';
		$widget_style = ! empty( $instance['widget_style'] ) ? $instance['widget_style'] : 's3';
		$cat          = ! empty( $instance['posts_cat_id'] ) ? (array) $instance['posts_cat_id'] : array();
		$pagenumber   = ! empty( $instance['pagenumber'] ) ? absint( $instance['pagenumber'] ) : 0;

		$widget_id = ! empty( $args['widget_id'] ) ? $args['widget_id'] : $this->id;

		/* إجبار ودجت أحدث المقالات رقم 7 على الشكل الثالث فقط */
		if ( $widget_id === 'vnxsport_news_widget-7' ) {
			$widget_style = 's3';
		}

		if ( wp_is_mobile() ) {
			if ( $Hidon === 'mobile' ) {
				return;
			}
			$showposts = ! empty( $instance['posts_num_mob'] ) ? absint( $instance['posts_num_mob'] ) : 8;
		} else {
			if ( $Hidon === 'comp' ) {
				return;
			}
			$showposts = ! empty( $instance['posts_num'] ) ? absint( $instance['posts_num'] ) : 8;
		}

		$paged = ( get_query_var( 'paged' ) > 1 ) ? get_query_var( 'paged' ) : 1;

		$post_args = array(
			'posts_per_page'      => $showposts,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true,
			'orderby'             => ! empty( $instance['posts_orderby'] ) ? $instance['posts_orderby'] : 'date',
			'order'               => 'DESC',
			'paged'               => $paged,
		);

		if ( ! empty( $cat ) ) {
			$post_args['category__in'] = array_map( 'absint', $cat );
		}

		if ( ! empty( $instance['posts_time'] ) && $instance['posts_time'] !== '0' ) {
			$post_args['date_query'] = array(
				array(
					'after' => sanitize_text_field( $instance['posts_time'] ),
				),
			);
		}

		if ( ! empty( $pagenumber ) ) {
			$post_args['offset'] = ( $paged - 1 ) * $showposts;
		}

		$posts = new WP_Query( $post_args );

		$title = apply_filters(
			'widget_title',
			empty( $instance['title'] ) ? '' : $instance['title'],
			$instance,
			$this->id_base
		);

		echo $args['before_widget'];

		if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}

		$custom_widget_class = 'widget-' . $widget_id . '-widget_styles' . $widget_style;

		echo '<div class="polist row ' . esc_attr( $widget_style ) . ' ' . esc_attr( $custom_widget_class ) . '">';

		if ( $posts->have_posts() ) :
			while ( $posts->have_posts() ) :
				$posts->the_post();

				if ( $widget_style === 's2' || $widget_style === 's3' ) {
					get_template_part( 'content', 's2' );
				} elseif ( $widget_style === 's4' ) {
					?>
					<div class="col-12">
						<a class="post-item d-flex" href="<?php the_permalink(); ?>" title="<?php echo esc_attr( get_the_title() ); ?>">
							<h3 class="title-inner"><?php the_title(); ?></h3>
						</a>
					</div>
					<?php
				} else {
					get_template_part( 'content' );
				}

			endwhile;
			wp_reset_postdata();
		else :
			echo '<p>' . esc_html__( 'لا توجد مقالات.', 'textdomain' ) . '</p>';
		endif;

		echo '</div>';

		echo $args['after_widget'];
	}

	public function update( $new, $old ) {
		$instance = array();

		$instance['title']         = isset( $new['title'] ) ? sanitize_text_field( $new['title'] ) : '';
		$instance['widget_style']  = isset( $new['widget_style'] ) ? sanitize_text_field( $new['widget_style'] ) : 's3';
		$instance['posts_num']     = isset( $new['posts_num'] ) ? absint( $new['posts_num'] ) : 8;
		$instance['posts_num_mob'] = isset( $new['posts_num_mob'] ) ? absint( $new['posts_num_mob'] ) : 8;
		$instance['posts_cat_id']  = isset( $new['posts_cat_id'] ) ? array_map( 'absint', (array) $new['posts_cat_id'] ) : array();
		$instance['pagenumber']    = isset( $new['pagenumber'] ) ? absint( $new['pagenumber'] ) : 0;
		$instance['posts_orderby'] = isset( $new['posts_orderby'] ) ? sanitize_text_field( $new['posts_orderby'] ) : 'date';
		$instance['posts_time']    = isset( $new['posts_time'] ) ? sanitize_text_field( $new['posts_time'] ) : '0';
		$instance['Hidon']         = isset( $new['Hidon'] ) ? sanitize_text_field( $new['Hidon'] ) : '0';

		return $instance;
	}

	public function form( $instance ) {
		$defaults = array(
			'title'         => 'أحدث المقالات',
			'posts_num'     => 8,
			'posts_num_mob' => 8,
			'posts_cat_id'  => array( 1 ),
			'pagenumber'    => 0,
			'posts_orderby' => 'date',
			'posts_time'    => '0',
			'Hidon'         => '0',
			'widget_style'  => 's3',
		);

		$instance     = wp_parse_args( (array) $instance, $defaults );
		$widget_style = $instance['widget_style'];
		?>
		
		<style>
			.widget .widget-inside .postslist-options .postform { width: 100%; }
			.widget .widget-inside .postslist-options p { margin: 3px 0; }
			.widget .widget-inside .postslist-options hr { margin: 20px 0 10px; }
			.widget .widget-inside .postslist-options h4 { margin-bottom: 10px; }
		</style>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e( 'عنوان: ', 'textdomain' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
		</p>

		<p>
			<div style="display:flex;overflow:hidden;width:100%;clear:both;border:solid 1px #fff;padding:10px;box-sizing:border-box;background:#eee;">
				<?php _e( 'عدد المقالات', 'textdomain' ); ?>
			</div>

			<div style="display:flex;overflow:hidden;width:100%;clear:both;border:solid 1px #fff;padding:10px;box-sizing:border-box;background:#eee;">
				<div style="display:flex;flex-direction:column;border-left:1px #fff solid;padding-left:10px;flex:0 0 50%;box-sizing:border-box;">
					<label><?php _e( 'كمبيوتر', 'textdomain' ); ?></label>
					<input id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" style="width:100px;" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" type="number" value="<?php echo absint( $instance['posts_num'] ); ?>" size="3" />
				</div>

				<div style="justify-content:center;display:flex;flex-direction:column;flex:0 0 50%;padding-right:10px;box-sizing:border-box;">
					<label><?php _e( 'جوال', 'textdomain' ); ?></label>
					<input id="<?php echo esc_attr( $this->get_field_id( 'posts_num_mob' ) ); ?>" style="width:100px;" name="<?php echo esc_attr( $this->get_field_name( 'posts_num_mob' ) ); ?>" type="number" value="<?php echo absint( $instance['posts_num_mob'] ); ?>" size="3" />
				</div>
			</div>
		</p>

		<div class="postslist-options">
			<p>
				<div style="display:flex;overflow:hidden;width:100%;clear:both;border:solid 1px #fff;padding:10px;box-sizing:border-box;background:#eee;flex-direction:column;">
					<div id="<?php echo esc_attr( $this->get_field_id( 'posts_cat_id' ) ); ?>" class="<?php echo esc_attr( $this->get_field_id( 'posts_cat_id' ) ); ?>">
						<label for="<?php echo esc_attr( $this->get_field_id( 'posts_cat_id' ) ); ?>"><?php _e( 'التصنيفات', 'textdomain' ); ?></label>

						<div class="multicheck-option" style="max-width:360px;max-height:140px;overflow-x:auto;border:solid 2px #CAD0D9;padding:10px;background:#fff;">
							<?php
							$categories = get_categories();

							foreach ( $categories as $cat ) {
								$checked = ( is_array( $instance['posts_cat_id'] ) && in_array( $cat->term_id, $instance['posts_cat_id'], true ) ) ? 'checked="checked"' : '';
								?>
								<label style="display:block;margin-bottom:5px;">
									<input
										type="checkbox"
										id="<?php echo esc_attr( $this->get_field_id( 'posts_cat_id' ) . '_' . $cat->term_id ); ?>"
										name="<?php echo esc_attr( $this->get_field_name( 'posts_cat_id' ) ); ?>[]"
										value="<?php echo esc_attr( $cat->term_id ); ?>"
										<?php echo $checked; ?>
									/>
									<?php echo esc_html( $cat->cat_name . ' (' . $cat->category_count . ')' ); ?>
								</label>
								<?php
							}
							?>
						</div>
					</div>
				</div>
			</p>

			<p>
				<div>
					<ul id="single_post" class="box_tabs_container">
						<li>
							<label for="<?php echo esc_attr( $this->get_field_id( 'widget_style' ) ); ?>s3">
								<input id="<?php echo esc_attr( $this->get_field_id( 'widget_style' ) ); ?>s3" type="radio" name="<?php echo esc_attr( $this->get_field_name( 'widget_style' ) ); ?>" <?php checked( $widget_style, 's3' ); ?> value="s3"/>
								<img class="lazy" style="transform:scaleX(-1);max-width:150px;" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/s3.png" alt="s3"/>
							</label>
						</li>
					</ul>
				</div>
			</p>

			<p>
				<div style="display:flex;overflow:hidden;width:100%;clear:both;border:solid 1px #fff;padding:10px;box-sizing:border-box;background:#eee;">
					<div style="display:flex;flex-direction:column;border-left:1px #fff solid;padding-left:10px;flex:0 0 50%;box-sizing:border-box;">
						<label style="width:100%;display:inline-block" for="<?php echo esc_attr( $this->get_field_id( 'posts_orderby' ) ); ?>">
							<?php _e( 'ترتيب حسب :', 'textdomain' ); ?>
						</label>

						<select style="width:100%" id="<?php echo esc_attr( $this->get_field_id( 'posts_orderby' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_orderby' ) ); ?>">
							<option value="date" <?php selected( $instance['posts_orderby'], 'date' ); ?>><?php _e( 'الأحدث', 'textdomain' ); ?></option>
							<option value="meta_value_num" <?php selected( $instance['posts_orderby'], 'meta_value_num' ); ?>><?php _e( 'الاكثر مشاهدة', 'textdomain' ); ?></option>
							<option value="comment_count" <?php selected( $instance['posts_orderby'], 'comment_count' ); ?>><?php _e( 'الأكثر تعليقا', 'textdomain' ); ?></option>
							<option value="rand" <?php selected( $instance['posts_orderby'], 'rand' ); ?>><?php _e( 'عشوائي', 'textdomain' ); ?></option>
						</select>
					</div>

					<div style="justify-content:center;display:flex;flex-direction:column;flex:0 0 50%;padding-right:10px;box-sizing:border-box;">
						<label style="width:100%;display:inline-block" for="<?php echo esc_attr( $this->get_field_id( 'posts_time' ) ); ?>">
							<?php _e( 'المقالات من', 'textdomain' ); ?>
						</label>

						<select style="width:100%" id="<?php echo esc_attr( $this->get_field_id( 'posts_time' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_time' ) ); ?>">
							<option value="0" <?php selected( $instance['posts_time'], '0' ); ?>>All time</option>
							<option value="1 year ago" <?php selected( $instance['posts_time'], '1 year ago' ); ?>><?php _e( 'هذا العام', 'textdomain' ); ?></option>
							<option value="1 month ago" <?php selected( $instance['posts_time'], '1 month ago' ); ?>><?php _e( 'هذا الشهر', 'textdomain' ); ?></option>
							<option value="1 week ago" <?php selected( $instance['posts_time'], '1 week ago' ); ?>><?php _e( 'هذا الاسبوع', 'textdomain' ); ?></option>
							<option value="1 day ago" <?php selected( $instance['posts_time'], '1 day ago' ); ?>><?php _e( '24 ساعة الماضية', 'textdomain' ); ?></option>
						</select>
					</div>
				</div>

				<div style="display:flex;overflow:hidden;width:100%;clear:both;border:solid 1px #fff;padding:10px;box-sizing:border-box;background:#eee;">
					<div style="display:flex;flex-direction:column;flex:0 0 100%;box-sizing:border-box;">
						<label style="width:100%;display:inline-block" for="<?php echo esc_attr( $this->get_field_id( 'Hidon' ) ); ?>">
							إخفاء على
						</label>

						<select style="width:100%" id="<?php echo esc_attr( $this->get_field_id( 'Hidon' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'Hidon' ) ); ?>">
							<option value="0" <?php selected( $instance['Hidon'], '0' ); ?>>-------</option>
							<option value="mobile" <?php selected( $instance['Hidon'], 'mobile' ); ?>>الجوال</option>
							<option value="comp" <?php selected( $instance['Hidon'], 'comp' ); ?>>الكمبيوتر</option>
						</select>
					</div>
				</div>

				<hr>
			</p>

			<style type="text/css">
				#single_post [type="radio"]:checked + img { border-color:#0073aa; }
				#single_post * { box-sizing:border-box; }
				#single_post { text-align:center; width:100%; max-width:100%; margin:0; padding:0; display:flex; flex-wrap:wrap; }
				#single_post li { display:inline-block; width:50% !important; padding:5px !important; line-height:1 !important; }
				#single_post [type="radio"] { display:none !important; text-align:center; margin:0 auto 5px; }
				#single_post label img { margin:0; border:#ececec 3px solid; padding:0; display:block; }
				#single_post label img:hover { border-color:#d3d3d3; }
				.option-item { clear:both; padding:10px 0; overflow:hidden; display:block; }
				span.labe2 { width:115px; display:inline-block; float:right; padding-top:4px; font-weight:bold; }
			</style>
		</div>
		<?php
	}
}