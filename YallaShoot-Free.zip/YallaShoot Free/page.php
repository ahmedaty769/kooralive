<?php
  get_header();
  ?>
<div class="vnx-single">
  <?php while (have_posts()): the_post();?>
  <section class="page-breadcrumb">

    <div class="breadcrumb-wrap">
        <h1><?php the_title(); ?></h1>
        <div class="breadcrumb-path">
            <a href="<?php echo esc_url( home_url('/') ); ?>"><?php echo __('الرئيسية','vnx');?></a>
            <i>/</i>
            <span><?php the_title(); ?></span>
        </div>
    </div>
  </section>

  <section class="box clearfix ">

    <div id="entry">
      <div class="entry">
        <?php the_content();?>
      </div>
    </div>
  </section>
  <?php endwhile;?>
</div>
<?php
get_footer();