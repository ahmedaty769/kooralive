<article id="post-<?php the_ID(); ?>" <?php post_class('ap-news-card'); ?>>
    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
        
        <div class="ap-thumb">
            <?php if ( has_post_thumbnail() ) : ?>
                <img 
                    width="800" 
                    height="450" 
                    data-img="<?php echo esc_url( get_the_post_thumbnail_url(get_the_ID(), 'large') ); ?>" 
                    alt="<?php the_title_attribute(); ?>" 
                    class="attachment-large size-large wp-post-image imgLoaded"
                    decoding="async"
                >
            <?php endif; ?>
        </div>

        <div class="ap-card-content">
            <h3 class="ap-title">
<?php echo wp_trim_words( get_the_title(), 9, '...' ); ?>            </h3>


            <div class="ap-time">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="9"></circle>
                    <polyline points="12 7 12 12 15 15"></polyline>
                </svg>
                <span><?php echo get_the_date('Y-m-d'); ?></span>
            </div>
        </div>
    </a>
</article>