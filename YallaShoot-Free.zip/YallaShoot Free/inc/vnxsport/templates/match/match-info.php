<?php
/**
 * The Template for displaying Match >> info Section.
 *
 * This template can be overridden by copying it to yourtheme/VnxSport/match/match-info.php.
 *
 * @var object $data - Object with args.
 *
 * @author        VNX Web <vnxweb.com>
 * @package       VnxSport/Templates
 * @since         0.0.1
 *
 * @version       0.14.14
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$data  = (object) wp_parse_args(
   $data,[
       'match_id'          => '',
       'kickoff'           => '',
       'match_time'    	   => '',
       'match_date'    	   => '',
       'home_name'         => '',
       'away_name'         => '',
       'home_logo'         => '',
       'away_logo'         => '',
       'home_goals'        => '',
       'away_goals'        => '',
       'home_penalty'  	   => '',
       'away_penalty'  	   => '',
       'status_meta'       => '',
       'status_id'         => '',
       'competition'      	=> '',
       'commentator'      	=> '',
       'channel_name'      => '',
   
   ]
);

$penalty_resu = $data->status_meta == 'ended_penalty' ? ' <span style="color: #eb5a3e;"><span class="name">'. esc_html__( 'Penalties',VNXSPORT_TEXTDOMAIN).'</span><span><span class="score">'.$data->home_penalty.'</span> - <span class="score">'.$data->away_penalty.'</span></span></span>' : '';
$match_info   = array(
   [
      'icon'   => '',
      'label'  => esc_html__("Competition"	 ,VNXSPORT_TEXTDOMAIN),
      'value'  => $data->competition
   ],
   [
      'icon'   => '',
      'label'  => esc_html__("Channel Name"	 ,VNXSPORT_TEXTDOMAIN),
      'value'  => $data->channel_name
   ],
   [
      'icon'   => '',
      'label'  => esc_html__("Commentator"	 ,VNXSPORT_TEXTDOMAIN),
      'value'  => $data->commentator
   ],
   [
      'icon'   => '',
      'label'  => esc_html__("Match Time"	   ,VNXSPORT_TEXTDOMAIN),
      'value'  => sprintf( __( '%s Time', VNXSPORT_TEXTDOMAIN ), Vnx_Sport_Plugin()->helper->get_timzone_name() )
   ],
   [
      'icon'   => '',
      'label'  => esc_html__("Matche Date"	 ,VNXSPORT_TEXTDOMAIN),
      'value'  => $data->match_date
   ],
   [
      'icon'   => '',
      'label'  => esc_html__("Matche Result"	 ,VNXSPORT_TEXTDOMAIN),
      'value'  => $data->home_name.' '.$data->home_goals.' - '.$data->away_goals.' '.$data->away_name . $penalty_resu
   ],

);
echo '<div class="aspwp-section aspwp-match-info" >';

   /**
    * Hook: aspwp/tmpl-match/before_match_info
   */
  
   do_action( 'aspwp/tmpl-match/before_match_info');


   echo '<div class="VnxMatchInfo asp-font">';

      echo '<h2 class="asp-font">'.esc_html__( "Matche Card",VNXSPORT_TEXTDOMAIN).' '.$data->home_name.' Vs '.$data->away_name.'</h2>';
      
      echo '<ul>';

         foreach ($match_info as $info) {
            echo '<li>';

               echo '<div class="title">'.$info['label'].'</div> ';

               echo '<div class="content">'.$info['value'].'</div> ';

            echo '</li>';
         }
         
      echo '</ul>';

   echo '</div>';

      /**
    * Hook: aspwp/tmpl-match/after_match_info
   */
  do_action( 'aspwp/tmpl-match/after_match_info');

echo '</div>';