<?php
/**
 * The Template for displaying Matches Loops.
 *
 * This template can be overridden by copying it to yourtheme/vnxsport-template/loop/loop-match-table.php.
 *
 * @var object $data - Object with args.
 *
 * @author        VNX Web <vnxweb.com>
 * @package       VnxSport/Templates
 *
 * @version       0.0.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$data  = (object) wp_parse_args(
	$data,
	[
		'match_id'       => '',
		'kickoff'        => '',
		'match_time'     => '',
		'home_name'      => '',
		'away_name'      => '',
		'home_logo'      => '',
		'away_logo'      => '',
		'home_goals'     => '',
		'away_goals'     => '',
		'home_penalty'   => '',
		'away_penalty'   => '',
		'status_meta'    => '',
		'status_class'   => '',
		'status_id'      => '',
		'status_title'   => '',
		'link'           => '',
		'link_title'     => '',
		'competition'    => '',
		'commentator'    => '',
		'channel_name'   => '',
		'ended_text'     => '',
	]
);

$match_class  = $data->status_meta == 'not_ended' ? 'AF_WithTimmer' : $data->status_class;
$status_title = $data->status_meta == 'not_ended' ? '<div class="asp-dot-flashing"></div>' : $data->status_title;

if ( $data->ended_text && $data->status_class == 'finished' ) {
	$data->link_title = $data->ended_text;
	$match_class      = 'gools';
	$status_title     = $data->ended_text;
}

if ( function_exists( 'is_amp_endpoint' ) && is_amp_endpoint() ) {
	$match_class  = $data->status_class;
	$status_title = $data->status_title;
}

$channel_name = trim( wp_strip_all_tags( (string) $data->channel_name ) );
$commentator  = trim( wp_strip_all_tags( (string) $data->commentator ) );
$competition  = trim( wp_strip_all_tags( (string) $data->competition ) );

$has_match_info = ( $channel_name !== '' || $commentator !== '' || $competition !== '' );

$hide_match_time = false;

if (
	in_array( (string) $data->status_class, [ 'live', 'finished' ], true ) ||
	in_array( (string) $data->status_meta, [ 'ended', 'ended_penalty' ], true ) ||
	( $data->ended_text && $data->status_class == 'finished' )
) {
	$hide_match_time = true;
}

$show_result = false;

if (
	in_array( (string) $data->status_class, [ 'live', 'finished' ], true ) ||
	in_array( (string) $data->status_meta, [ 'ended', 'ended_penalty' ], true ) ||
	( $data->ended_text && $data->status_class == 'finished' )
) {
	$show_result = true;
}
?>
<div class="AF_Match asp-w-100 AF_EvItem <?php echo esc_attr( $match_class ); ?>" data-start="<?php echo esc_attr( $data->kickoff ); ?>">
	<div class="AF_inner asp-flex">
		<div class="AF_Team AF_FTeam asp-txt-center">
			<div class="AF_TeamLogo asp-relative ">
				<img alt="<?php echo esc_attr( $data->home_name ); ?>" src="<?php echo esc_url( apply_filters( 'jetpack_photon_url', $data->home_logo ) ); ?>" width="80" height="80"/>
			</div>
			<div class="AF_TeamName asp-txt-center">
				<?php echo wp_kses_post( $data->home_name ); ?>
			</div>
		</div>

		<div class="AF_Data match-data asp-txt-center asp-relative">
			<div class="match-data">
				<div class="AF_EvTime" style="<?php echo $hide_match_time ? 'display:none;' : ''; ?>">
					<?php echo wp_kses_post( $data->match_time ); ?>
				</div>

				<?php if ( $show_result ) : ?>
					<div class="AF_EventResult asp-flex asp-w-100">
						<span class="result">
							<?php echo wp_kses_post( $data->home_goals ); ?>
						</span>

						<span class="result-separator">-</span>

						<span class="result">
							<?php echo wp_kses_post( $data->away_goals ); ?>
						</span>
					</div>
				<?php endif; ?>

				<div class="AF_EvStat asp-flex">
					<div id="gmDate<?php echo esc_attr( $data->match_id ); ?>" class="AF_StaText AF_Timer asp-inline-flex">
						<?php echo wp_kses_post( $status_title ); ?>
					</div>
				</div>

				<?php if ( $data->status_meta == 'ended_penalty' ) : ?>
					<div class="AF_EvPenalty">
						<div class="AF_PenResult">
							<span class="score">
								<?php echo wp_kses_post( $data->home_penalty ); ?>
							</span>
							<span class="name">
								<?php echo esc_html__( 'Penalties', VNXSPORT_TEXTDOMAIN ); ?>
							</span>
							<span class="score">
								<?php echo wp_kses_post( $data->away_penalty ); ?>
							</span>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<div class="AF_Team AF_STeam asp-txt-center">
			<div class="AF_TeamLogo asp-relative ">
				<img alt="<?php echo esc_attr( $data->away_name ); ?>" src="<?php echo esc_url( apply_filters( 'jetpack_photon_url', $data->away_logo ) ); ?>" width="80" height="80"/>
			</div>
			<div class="AF_TeamName asp-txt-center">
				<?php echo wp_kses_post( $data->away_name ); ?>
			</div>
		</div>
	</div>

	<?php if ( $has_match_info ) : ?>
		<div class="MT_Info">
			<ul>
				<?php if ( $channel_name !== '' ) : ?>
					<li><span><?php echo esc_html( $channel_name ); ?></span></li>
				<?php endif; ?>

				<?php if ( $commentator !== '' ) : ?>
					<li><span><?php echo esc_html( $commentator ); ?></span></li>
				<?php endif; ?>

				<?php if ( $competition !== '' ) : ?>
					<li><span><?php echo esc_html( $competition ); ?></span></li>
				<?php endif; ?>
			</ul>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $data->link ) ) : ?>
		<a <?php echo $data->link; ?> class="AF_EventMask">
			<div class="AF_MaskInner">
				<div class="MT_MaskText"></div>
			</div>
		</a>
	<?php endif; ?>
</div>