<?php
/**
 * The Template for displaying Matches Loops.
 *
 * This template can be overridden by copying it to yourtheme/vnxsport-template/loop/loop-match-small.php.
 *
 * @var object $data - Object with args.
 *
 * @author        VNX Web <vnxweb.com>
 * @package       VnxSport/Templates
 *
 * @version       0.0.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$data  = (object) wp_parse_args(
    $data,[
        'match_id'          => '',
        'kickoff'           => '',
        'match_time'    	=> '',
        'home_name'         => '',
        'away_name'         => '',
        'home_logo'         => '',
        'away_logo'         => '',
        'home_goals'        => '',
        'away_goals'        => '',
        'home_penalty'  	=> '',
        'away_penalty'  	=> '',
        'status_meta'       => '',
        'status_class'      => '',
        'status_id'         => '',
        'status_title'      => '',
        'link'          	=> '',
        'link_title'    	=> '',
        'competition'      	=> '',
        'commentator'      	=> '',
        'channel_name'      => '',
        'ended_text'      	=> '',
    
    ]
);

// Get match data to render

$match_class            = $data->status_meta == 'not_ended' ?  'AF_WithTimmer' : $data->status_class;
$status_title           = $data->status_meta == 'not_ended' ?  '<div class="asp-dot-flashing"></div>' : $data->status_title;

if ($data->ended_text && $data->status_class == 'finished' ) {
    $data->link_title   = $data->ended_text; 
    $match_class        = 'gools';
    $status_title       =  $data->ended_text; 
}
if(function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()){
    $match_class            =  $data->status_class;
    $status_title           =   $data->status_title;
}
?>
<div class="AF_Match AspMatchItem <?php echo $match_class;?>" data-start="<?php echo $data->kickoff;?>">
    <div class="teamA asps-team">
        <img src="<?php echo apply_filters('jetpack_photon_url', $data->home_logo);?>" width="50" height="50"/>
        <span><?php echo $data->home_name;?></span>
    </div>
    <div class="resultDiv">
        <span class="AF_EvTime"><?php echo $data->match_time;?></span>
        <div class="matchResult">
        <span class="asps-result LiveTeamA">
            <?php echo $data->home_goals;?>
        </span>
        <span> - </span>
        <span class="asps-result LiveTeamB">
            <?php echo $data->away_goals;?>
        </span>
        </div>
        <div class="matchStatus">
            <span class="asps-status AF_Timer">
                <?php echo $status_title;?>
            </span>
        </div>
    </div>
    <div class="teamB asps-team">
        <img src="<?php echo apply_filters('jetpack_photon_url', $data->away_logo) ;?>" width="50" height="50"/>
        <span><?php echo $data->away_name;?></span>
    </div>
    <div class="clear"></div>
    <?php if( ! empty($data->link) ) : ?>
        <a class="aspwp-link-cover" <?php echo $data->link;?>></a>
    <?php endif;?>
</div>