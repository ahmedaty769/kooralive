<?php
  if ( post_password_required() ) {
  	return;
  }
  ?>
<div id="comments" class="comments-area clearfix">
  <h2 class="comments-t">
  <?php _e( 'تعليقات الزوار','vnx'); ?> ( <?php echo get_comments_number(); ?> )
  </h2>
  <?php
    // You can start editing here -- including this comment!
    if ( have_comments() ) : ?>
  <ol class="comment-list">
    <?php
      wp_list_comments( array(
      	'style'      => 'ol',
      	'short_ping' => true,
      	'avatar_size'       => 30,
      	'reply_text'        => __('رد','vnx'),
      	) );
      	?>
  </ol>
  <?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :?>
  <nav id="comment-nav-below" class="navigation comment-navigation clearfix" role="navigation">
    <div class="nav-links">
      <div class="nav-previous"><?php previous_comments_link( esc_html__( 'التعليقات الاقدم','vnx') ); ?></div>
      <div class="nav-next"><?php next_comments_link( esc_html__( 'التعليقات الاحدث','vnx') ); ?></div>
    </div>
  </nav>
  <?php
    endif;
    endif;
    
    if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
  <p class="no-comments"><?php esc_html_e( 'Comments are closed.'); ?></p>
  <?php
    endif;
    $args = array(
    	'comment_field' => '<p class="comment-form-comment">' .
    	'<textarea id="comment" name="comment" placeholder="'.__('افكارك ..','vnx').'" cols="45" rows="8" aria-required="true"></textarea>' .
    	'</p>',
    'fields' => apply_filters(
    	'comment_form_default_fields', array(
    		'author' =>'<p class="comment-form-author">' . '<input id="author" placeholder="'.__('الاسم','vnx').'" name="author" type="text" value="' .
    			esc_attr( $commenter['comment_author'] ) . '" size="30" />'.
    			'</p>'
    			,
    		'email'  => '<p class="comment-form-email">' . '<input id="email" placeholder="'.__('الايميل','vnx').'" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
    			'" size="30" />'  .
    			'</p>',
    		'url'    => '<p class="comment-form-url">' .
    		 '<input id="url" name="url" placeholder="'.__('عنوان موقعك','vnx').'" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="30" /> ' .
               '</p>'
    	)
    ),
       'comment_notes_after' => false,
       'comment_notes_before' => false,
    
    );
    comment_form($args);
    ?>
</div>