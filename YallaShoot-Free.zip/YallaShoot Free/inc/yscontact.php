<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/
function ys_contact_get_user_ip() {
	$ip_keys = array(
		'HTTP_CF_CONNECTING_IP',
		'HTTP_X_FORWARDED_FOR',
		'HTTP_CLIENT_IP',
		'REMOTE_ADDR',
	);

	foreach ( $ip_keys as $key ) {
		if ( ! empty( $_SERVER[ $key ] ) ) {
			$raw_ip = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );

			if ( 'HTTP_X_FORWARDED_FOR' === $key && strpos( $raw_ip, ',' ) !== false ) {
				$ips    = explode( ',', $raw_ip );
				$raw_ip = trim( $ips[0] );
			}

			if ( filter_var( $raw_ip, FILTER_VALIDATE_IP ) ) {
				return $raw_ip;
			}
		}
	}

	return '';
}

function ys_contact_get_user_agent() {
	return ! empty( $_SERVER['HTTP_USER_AGENT'] )
		? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) )
		: '';
}

function ys_contact_get_referrer() {
	return ! empty( $_SERVER['HTTP_REFERER'] )
		? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) )
		: '';
}

/*
|--------------------------------------------------------------------------
| Register Post Type
|--------------------------------------------------------------------------
*/
add_action( 'init', 'ys_register_contact_messages_cpt' );

function ys_register_contact_messages_cpt() {
	$labels = array(
		'name'               => esc_html__( 'رسائل اتصل بنا', 'vnx' ),
		'singular_name'      => esc_html__( 'رسالة', 'vnx' ),
		'menu_name'          => esc_html__( 'رسائل اتصل بنا', 'vnx' ),
		'name_admin_bar'     => esc_html__( 'رسالة', 'vnx' ),
		'add_new'            => esc_html__( 'إضافة جديد', 'vnx' ),
		'add_new_item'       => esc_html__( 'إضافة رسالة', 'vnx' ),
		'new_item'           => esc_html__( 'رسالة جديدة', 'vnx' ),
		'edit_item'          => esc_html__( 'عرض الرسالة', 'vnx' ),
		'view_item'          => esc_html__( 'عرض الرسالة', 'vnx' ),
		'all_items'          => esc_html__( 'كل الرسائل', 'vnx' ),
		'search_items'       => esc_html__( 'بحث في الرسائل', 'vnx' ),
		'not_found'          => esc_html__( 'لا توجد رسائل', 'vnx' ),
		'not_found_in_trash' => esc_html__( 'لا توجد رسائل في المهملات', 'vnx' ),
	);

	register_post_type(
		'ys_contact_message',
		array(
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'exclude_from_search' => true,
			'publicly_queryable'  => false,
			'has_archive'         => false,
			'menu_icon'           => 'dashicons-email-alt',
			'supports'            => array( 'title' ),
			'map_meta_cap'        => true,
			'capability_type'     => 'post',
			'capabilities'        => array(
				'create_posts' => 'do_not_allow',
			),
		)
	);
}

/*
|--------------------------------------------------------------------------
| Hide Add New
|--------------------------------------------------------------------------
*/
add_action( 'admin_menu', 'ys_hide_add_new_contact_message_submenu', 999 );

function ys_hide_add_new_contact_message_submenu() {
	remove_submenu_page( 'edit.php?post_type=ys_contact_message', 'post-new.php?post_type=ys_contact_message' );
}

/*
|--------------------------------------------------------------------------
| Hide Add New button and edit UI
|--------------------------------------------------------------------------
*/
add_action( 'admin_head', 'ys_hide_contact_message_add_new_button' );

function ys_hide_contact_message_add_new_button() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

	if ( $screen && 'ys_contact_message' === $screen->post_type ) {
		echo '<style>
			.page-title-action,
			#favorite-actions,
			#minor-publishing,
			#misc-publishing-actions,
			#save-post,
			#publish,
			#preview-action,
			#edit-slug-box,
			#postdivrich {
				display:none !important;
			}
		</style>';
	}
}

/*
|--------------------------------------------------------------------------
| Custom Columns
|--------------------------------------------------------------------------
*/
add_filter( 'manage_ys_contact_message_posts_columns', 'ys_contact_message_columns' );

function ys_contact_message_columns( $columns ) {
	return array(
		'cb'        => '<input type="checkbox" />',
		'title'     => esc_html__( 'عنوان الرسالة', 'vnx' ),
		'sender'    => esc_html__( 'الاسم', 'vnx' ),
		'email'     => esc_html__( 'البريد الإلكتروني', 'vnx' ),
		'ip'        => esc_html__( 'IP', 'vnx' ),
		'user_type' => esc_html__( 'الحالة', 'vnx' ),
		'date'      => esc_html__( 'التاريخ', 'vnx' ),
	);
}

add_action( 'manage_ys_contact_message_posts_custom_column', 'ys_contact_message_custom_column', 10, 2 );

function ys_contact_message_custom_column( $column, $post_id ) {
	switch ( $column ) {
		case 'sender':
			echo esc_html( get_post_meta( $post_id, '_ys_contact_name', true ) );
			break;

		case 'email':
			$email = get_post_meta( $post_id, '_ys_contact_email', true );
			echo $email ? esc_html( $email ) : '—';
			break;

		case 'ip':
			$ip = get_post_meta( $post_id, '_ys_contact_ip', true );
			echo $ip ? esc_html( $ip ) : '—';
			break;

		case 'user_type':
			$user_id = get_post_meta( $post_id, '_ys_contact_user_id', true );
			echo esc_html( $user_id ? __( 'مسجل دخول', 'vnx' ) : __( 'زائر', 'vnx' ) );
			break;
	}
}

/*
|--------------------------------------------------------------------------
| Make row actions: view/delete only
|--------------------------------------------------------------------------
*/
add_filter( 'post_row_actions', 'ys_contact_messages_row_actions', 10, 2 );

function ys_contact_messages_row_actions( $actions, $post ) {
	if ( 'ys_contact_message' === $post->post_type ) {
		unset( $actions['inline hide-if-no-js'] );
		unset( $actions['edit'] );
		unset( $actions['view'] );
	}

	return $actions;
}

/*
|--------------------------------------------------------------------------
| Read-only Metabox
|--------------------------------------------------------------------------
*/
add_action( 'add_meta_boxes', 'ys_contact_message_add_meta_boxes' );

function ys_contact_message_add_meta_boxes() {
	add_meta_box(
		'ys_contact_message_details',
		esc_html__( 'تفاصيل الرسالة', 'vnx' ),
		'ys_contact_message_details_callback',
		'ys_contact_message',
		'normal',
		'high'
	);

	remove_meta_box( 'submitdiv', 'ys_contact_message', 'side' );
}

function ys_contact_message_details_callback( $post ) {
	$name       = get_post_meta( $post->ID, '_ys_contact_name', true );
	$email      = get_post_meta( $post->ID, '_ys_contact_email', true );
	$message    = get_post_meta( $post->ID, '_ys_contact_message', true );
	$user_id    = get_post_meta( $post->ID, '_ys_contact_user_id', true );
	$ip         = get_post_meta( $post->ID, '_ys_contact_ip', true );
	$user_agent = get_post_meta( $post->ID, '_ys_contact_user_agent', true );
	$referrer   = get_post_meta( $post->ID, '_ys_contact_referrer', true );

	$user = $user_id ? get_user_by( 'id', $user_id ) : false;
	?>
	<table class="form-table">
		<tr>
			<th><label><?php echo esc_html__( 'الاسم', 'vnx' ); ?></label></th>
			<td><input type="text" class="regular-text" value="<?php echo esc_attr( $name ); ?>" readonly></td>
		</tr>

		<tr>
			<th><label><?php echo esc_html__( 'البريد الإلكتروني', 'vnx' ); ?></label></th>
			<td><input type="text" class="regular-text" value="<?php echo esc_attr( $email ); ?>" readonly></td>
		</tr>

		<tr>
			<th><label><?php echo esc_html__( 'الحالة', 'vnx' ); ?></label></th>
			<td><input type="text" class="regular-text" value="<?php echo esc_attr( $user ? __( 'مسجل دخول', 'vnx' ) : __( 'زائر', 'vnx' ) ); ?>" readonly></td>
		</tr>

		<?php if ( $user ) : ?>
			<tr>
				<th><label><?php echo esc_html__( 'المستخدم', 'vnx' ); ?></label></th>
				<td><input type="text" class="regular-text" value="<?php echo esc_attr( $user->display_name . ' (' . $user->user_login . ')' ); ?>" readonly></td>
			</tr>
		<?php endif; ?>

		<tr>
			<th><label><?php echo esc_html__( 'IP', 'vnx' ); ?></label></th>
			<td><input type="text" class="regular-text" value="<?php echo esc_attr( $ip ); ?>" readonly></td>
		</tr>

		<tr>
			<th><label><?php echo esc_html__( 'User Agent', 'vnx' ); ?></label></th>
			<td><textarea rows="4" class="large-text" readonly><?php echo esc_textarea( $user_agent ); ?></textarea></td>
		</tr>

		<tr>
			<th><label><?php echo esc_html__( 'Referrer', 'vnx' ); ?></label></th>
			<td><input type="text" class="large-text" value="<?php echo esc_attr( $referrer ); ?>" readonly></td>
		</tr>

		<tr>
			<th><label><?php echo esc_html__( 'الرسالة', 'vnx' ); ?></label></th>
			<td><textarea rows="10" class="large-text" readonly><?php echo esc_textarea( $message ); ?></textarea></td>
		</tr>
	</table>

	<p style="margin-top:15px;color:#666;">
		<?php echo esc_html__( 'هذه الرسالة للعرض فقط. يمكن حذفها من قائمة الرسائل.', 'vnx' ); ?>
	</p>
	<?php
}

/*
|--------------------------------------------------------------------------
| Prevent editing but allow view/delete
|--------------------------------------------------------------------------
*/
add_action( 'admin_init', 'ys_contact_message_prevent_editing' );

function ys_contact_message_prevent_editing() {
	global $pagenow;

	if ( ! is_admin() || 'post.php' !== $pagenow ) {
		return;
	}

	$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;

	if ( ! $post_id && isset( $_POST['post_ID'] ) ) {
		$post_id = absint( $_POST['post_ID'] );
	}

	if ( ! $post_id ) {
		return;
	}

	$post = get_post( $post_id );

	if ( ! $post || 'ys_contact_message' !== $post->post_type ) {
		return;
	}

	if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['post_ID'] ) ) {
		wp_die( esc_html__( 'لا يمكن تعديل هذه الرسالة. يمكنك فقط عرضها أو حذفها.', 'vnx' ) );
	}
}

/*
|--------------------------------------------------------------------------
| Keep old post data if any update is attempted
|--------------------------------------------------------------------------
*/
add_filter( 'wp_insert_post_data', 'ys_contact_message_block_admin_update', 10, 2 );

function ys_contact_message_block_admin_update( $data, $postarr ) {
	if (
		is_admin() &&
		! empty( $postarr['ID'] ) &&
		! empty( $data['post_type'] ) &&
		'ys_contact_message' === $data['post_type']
	) {
		$old_post = get_post( $postarr['ID'] );
		if ( $old_post ) {
			$data['post_title']   = $old_post->post_title;
			$data['post_content'] = $old_post->post_content;
			$data['post_status']  = $old_post->post_status;
			$data['post_name']    = $old_post->post_name;
		}
	}

	return $data;
}

/*
|--------------------------------------------------------------------------
| Add Delete All button
|--------------------------------------------------------------------------
*/
add_action( 'admin_notices', 'ys_contact_messages_delete_all_button' );

function ys_contact_messages_delete_all_button() {
	global $pagenow;

	if ( ! is_admin() || 'edit.php' !== $pagenow ) {
		return;
	}

	$post_type = isset( $_GET['post_type'] ) ? sanitize_key( $_GET['post_type'] ) : '';

	if ( 'ys_contact_message' !== $post_type ) {
		return;
	}

	if ( ! current_user_can( 'delete_posts' ) ) {
		return;
	}

	$url = wp_nonce_url(
		admin_url( 'edit.php?post_type=ys_contact_message&ys_delete_all_messages=1' ),
		'ys_delete_all_messages_action',
		'ys_delete_all_nonce'
	);

	echo '<div class="notice notice-warning" style="padding:12px 14px;">';
	echo '<p style="margin:0;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">';
	echo '<span>' . esc_html__( 'يمكنك حذف جميع الرسائل دفعة واحدة.', 'vnx' ) . '</span>';
	echo '<a href="' . esc_url( $url ) . '" class="button button-secondary" onclick="return confirm(\'' . esc_js( __( 'هل أنت متأكد من حذف جميع الرسائل؟', 'vnx' ) ) . '\');">' . esc_html__( 'حذف الجميع', 'vnx' ) . '</a>';
	echo '</p>';
	echo '</div>';
}

/*
|--------------------------------------------------------------------------
| Handle Delete All
|--------------------------------------------------------------------------
*/
add_action( 'admin_init', 'ys_contact_messages_handle_delete_all' );

function ys_contact_messages_handle_delete_all() {
	if ( ! is_admin() ) {
		return;
	}

	$post_type  = isset( $_GET['post_type'] ) ? sanitize_key( $_GET['post_type'] ) : '';
	$delete_all = isset( $_GET['ys_delete_all_messages'] ) ? absint( $_GET['ys_delete_all_messages'] ) : 0;

	if ( 'ys_contact_message' !== $post_type || 1 !== $delete_all ) {
		return;
	}

	if ( ! current_user_can( 'delete_posts' ) ) {
		wp_die( esc_html__( 'ليس لديك صلاحية حذف الرسائل.', 'vnx' ) );
	}

	check_admin_referer( 'ys_delete_all_messages_action', 'ys_delete_all_nonce' );

	$messages = get_posts(
		array(
			'post_type'      => 'ys_contact_message',
			'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'trash' ),
			'posts_per_page' => -1,
			'fields'         => 'ids',
		)
	);

	if ( ! empty( $messages ) ) {
		foreach ( $messages as $message_id ) {
			wp_delete_post( $message_id, true );
		}
	}

	wp_safe_redirect( admin_url( 'edit.php?post_type=ys_contact_message&ys_deleted_all=1' ) );
	exit;
}

/*
|--------------------------------------------------------------------------
| Delete All Success Notice
|--------------------------------------------------------------------------
*/
add_action( 'admin_notices', 'ys_contact_messages_delete_all_success_notice' );

function ys_contact_messages_delete_all_success_notice() {
	if ( ! is_admin() ) {
		return;
	}

	$post_type = isset( $_GET['post_type'] ) ? sanitize_key( $_GET['post_type'] ) : '';
	$deleted   = isset( $_GET['ys_deleted_all'] ) ? absint( $_GET['ys_deleted_all'] ) : 0;

	if ( 'ys_contact_message' !== $post_type || 1 !== $deleted ) {
		return;
	}

	echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'تم حذف جميع الرسائل بنجاح.', 'vnx' ) . '</p></div>';
}

/*
|--------------------------------------------------------------------------
| Shortcode: [ys_contact_page]
|--------------------------------------------------------------------------
*/
add_shortcode( 'ys_contact_page', 'ys_contact_page_shortcode' );

function ys_contact_page_shortcode() {
	$current_user = wp_get_current_user();
	$is_logged_in = is_user_logged_in();
	$name_value   = $is_logged_in ? $current_user->display_name : '';
	$email_value  = $is_logged_in ? $current_user->user_email : '';
	$success_msg  = '';
	$error_msg    = '';

	if ( isset( $_POST['ys_contact_submit'] ) ) {
		if ( ! isset( $_POST['ys_contact_nonce'] ) || ! wp_verify_nonce( $_POST['ys_contact_nonce'], 'ys_contact_form_action' ) ) {
			$error_msg = __( 'حدث خطأ أمني، حاول مرة أخرى.', 'vnx' );
		} else {
			$name       = isset( $_POST['ys_contact_name'] ) ? sanitize_text_field( wp_unslash( $_POST['ys_contact_name'] ) ) : '';
			$email      = isset( $_POST['ys_contact_email'] ) ? sanitize_email( wp_unslash( $_POST['ys_contact_email'] ) ) : '';
			$message    = isset( $_POST['ys_contact_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ys_contact_message'] ) ) : '';
			$ip         = ys_contact_get_user_ip();
			$user_agent = ys_contact_get_user_agent();
			$referrer   = ys_contact_get_referrer();

			if ( $is_logged_in ) {
				$email = $current_user->user_email;
			}

			if ( empty( $name ) || empty( $message ) ) {
				$error_msg = __( 'يرجى ملء جميع الحقول المطلوبة.', 'vnx' );
			} elseif ( ! $is_logged_in && ( empty( $email ) || ! is_email( $email ) ) ) {
				$error_msg = __( 'يرجى إدخال بريد إلكتروني صحيح.', 'vnx' );
			} else {
				if ( ! empty( $ip ) ) {
					$existing = get_posts(
						array(
							'post_type'      => 'ys_contact_message',
							'post_status'    => 'publish',
							'posts_per_page' => 1,
							'fields'         => 'ids',
							'orderby'        => 'date',
							'order'          => 'DESC',
							'meta_query'     => array(
								array(
									'key'   => '_ys_contact_ip',
									'value' => $ip,
								),
							),
							'date_query'     => array(
								array(
									'after' => '1 hour ago',
								),
							),
						)
					);

					if ( ! empty( $existing ) ) {
						$error_msg = __( 'لقد أرسلت رسالة بالفعل من نفس الشبكة. يمكنك المحاولة مرة أخرى بعد ساعة.', 'vnx' );
					}
				}

				if ( empty( $error_msg ) ) {
					$post_id = wp_insert_post(
						array(
							'post_type'   => 'ys_contact_message',
							'post_status' => 'publish',
							'post_title'  => sprintf(
								/* translators: 1: sender name, 2: current datetime */
								__( 'رسالة من %1$s - %2$s', 'vnx' ),
								$name,
								current_time( 'mysql' )
							),
						),
						true
					);

					if ( is_wp_error( $post_id ) ) {
						$error_msg = __( 'تعذر إرسال الرسالة حاليًا، حاول لاحقًا.', 'vnx' );
					} else {
						update_post_meta( $post_id, '_ys_contact_name', $name );
						update_post_meta( $post_id, '_ys_contact_email', $email );
						update_post_meta( $post_id, '_ys_contact_message', $message );
						update_post_meta( $post_id, '_ys_contact_user_id', $is_logged_in ? $current_user->ID : 0 );
						update_post_meta( $post_id, '_ys_contact_ip', $ip );
						update_post_meta( $post_id, '_ys_contact_user_agent', $user_agent );
						update_post_meta( $post_id, '_ys_contact_referrer', $referrer );

						$success_msg = __( 'تم إرسال رسالتك بنجاح.', 'vnx' );

						if ( ! $is_logged_in ) {
							$name_value  = '';
							$email_value = '';
						}
					}
				}
			}
		}
	}

	ob_start();
	?>
	<div class="ys-contact-wrap">
		<div class="ys-contact-card">
			<h2><?php echo esc_html__( 'اتصل بنا', 'vnx' ); ?></h2>
			<p class="ys-contact-desc"><?php echo esc_html__( 'يمكنك إرسال استفسارك أو رسالتك من خلال النموذج التالي.', 'vnx' ); ?></p>

			<?php if ( $success_msg ) : ?>
				<div class="ys-contact-alert success"><?php echo esc_html( $success_msg ); ?></div>
			<?php endif; ?>

			<?php if ( $error_msg ) : ?>
				<div class="ys-contact-alert error"><?php echo esc_html( $error_msg ); ?></div>
			<?php endif; ?>

			<form method="post" class="ys-contact-form">
				<?php wp_nonce_field( 'ys_contact_form_action', 'ys_contact_nonce' ); ?>

				<div class="ys-contact-field">
					<label for="ys_contact_name"><?php echo esc_html__( 'الاسم', 'vnx' ); ?></label>
					<input
						type="text"
						id="ys_contact_name"
						name="ys_contact_name"
						value="<?php echo esc_attr( $name_value ); ?>"
						<?php echo $is_logged_in ? 'readonly' : ''; ?>
						required
					>
				</div>

				<?php if ( ! $is_logged_in ) : ?>
					<div class="ys-contact-field">
						<label for="ys_contact_email"><?php echo esc_html__( 'البريد الإلكتروني', 'vnx' ); ?></label>
						<input
							type="email"
							id="ys_contact_email"
							name="ys_contact_email"
							value="<?php echo esc_attr( $email_value ); ?>"
							required
						>
					</div>
				<?php endif; ?>

				<div class="ys-contact-field">
					<label for="ys_contact_message"><?php echo esc_html__( 'الرسالة', 'vnx' ); ?></label>
					<textarea
						id="ys_contact_message"
						name="ys_contact_message"
						rows="7"
						required
					><?php echo isset( $_POST['ys_contact_message'] ) && ! $success_msg ? esc_textarea( wp_unslash( $_POST['ys_contact_message'] ) ) : ''; ?></textarea>
				</div>

				<button type="submit" name="ys_contact_submit" class="ys-contact-btn"><?php echo esc_html__( 'إرسال الرسالة', 'vnx' ); ?></button>
			</form>
		</div>
	</div>
	<?php
	return ob_get_clean();
}