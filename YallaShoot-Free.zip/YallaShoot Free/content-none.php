<section class="no-results not-found">
	<header class="page-header">
		<span class="page-title p-2 d-flex"><?php esc_html_e( 'لا يوجد شي ','vnx'); ?></span>
	</header>

	<p><?php _e('يبدو أنه لا يوجد أي شئ هنا. جرب أحد الروابط الموجودة في الأسفل أو استخدم أداة البحث.','vnx');?></p>
   
</section>
