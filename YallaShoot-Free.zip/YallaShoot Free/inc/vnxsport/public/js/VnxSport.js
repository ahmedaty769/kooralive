"use strict";

var vnxsport_bx = jQuery.noConflict();

vnxsport_bx(function (t) {
    var a = {};

    t(function () {
        a.fixture_tabs();
        a.timezone_converter();
        a.fixture_events();
        a.match_servers();
        a.matches_slider();
    });

    a.fixture_events = function (selector = "") {
        moment.tz.setDefault(VnxSport.Timezone);

        t(selector + ".AF_WithTimmer").each(function () {
            var e = t(this),
                s = e.find(".AF_Timer"),
                i = e.data("start"),
                o = moment(i, "YYYY-MM-DD HH:mm"),
                n = moment(i, "YYYY-MM-DD HH:mm").add(2, "hours"),
                l = moment.tz(VnxSport.Timezone).format("YYYY-MM-DD HH:mm"),
                r = o.diff(l, "minutes"),
                d = n.diff(l, "minutes"),
                mask = e.find(".AF_MaskText");

            e.removeClass("not-started comming-soon live finished ended");
            s.removeClass("comming-soon live ended");

            switch (true) {
                case 30 < r:
                    e.addClass("not-started");
                    s.html("لم تبدأ بعد");
                    mask.html("لم تبدأ بعد");
                    break;

                case 0 < r:
                    e.addClass("comming-soon");
                    s.addClass("comming-soon").html("بعد قليل");
                    mask.html("بعد قليل");
                    break;

                case 0 < d:
                    e.addClass("live");
                    s.addClass("live").html(VnxSport.Live);
                    mask.html(VnxSport.Show);
                    break;

                default:
                    e.addClass("finished");
                    s.addClass("ended").html(VnxSport.Finished);
                    mask.html(VnxSport.FinMatch);
                    break;
            }
        });
    };

    a.timezone_converter = function () {
        moment.tz.setDefault(VnxSport.Timezone);

        t("select#change_timezone").on("change", function () {
            var timezone = t(this).val();

            t.each(t(".AF_EvItem"), function () {
                var start = t(this).data("start");

                t(this)
                    .find(".AF_EvTime")
                    .text(moment(start, "YYYY-MM-DD HH:mm").tz(timezone).format(VnxSport.Timeformat));

                t(this)
                    .find(".match-data .asp-city")
                    .text(t("select#change_timezone option:selected").attr("rel"));
            });
        });
    };

    a.fixture_tabs = function () {
        t(document).on("click", ".VnxSportFixture button.tablinks", function () {
            var btn = t(this),
                target = btn.data("target"),
                wrapper = btn.closest(".VnxSportFixture");

            btn.addClass("active").siblings().removeClass("active");
            wrapper.find(".AF_Contents .AF_TabCon").hide();
            wrapper.find(target).fadeIn();

            return false;
        });
    };

    a.matches_slider = function () {
        var options = {
            item: 3,
            slideMove: 1,
            slideMargin: 5,
            rtl: true,
            responsive: [
                { breakpoint: 1440, settings: { item: 3 } },
                { breakpoint: 1200, settings: { item: 3 } },
                { breakpoint: 992, settings: { item: 2 } },
                { breakpoint: 680, settings: { item: 1 } }
            ],
            onAfterSlide: function () {}
        };

        t(".AspMatchSlider").each(function () {
            var s = t(this).closest(".AspTopSliderMatch"),
                i = t(this).lightSlider(options),
                o = t(s.find(".aspwp-ajaxLoad"));

            t(s).on("click", ".gotoDay", function (n) {
                n.preventDefault();

                var l = t(this).data("day"),
                    r = s.find(".AspMatchSlider");

                t(this).addClass("active").siblings().removeClass("active");
                t(".gotoDay").addClass("asp-disabled");
                o.addClass("show");

                if (i.lightSlider) {
                    i.destroy();
                }

                t.ajax({
                    type: "POST",
                    dataType: "html",
                    url: VnxSport.ajaxurl,
                    data: {
                        action: "aspwp_getmatches",
                        day: l
                    },
                    success: function (response) {
                        o.removeClass("show");

                        if (response == 0) {
                            r.html('<p class="nomatchinslide">' + VnxSport.NoMatches + "</p>")
                                .removeClass("opacity");
                        } else {
                            r.html(response);

                            if (!i.lightSlider) {
                                i = r.lightSlider(options);
                            }

                            a.fixture_events(".AspMatchSlider ");
                        }
                    },
                    complete: function () {
                        t(".gotoDay").removeClass("asp-disabled");
                    }
                });
            });
        });
    };

    a.match_servers = function () {
        t(document).on("click", ".aspwp-server-ajax a[data-asp-id]", function (ev) {
            ev.preventDefault();

            var e = t(this),
                s = e.data("asp-live"),
                i = e.data("asp-id"),
                o = e.closest(".aspwp-match-servers").find(".asp-server-body");

            e.addClass("active").siblings().removeClass("active");

            o.html('<div class="aspwp-ajaxLoad red show"><div class="asp-dot-flashing"></div></div>');

            t.ajax({
                type: "POST",
                dataType: "html",
                url: VnxSport.ajaxurl,
                data: {
                    action: "load-match",
                    live: s,
                    id: i
                },
                success: function (response) {
                    o.html(response).show();
                    return false;
                }
            });
        });
    };
});