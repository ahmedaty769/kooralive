
/**
 *
 * -----------------------------------------------------------
 *
 * VnxSport
 *
 * -----------------------------------------------------------
 *
 */
(function( $, window, document, undefined ) {
    'use strict';
  
    //
    // Constants
    //
    var ASPWP   = ASPWP || {};
  
    ASPWP.funcs = {};
  
    ASPWP.VARS  = {
      onloaded: false,
      $body: $('body'),
      $window: $(window),
      $document: $(document),
      $form_warning: null,
      is_confirm: false,
      form_modified: false,
      code_themes: [],
      is_rtl: $('body').hasClass('rtl'),
    };
  
    //
    // Helper Functions
    //
    ASPWP.HELPER = {
  
      //
      // Generate UID
      //
      uid: function( prefix ) {
        return ( prefix || '' ) + Math.random().toString(36).substr(2, 9);
      },
  
      // Quote regular expression characters
      //
      preg_quote: function( str ) {
        return (str+'').replace(/(\[|\])/g, "\\$1");
      },
  
      //
      // Reneme input names
      //
      name_nested_replace: function( $selector, field_id ) {
  
        var checks = [];
        var regex  = new RegExp(ASPWP.HELPER.preg_quote(field_id +'[\\d+]'), 'g');
  
        $selector.find(':radio').each(function() {
          if ( this.checked || this.orginal_checked ) {
            this.orginal_checked = true;
          }
        });
  
        $selector.each( function( index ) {
          $(this).find(':input').each(function() {
            this.name = this.name.replace(regex, field_id +'['+ index +']');
            if ( this.orginal_checked ) {
              this.checked = true;
            }
          });
        });
  
      },
  
      //
      // Debounce
      //
      debounce: function( callback, threshold, immediate ) {
        var timeout;
        return function() {
          var context = this, args = arguments;
          var later = function() {
            timeout = null;
            if ( !immediate ) {
              callback.apply(context, args);
            }
          };
          var callNow = ( immediate && !timeout );
          clearTimeout( timeout );
          timeout = setTimeout( later, threshold );
          if ( callNow ) {
            callback.apply(context, args);
          }
        };
      },
  
    };
  
  
  
      //
    // Options Navigation
    //
    $.fn.aspwp_nav_options = function() {
      return this.each( function() {
  
        var $nav    = $(this),
            $window = $(window),
            $wpwrap = $('#wpwrap'),
            $links  = $nav.find('a'),
            $last;
  
        $window.on('hashchange vnx.hashchange', function() {
  
          var hash  = window.location.hash.replace('#tab=', '');
          var slug  = hash ? hash : $links.first().attr('href').replace('#tab=', '');
          var $link = $('[data-tab-id="'+slug+'"]');
  
          if ( $link.length ) {
  
            $link.closest('.aspwp-menu-item').addClass('aspwp-tab-expanded').siblings().removeClass('aspwp-tab-expanded');
  
            if( $link.next().is('ul') ) {
  
              $link = $link.next().find('li').first().find('a');
              slug  = $link.data('tab-id');
  
            }
  
            $links.removeClass('aspwp-active');
            $link.addClass('aspwp-active');
  
            if ( $last ) {
              $last.addClass('hidden');
            }
  
            var $section = $('[data-section-id="'+slug+'"]');
  
            $section.removeClass('hidden').siblings().addClass('hidden');
            $section.aspwp_reload_script();
  
            $('.aspwp-section-id').val( $section.index()+1 );
  
            $last = $section;
  
            if ( $wpwrap.hasClass('wp-responsive-open') ) {
              $('html, body').animate({scrollTop:($section.offset().top-50)}, 200);
              $wpwrap.removeClass('wp-responsive-open');
            }
  
          }
          if(hash == 'shortcodes'){
            $('#aspwp-form #major-publishing-actions .button').hide();
          }else{
            $('#aspwp-form #major-publishing-actions .button').show();
          }
        }).trigger('vnx.hashchange');
      });
    };
  
    //
    // Custom clone for textarea and select clone() bug
    //
    $.fn.aspwp_clone = function() {
  
      var base   = $.fn.clone.apply(this, arguments),
          clone  = this.find('select').add(this.filter('select')),
          cloned = base.find('select').add(base.filter('select'));
  
      for( var i = 0; i < clone.length; ++i ) {
        for( var j = 0; j < clone[i].options.length; ++j ) {
  
          if ( clone[i].options[j].selected === true ) {
            cloned[i].options[j].selected = true;
          }
  
        }
      }
  
      this.find(':radio').each( function() {
        this.orginal_checked = this.checked;
      });
  
      return base;
  
    };
  
  
      //
    // Customize Refresh
    //
    $.fn.aspwp_customizer_refresh = function() {
      return this.each( function() {
  
        var $this    = $(this),
            $complex = $this.closest('.aspwp-customize-complex');
  
        if ( $complex.length ) {
  
         var unique_id = $complex.data('unique-id');
  
          if ( unique_id === undefined ) {
            return;
          }
  
          var $input    = $complex.find(':input'),
              option_id = $complex.data('option-id'),
              obj       = $input.serializeObjectALBA(),
              data      = ( ! $.isEmptyObject(obj) && obj[unique_id] && obj[unique_id][option_id] ) ? obj[unique_id][option_id] : '',
              control   = window.wp.customize.control(unique_id +'['+ option_id +']');
  
          // clear the value to force refresh.
          control.setting._value = null;
  
          control.setting.set( data );
  
        } else {
  
          $this.find(':input').first().trigger('change');
  
        }
  
        $(document).trigger('aspwp-customizer-refresh', $this);
  
      });
    };
  
     //
    // Customize Listen Form Elements
    //
    $.fn.aspwp_customizer_listen = function( options ) {
  
      var settings = $.extend({
        closest: false,
      }, options );
  
      return this.each( function() {
  
        if ( window.wp.customize === undefined ) { return; }
  
        var $this     = ( settings.closest ) ? $(this).closest('.aspwp-customize-complex') : $(this),
            $input    = $this.find(':input'),
            unique_id = $this.data('unique-id'),
            option_id = $this.data('option-id');
  
        if ( unique_id === undefined ) {
          return;
        }
  
        $input.on('change keyup vnx.change', function() {
  
          var obj = $this.find(':input').serializeObjectALBA();
          var val = ( !$.isEmptyObject(obj) && obj[unique_id] && obj[unique_id][option_id] ) ? obj[unique_id][option_id] : '';
  
          window.wp.customize.control( unique_id +'['+ option_id +']' ).setting.set( val );
  
        });
  
      });
    };
    
  
      //
    // WP Color Picker
    //
    $.fn.aspwp_color = function() {
      return this.each( function() {
        $(this).wpColorPicker();
      });
    };
  
  
    //
    // Field: upload
    //
    $.fn.aspwp_field_upload = function() {
      return this.each( function() {
  
        var $this          = $(this),
            $input         = $this.find('input'),
            $upload_button = $this.find('.aspwp--button'),
            $remove_button = $this.find('.aspwp--remove'),
            $preview_wrap  = $this.find('.aspwp--preview'),
            $preview_src   = $this.find('.aspwp--src'),
            $library       = $upload_button.data('library') && $upload_button.data('library').split(',') || '',
            wp_media_frame;
  
        $upload_button.on('click', function( e ) {
  
          e.preventDefault();
  
          if ( typeof window.wp === 'undefined' || ! window.wp.media || ! window.wp.media.gallery ) {
            return;
          }
  
          if ( wp_media_frame ) {
            wp_media_frame.open();
            return;
          }
  
          wp_media_frame = window.wp.media({
            library: {
              type: $library
            },
          });
  
          wp_media_frame.on( 'select', function() {
  
            var src;
            var attributes = wp_media_frame.state().get('selection').first().attributes;
  
            if ( $library.length && $library.indexOf(attributes.subtype) === -1 && $library.indexOf(attributes.type) === -1 ) {
              return;
            }
  
            $input.val(attributes.url).trigger('change');
  
          });
  
          wp_media_frame.open();
  
        });
  
        $remove_button.on('click', function( e ) {
          e.preventDefault();
          $input.val('').trigger('change');
        });
  
        $input.on('change', function( e ) {
  
          var $value = $input.val();
  
          if ( $value ) {
            $remove_button.removeClass('hidden');
          } else {
            $remove_button.addClass('hidden');
          }
  
          if ( $preview_wrap.length ) {
  
            if ( $.inArray( $value.split('.').pop().toLowerCase(), ['jpg', 'jpeg', 'gif', 'png', 'svg', 'webp'] ) !== -1 ) {
              $preview_wrap.removeClass('hidden');
              $preview_src.attr('src', $value);
            } else {
              $preview_wrap.addClass('hidden');
            }
  
          }
  
        });
  
      });
  
    };
  
      //
    // Dependency System
    //
    $.fn.aspwp_dependency = function() {
      return this.each( function() {
  
        var $this   = $(this),
            $fields = $this.children('[data-controller]');
  
        if( $fields.length ) {
  
          var normal_ruleset = $.aspwp_deps.createRuleset(),
              global_ruleset = $.aspwp_deps.createRuleset(),
              normal_depends = [],
              global_depends = [];
  
          $fields.each( function() {
  
            var $field      = $(this),
                controllers = $field.data('controller').split('|'),
                conditions  = $field.data('condition').split('|'),
                values      = $field.data('value').toString().split('|'),
                is_global   = $field.data('depend-global') ? true : false,
                ruleset     = ( is_global ) ? global_ruleset : normal_ruleset;
  
            $.each(controllers, function( index, depend_id ) {
  
              var value     = values[index] || '',
                  condition = conditions[index] || conditions[0];
  
              ruleset = ruleset.createRule('[data-depend-id="'+ depend_id +'"]', condition, value);
  
              ruleset.include($field);
  
              if ( is_global ) {
                global_depends.push(depend_id);
              } else {
                normal_depends.push(depend_id);
              }
  
            });
  
          });
  
          if ( normal_depends.length ) {
            $.aspwp_deps.enable($this, normal_ruleset, normal_depends);
          }
  
          if ( global_depends.length ) {
            $.aspwp_deps.enable(ASPWP.VARS.$body, global_ruleset, global_depends);
          }
  
        }
  
      });
    };
    
      //
    // Field: repeater
    //
    $.fn.aspwp_field_repeater = function() {
      return this.each( function() {
  
        var $this     = $(this),
            $fieldset = $this.children('.aspwp-fieldset'),
            $repeater = $fieldset.length ? $fieldset : $this,
            $wrapper  = $repeater.find('.aspwp-repeater-wrapper'),
            $hidden   = $repeater.find('.aspwp-repeater-hidden'),
            $max      = $repeater.find('.aspwp-repeater-max'),
            $min      = $repeater.find('.aspwp-repeater-min'),
            field_id  = $wrapper.data('field-id'),
            max       = parseInt( $wrapper.data('max') ),
            min       = parseInt( $wrapper.data('min') );
  
        $wrapper.find('.aspwp-repeater-item').find('.aspwp-repeater-content').aspwp_reload_script();
  
  
        var update_title_numbers = function( $selector ) {
          $selector.find('.aspwp-repeater-sort').each( function( index ) {
            $(this).html( ( $(this).closest('.aspwp-repeater-item').index()+1 ));
          });
        };
  
  
        $wrapper.sortable({
          items: '> tr',
          handle: '> td.order',
          forceHelperSize: true,
          forcePlaceholderSize: true,
          scroll: true,
          stop: function (event, ui) {
            let update_order_numbers = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
            // Update order number.
            if (update_order_numbers) {
              $wrapper.find('.aspwp-repeater-item').each(function (i) {
                $(this).find('> .order > span').html(i + 1);
              });
            }
          },
          update: function( event, ui ) {
  
            update_title_numbers($wrapper);
  
            ASPWP.HELPER.name_nested_replace( $wrapper.children('.aspwp-repeater-item'), field_id );
            $wrapper.aspwp_customizer_refresh();
  
          }
        });
  
        $repeater.find('.aspwp-repeater-add').on('click', function( e ) {
  
          e.preventDefault();
  
          var count = $wrapper.find('.aspwp-repeater-item').length;
  
          $min.hide();
  
          if ( max && (count+1) > max ) {
            $max.show();
            return;
          }
  
          var $cloned_item = $hidden.aspwp_clone(true);
  
          $cloned_item.removeClass('aspwp-repeater-hidden');
  
          $cloned_item.find(':input[name!="_pseudo"]').each( function() {
            this.name = this.name.replace( '___', '' ).replace( field_id +'[0]', field_id +'['+ count +']' );
          });
  
          $wrapper.append($cloned_item);
          $cloned_item.find('.aspwp-repeater-content').aspwp_reload_script();
          $wrapper.aspwp_customizer_refresh();
          $wrapper.aspwp_customizer_listen({closest: true});
  
          update_title_numbers($wrapper);
  
  
        });
  
        var event_clone = function( e ) {
  
          e.preventDefault();
  
          var count = $wrapper.children('.aspwp-repeater-item').length;
  
          $min.hide();
  
          if ( max && (count+1) > max ) {
            $max.show();
            return;
          }
  
          
  
          var $this           = $(this),
              $parent         = $this.parent().parent(),
              $handle         = $parent.find('.aspwp-row-handle').aspwp_clone(),
              $cloned_content = $parent.find('.aspwp-repeater-content').aspwp_clone(),
              $cloned_helper  = $parent.find('.aspwp-repeater-helper').aspwp_clone(true),
              $cloned_item    = $('<tr class="aspwp-repeater-item" />');
  
          $cloned_item.append($handle);
          $cloned_item.append($cloned_content);
          $cloned_item.append($cloned_helper);
  
          $wrapper.children().eq($parent.index()).after($cloned_item);
  
          $cloned_item.children('.aspwp-repeater-content').aspwp_reload_script();
  
          ASPWP.HELPER.name_nested_replace( $wrapper.find('.aspwp-repeater-item'), field_id );
  
          $wrapper.aspwp_customizer_refresh();
          $wrapper.aspwp_customizer_listen({closest: true});
  
          update_title_numbers($wrapper);
  
        };
  
        $wrapper.find('.aspwp-repeater-item').find('.aspwp-repeater-helper').on('click', '.aspwp-repeater-clone', event_clone);
        $repeater.find('.aspwp-repeater-hidden').find('.aspwp-repeater-helper').on('click', '.aspwp-repeater-clone', event_clone);
  
        var event_remove = function( e ) {
  
          e.preventDefault();
  
          var count = $wrapper.find('.aspwp-repeater-item').length;
  
          $max.hide();
          $min.hide();
  
          if ( min && (count-1) < min ) {
            $min.show();
            return;
          }
  
          $(this).closest('.aspwp-repeater-item').remove();
  
          ASPWP.HELPER.name_nested_replace( $wrapper.find('.aspwp-repeater-item'), field_id );
  
          $wrapper.aspwp_customizer_refresh();
          update_title_numbers($wrapper);
  
        };
  
        $wrapper.find('.aspwp-repeater-item').find('.aspwp-repeater-helper').on('click', '.aspwp-repeater-remove', event_remove);
        $repeater.find('.aspwp-repeater-hidden').find('.aspwp-repeater-helper').on('click', '.aspwp-repeater-remove', event_remove);
  
      });
    };
  
  
  
      //
    // Field: date
    //
    $.fn.aspwp_field_date = function() {
      return this.each( function() {
        var $this    = $(this),
        $inputs     = $this.find('input[type="hidden"]'),
        $inputText  = $this.find('input[type="text"]'),
        settings    = $this.find('.aspwp-date-settings').data('settings');
        // args
        var defaults = {
          dateFormat: 'MM d, yy',
          altField: $inputs,
          altFormat: 'yymmdd',
          changeYear: true,
          yearRange: '-100:+100',
          changeMonth: true,
          showButtonPanel: true,
          isRTL     : ASPWP.VARS.is_rtl,
          controlType : "select",
          firstDay : 6,
        };
        settings = $.extend({}, settings, defaults);
        $inputText.each( function() {
          var $inputTe = $(this);
          $inputTe.datepicker(settings);
        });
  
                // wrap the datepicker (only if it hasn't already been wrapped)
        if( $('body > #ui-datepicker-div').length ) {
          $('body > #ui-datepicker-div').wrap('<div class="aspwp-ui-datepicker" />');
        }
  
      });
    };
  
  
      //
    // Field: datetime
    //
    $.fn.aspwp_field_datetime = function() {
      return this.each( function() {
  
        var $this    = $(this),
            $inputs     = $this.find('input[type="hidden"]'),
            $inputText  = $this.find('input[type="text"]'),
            settings = $this.find('.aspwp-datetime-settings').data('settings');
  
            var defaults = {
              controlType       : "select",
              isRTL             : ASPWP.VARS.is_rtl,
              altField          : $inputs,
              timeFormat        : 'hh:mm TT',
              altTimeFormat     : 'HH:mm',
              altFieldTimeOnly  : true,
              changeMonth       : true,
              showButtonPanel   : true,
              oneLine           : true,
              changeYear        : true,
              yearRange         : "-100:+100",
            };
  
            settings = $.extend({}, settings, defaults);
  
  
          $inputText.each( function() {
            $(this).timepicker(settings);
          });
  
      });
    };
  
  
    
      //
    // ChosenJS
    //
    $.fn.aspwp_chosen = function() {
      return this.each( function() {
  
        var $this       = $(this),
            is_ajax     = $this.hasClass('aspwp-chosen-ajax') || false,
            set_options = $.extend({
              allow_single_deselect: true,
              disable_search_threshold: 10,
              width: '100%',
              no_results_text: window.aspwp_vars.i18n.no_results_text,
            }, $this.data('chosen-settings'));
  
        // Chosen ajax
        if ( is_ajax ) {
          var set_ajax_options = $.extend({
            ajax: {
              url: ajaxurl,
              dataType: 'json',
              delay : 250,
              type  : "POST",
              data: function (params) {
                var query = {
                  action: 	'aspwp_select',
                  s: 			  params.term || '',
                  paged: 		params.page || 1
                }
                // Query parameters will be ?search=[term]&type=public
                return query;
              },
              processResults: function (data) {          
                return {
                    results: data.results,
                    pagination: {
                        more: data.more
                    }
                };
              },
              cache: true
    
            },
            placeholder: 'Search for a repository',
    
            
          }, set_options);
  
          $this.select2(set_ajax_options);
          
          
        } else {
  
          $this.select2(set_options);
  
        }
        
  
      });
    };
    
      //
    // Option Framework
    //
    $.fn.aspwp_options = function() {
      return this.each( function() {
  
        var $this         = $(this),
            $content      = $this.find('.aspwp-content'),
            $form_success = $this.find('.aspwp-form-success'),
            $form_warning = $this.find('.aspwp-form-warning'),
            $save_button  = $this.find('.aspwp-header .aspwp-save');
  
        ASPWP.VARS.$form_warning = $form_warning;
  
        // Shows a message white leaving theme options without saving
        if ( $form_warning.length ) {
  
          window.onbeforeunload = function() {
            return ( ASPWP.VARS.form_modified ) ? true : undefined;
          };
  
          $content.on('change keypress', ':input', function() {
            if ( !ASPWP.VARS.form_modified ) {
              $form_success.hide();
              $form_warning.fadeIn('fast');
              ASPWP.VARS.form_modified = true;
            }
          });
  
        }
  
        if ( $form_success.hasClass('aspwp-form-show') ) {
          setTimeout( function() {
            $form_success.fadeOut('fast');
          }, 1000);
        }
  
        $(document).keydown(function (event) {
          if ( ( event.ctrlKey || event.metaKey ) && event.which === 83 ) {
            $save_button.trigger('click');
            event.preventDefault();
            return false;
          }
        });
  
      });
    };
  
  
  
      //
    // Widgets Framework
    //
    $.fn.aspwp_widgets = function() {
      return this.each( function() {
  
        $(document).on('widget-added widget-updated', function( event, $widget ) {
  
          var $fields = $widget.find('.aspwp-fields');
  
          if ( $fields.length ) {
            $fields.aspwp_reload_script();
          }
  
        });
  
        $(document).on('click', '.widget-top', function( event ) {
  
          var $fields = $(this).parent().find('.aspwp-fields');
  
          if ( $fields.length ) {
            $fields.aspwp_reload_script();
          }
  
        });
  
      });
    };
  
      //
    // Options Save
    //
    $.fn.aspwp_save = function() {
      return this.each( function() {
  
        var $this    = $(this),
            $buttons = $('.aspwp-save'),
            $panel   = $('.aspwp-options'),
            $placeholder   = $('.aspwp-placeholder'),
            $aspwp_saving   = $('#aspwp-saving-settings'),
            
            flooding = false,
            timeout;
  
        $this.on('click', function( e ) {
  
          $aspwp_saving.removeClass("aspwp-is-success aspwp-is-failed");
          $placeholder.show();
          if ( !flooding ) {
  
            var $text  = $this.data('save'),
                $value = $this.val();
  
            $buttons.attr('value', $text);
  
            if ( $this.hasClass('aspwp-save-ajax') ) {
  
              e.preventDefault();
  
              $panel.addClass('aspwp-saving');
              $buttons.prop('disabled', true);
  
              window.wp.ajax.post( 'aspwp_ajax_save', {
                data: $('#aspwp-form').serializeJSONALBA()
              })
              .done( function( response ) {
  
                // clear errors
                $('.aspwp-error').remove();
  
                if ( Object.keys( response.errors ).length ) {
  
  
                  $aspwp_saving.addClass("aspwp-is-failed").delay(1e3), setTimeout(function() {
                    $placeholder.fadeOut()
                  }, 1200);
  
                  var error_icon = '<i class="aspwp-label-error aspwp-error">!</i>';
  
                  $.each(response.errors, function( key, error_message ) {
  
                    var $field = $('[data-depend-id="'+ key +'"]'),
                        $link  = $('a[href="#tab='+ $field.closest('.aspwp-section').data('section-id') +'"]' ),
                        $tab   = $link.closest('.aspwp-menu-item');
  
                    $field.closest('.aspwp-fieldset').append( '<p class="aspwp-error aspwp-error-text">'+ error_message +'</p>' );
  
                    if ( !$link.find('.aspwp-error').length ) {
                      $link.append( error_icon );
                    }
  
                    if ( !$tab.find('.aspwp-arrow .aspwp-error').length ) {
                      $tab.find('.aspwp-arrow').append( error_icon );
                    }
  
                  });
  
                }
  
                $panel.removeClass('aspwp-saving');
                $buttons.prop('disabled', false).attr('value', $value);
                flooding = false;
  
                ASPWP.VARS.form_modified = false;
                ASPWP.VARS.$form_warning.hide();
  
                clearTimeout(timeout);
  
                $aspwp_saving.addClass("aspwp-is-success").delay(1e3), setTimeout(function() {
                  $placeholder.fadeOut()
                }, 1200)
  
                var $result_success = $('.aspwp-form-success');
                $result_success.empty().append(response.notice).fadeIn('fast', function() {
                  timeout = setTimeout( function() {
                    $result_success.fadeOut('fast');
                  }, 1000);
                });
  
              })
              .fail( function( response ) {
                $panel.removeClass('aspwp-saving');
                $buttons.prop('disabled', false).attr('value', $value);
                $aspwp_saving.addClass("aspwp-is-failed").delay(1e3), setTimeout(function() {
                  $placeholder.fadeOut()
                }, 1200);
              });
  
            } else {
  
              ASPWP.VARS.form_modified = false;
  
            }
  
          }
  
          flooding = true;
  
        });
  
      });
    };
  
  
  
    //

//
    // Reload Plugins
    //
    $.fn.aspwp_reload_script = function( options ) {
  
      var settings = $.extend({
        dependency: true,
      }, options );
  
      return this.each( function() {
  
        var $this = $(this);
  
        // Avoid for conflicts
        if ( !$this.data('inited') ) {
  
          $this.children('.aspwp-field-upload').aspwp_field_upload();
          $this.children('.aspwp-field-repeater').aspwp_field_repeater();
          $this.children('.aspwp-field-date').aspwp_field_date();
          $this.children('.aspwp-field-datetime').aspwp_field_datetime();
          $this.children('.aspwp-field-color').find('.aspwp-color').aspwp_color();
          // Field chosenjs
          $this.children('.aspwp-field-select').find('.aspwp-chosen').aspwp_chosen();
          
          if ( settings.dependency ) {
            $this.aspwp_dependency();
          }
          $this.data('inited', true);
          $(document).trigger('aspwp-reload-script', $this);
  
        }
  
      });
    };
  
  
  
  
      //
    // Document ready and run scripts
    //
    $(document).ready( function() {
      $('.aspwp-save').aspwp_save();
      $('.aspwp-options').aspwp_options();
      $('.aspwp-nav').aspwp_nav_options();
      $('.aspwp-onload').aspwp_reload_script();
      $('#widgets-editor').aspwp_widgets();
      $('#widgets-right').aspwp_widgets();
    
  
  
      jQuery('.aspwp-toggle-select').each(function() {
        var $thisElement = jQuery(this),
          $val = $thisElement.val(),
          toggleItems = $thisElement.data('aspwp-toggle');
          jQuery(toggleItems).hide();
          jQuery(".aspwp-tok-"+$val).slideDown('fast');
          $thisElement.change(function() {
  
           jQuery(toggleItems).slideUp('fast');
           jQuery(".aspwp-tok-"+jQuery(this).val()).slideDown('fast');
          });
        
      })
    
  
  
      $('[data-section-id="shortcodes"]').on('keyup change paste', 'input, select', function(){
  
        
        var table_title     = jQuery("#shortcode_title").val();
        var tabs_type       = jQuery("#shortcode_tabs_type").val();
        var matches_day     = jQuery("#shortcode_mday").val();
        var yesterday_url   = jQuery("#shortcode_ysurl").val();
        var today_url       = jQuery("#shortcode_tdurl").val();
        var tomorrow_url    = jQuery("#shortcode_tmurl").val();
        var limit           = jQuery("#matches_limit").val();
  
          
          
          var dayss = {
            yesterday : jQuery("#yesterday").is(':checked')  ?  '' : ' yesterday="0"',
            today     : jQuery("#today").is(':checked')      ?  '' : ' today="0"',
            tomorrow  : jQuery("#tomorrow").is(':checked')   ?  '' : ' tomorrow="0"',
            has_title : jQuery("#has_title").is(':checked')  ?  '' : ' show_title="0"',
            timezone  : jQuery("#timezone").is(':checked')   ?  '' : ' show_timezone="0"',
          };
  
  
          
          $.each(dayss, function(key, value) {
              if(value == ''){
                jQuery('[data-target="#'+key+'"]').show();
              }else{
                jQuery('[data-target="#'+key+'"]').hide();
              }
          });
  
       
          
  
          var days = dayss.yesterday+dayss.today+dayss.tomorrow+dayss.has_title+dayss.timezone;
  
          var aspwp_builder = jQuery("#shortcode_bulder_type").val();
  
          
  
          jQuery('[data-target="#'+matches_day+'"]').addClass('active').siblings().removeClass('active');
  
  
  
          jQuery(".VnxSportFixture .AF_Title .asp-title").text(table_title);
     
          
          var table_title = table_title != '' ?  ' title="'+table_title+'"' : '';
          var match_limit = limit != '' ?  ' limit="'+limit+'"' : '';
          var aspwp_dark_style  = jQuery("#aspwp_dark_style").is(':checked') ?  ' dark_style="1"' : '';
          var small_style = jQuery("#small_style").is(':checked') ?  ' type="small"' : '';
  
            if(aspwp_dark_style == ' dark_style="1"'){
              jQuery('.VnxSportFixture,.AspTopSliderMatch').addClass('aspwp_dark_style');
            }else{
              jQuery('.VnxSportFixture,.AspTopSliderMatch').removeClass('aspwp_dark_style');
  
            }
            if(small_style == ' type="small"'){
              jQuery('.VnxSportFixture').addClass('small').find('.AspMatchItem').show();
              jQuery('.VnxSportFixture').find('.AF_EvItem').hide();
            }else{
              jQuery('.VnxSportFixture').removeClass('small').find('.AF_EvItem').show();
              jQuery('.VnxSportFixture').find('.AspMatchItem').hide();
            }
          
  
            if(aspwp_builder == 'table'){
              jQuery('#aspwp_dark_style-field').removeClass('aspwp-100').addClass('aspwp-50');
  
  
              if(tabs_type == 'tabs'){
                jQuery("#builder__composed").val(`[VnxSportTable${days}${table_title}${match_limit}${aspwp_dark_style}${small_style} matches_day="${matches_day}" ]`);
              }else{
                jQuery('[data-controller="tabs_type"]').slideDown('fast');
                jQuery("#builder__composed").val(`[VnxSportTable${days}${table_title}${match_limit}${aspwp_dark_style}${small_style} tabs_type="${tabs_type}" matches_day="${matches_day} yesterday_url="${yesterday_url}" today_url="${today_url}" tomorrow_url="${tomorrow_url}"]`);
              }
            }else if(aspwp_builder == 'slider'){
              jQuery('#aspwp_dark_style-field').removeClass('aspwp-50').addClass('aspwp-100');
              jQuery('[data-controller="tabs_type"]').slideUp('fast');
              jQuery("#builder__composed").val(`[VnxSportSlider${days}${match_limit}${aspwp_dark_style} matches_day="${matches_day}"]`);
            }else{
  
            }
         
  
            
          
            
  
  
      });
  
  
  
  
      jQuery("body").on("click", ".aspfaq_item > .aspfaq_question", function () {
        var card 	= jQuery(this).closest(".aspfaq_item");
        var sblngs  = card.siblings(".aspfaq_item");
        card.toggleClass('aspfaq_item_active'),
        sblngs.removeClass('aspfaq_item_active');
    });
    
      
    });
  
  })( jQuery, window, document );
  