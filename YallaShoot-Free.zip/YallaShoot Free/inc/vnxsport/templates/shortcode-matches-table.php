<?php
/**
 * The Template for displaying Matches.
 *
 * This template can be overridden by copying it to yourtheme/VnxSport/shortcode-matches.php.
 *
 * @var object|array $data Object with widget data.
 *
 * @author   VNX Web <vnxweb.com>
 * @package  VnxSport/Templates
 * @since    0.4.3
 * @version  0.15.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Normalize builder/settings keys to template keys.
 */
$data = (array) ( $data ?? [] );

// العنوان.
if ( isset( $data['shortcode_title'] ) && ! isset( $data['title'] ) ) {
	$data['title'] = $data['shortcode_title'];
}

// عرض العنوان.
if ( isset( $data['has_title'] ) && ! isset( $data['show_title'] ) ) {
	$data['show_title'] = $data['has_title'];
}

// اليوم الافتراضي المعروض.
if ( isset( $data['shortcode_mday'] ) && ! isset( $data['matches_day'] ) ) {
	$data['matches_day'] = $data['shortcode_mday'];
}

// نوع التبويب.
if ( isset( $data['shortcode_tabs_type'] ) && ! isset( $data['tabs_type'] ) ) {
	$data['tabs_type'] = $data['shortcode_tabs_type'];
}

// روابط الأيام.
if ( isset( $data['shortcode_ysurl'] ) && ! isset( $data['yesterday_url'] ) ) {
	$data['yesterday_url'] = $data['shortcode_ysurl'];
}
if ( isset( $data['shortcode_tdurl'] ) && ! isset( $data['today_url'] ) ) {
	$data['today_url'] = $data['shortcode_tdurl'];
}
if ( isset( $data['shortcode_tmurl'] ) && ! isset( $data['tomorrow_url'] ) ) {
	$data['tomorrow_url'] = $data['shortcode_tmurl'];
}

// عدد المباريات.
if ( isset( $data['matches_limit'] ) && ! isset( $data['limit'] ) ) {
	$data['limit'] = $data['matches_limit'];
}

// الوضع الصغير.
if ( ! empty( $data['small_style'] ) && empty( $data['type'] ) ) {
	$data['type'] = 'small';
}

// تأكيد قيم أزرار التفعيل/التعطيل.
$bool_like_keys = [ 'show_title', 'yesterday', 'today', 'tomorrow', 'small_style' ];
foreach ( $bool_like_keys as $bool_key ) {
	if ( isset( $data[ $bool_key ] ) ) {
		$data[ $bool_key ] = (string) $data[ $bool_key ] === '0' ? '0' : '1';
	}
}

$data = (object) wp_parse_args(
	$data,
	[
		'title'         => __( 'أهم مباريات اليوم', 'vnx' ),
		'style'         => '',
		'type'          => '',
		'show_timezone' => '1',
		'show_title'    => '1',
		'matches_day'   => 'today',
		'tabs_type'     => 'tabs',
		'yesterday_url' => '',
		'today_url'     => '',
		'tomorrow_url'  => '',
		'yesterday'     => '1',
		'today'         => '1',
		'tomorrow'      => '1',
		'dark_style'    => '',
		'limit'         => '',
		'widget_pos'    => '',
	]
);

$tabs_days = [
	[
		'slug'  => 'yesterday',
		'name'  => __( 'الأمس', 'vnx' ),
		'curnt' => ( $data->matches_day === 'yesterday' ),
		'url'   => $data->yesterday_url,
	],
	[
		'slug'  => 'today',
		'name'  => __( 'اليوم', 'vnx' ),
		'curnt' => ( $data->matches_day === '' || $data->matches_day === 'today' ),
		'url'   => $data->today_url,
	],
	[
		'slug'  => 'tomorrow',
		'name'  => __( 'الغد', 'vnx' ),
		'curnt' => ( $data->matches_day === 'tomorrow' ),
		'url'   => $data->tomorrow_url,
	],
];

$day_titles = [
	'yesterday' => __( 'أهم مباريات الأمس', 'vnx' ),
	'today'     => __( 'أهم مباريات اليوم', 'vnx' ),
	'tomorrow'  => __( 'أهم مباريات الغد', 'vnx' ),
];

$current_day_slug  = in_array( $data->matches_day, [ 'yesterday', 'today', 'tomorrow' ], true ) ? $data->matches_day : 'today';
$current_day_title = $day_titles[ $current_day_slug ];

$today_ts = current_time( 'timestamp' );

$match_day_labels = [
	'yesterday' => __( 'أهم مباريات الأمس', 'vnx' ),
	'today'     => __( 'أهم مباريات اليوم', 'vnx' ),
	'tomorrow'  => __( 'أهم مباريات الغد', 'vnx' ),
];

$current_nav_day_title = $match_day_labels[ $current_day_slug ];

/**
 * Hook: aspwp/tmpl-match/before_table
 */
do_action( 'aspwp/tmpl-match/before_table' );

$widget_pos  = in_array( $data->widget_pos, [ 'sidebar', 'primary-widget-area', 'post_side', 'sidebar_widget', 'archive_widget' ], true ) ? 'small' : '';
$item_layout = ( $data->type === 'small' || $widget_pos === 'small' ) ? 'small' : 'table';
$is_small    = ( $item_layout === 'small' );
$dark_style  = ! empty( $data->dark_style ) ? ' ' . (string) $data->dark_style : '';
$wrapp_class = trim(
	(string) $data->style . ' ' .
	(string) $data->type .
	$dark_style . ' ' .
	$widget_pos . ' ' .
	(string) $data->widget_pos
);

$instance_id = 'aspwp-fixture-' . wp_unique_id();

/**
 * Helper: extract league name from table layout HTML.
 */
$get_league_name_from_html = static function ( $html ) {
	$league_name = __( 'بطولة غير معروفة', VNXSPORT_TEXTDOMAIN );

	if ( preg_match( '/<span[^>]*class=(["\'])[^"\']*\bcup\b[^"\']*\1[^>]*>(.*?)<\/span>/is', $html, $cup_match ) ) {
		$extracted_name = trim( wp_strip_all_tags( $cup_match[2] ) );

		if ( $extracted_name !== '' ) {
			$league_name = $extracted_name;
		}
	}

	return $league_name;
};

/**
 * Helper: extract data attribute from HTML.
 */
$get_data_attr_from_html = static function ( $html, $attr_name, $default = '' ) {
	$pattern = '/data-' . preg_quote( (string) $attr_name, '/' ) . '=(["\'])(.*?)\1/is';

	if ( preg_match( $pattern, $html, $match ) ) {
		return trim( wp_strip_all_tags( $match[2] ) );
	}

	return $default;
};

$default_timezone = function_exists( 'AspwpOption' ) ? AspwpOption( 'VnxSportTimezon' ) : 'Africa/Cairo';
$timzone_list     = function_exists( 'AspwpOption' ) ? AspwpOption( 'VnxSportTimezonList' ) : [];
$timzone_list     = is_array( $timzone_list ) ? $timzone_list : [];

$selected_timezone = $default_timezone;

if ( ! empty( $selected_timezone ) && ! in_array( $selected_timezone, $timzone_list, true ) ) {
	array_unshift( $timzone_list, $selected_timezone );
	$timzone_list = array_unique( $timzone_list );
}

$current_timezone_city = 'القاهرة';
if ( class_exists( 'Vnx_Sport_Plugin' ) && method_exists( Vnx_Sport_Plugin()->helper, 'get_l10n_city' ) ) {
	$current_timezone_city = Vnx_Sport_Plugin()->helper->get_l10n_city( $selected_timezone );
}
?>

<div class="tmz-name timezone-dropdown">
	<select id="change_timezone" name="change_timezone" class="timezone-native-select" style="display:none;">
		<?php foreach ( $timzone_list as $timzone ) : ?>
			<?php
			$city_name = $timzone;
			if ( class_exists( 'Vnx_Sport_Plugin' ) && method_exists( Vnx_Sport_Plugin()->helper, 'get_l10n_city' ) ) {
				$city_name = Vnx_Sport_Plugin()->helper->get_l10n_city( $timzone );
			}
			?>
			<option
				value="<?php echo esc_attr( $timzone ); ?>"
				rel="<?php echo esc_attr( 'بتوقيت ' . $city_name ); ?>"
				<?php selected( $selected_timezone, $timzone ); ?>
			>
				<?php echo esc_html( 'بتوقيت ' . $city_name ); ?>
			</option>
		<?php endforeach; ?>
	</select>

	<details class="timezone-details">
		<summary class="timezone-summary">
			<span class="timezone-summary-text"><?php echo esc_html( 'بتوقيت ' . $current_timezone_city ); ?></span>
		</summary>

		<div class="timezone-menu">
			<?php foreach ( $timzone_list as $timzone ) : ?>
				<?php
				$city_name = $timzone;
				if ( class_exists( 'Vnx_Sport_Plugin' ) && method_exists( Vnx_Sport_Plugin()->helper, 'get_l10n_city' ) ) {
					$city_name = Vnx_Sport_Plugin()->helper->get_l10n_city( $timzone );
				}
				?>
				<label class="timezone-option">
					<input
						type="radio"
						name="change_timezone_fake"
						value="<?php echo esc_attr( $timzone ); ?>"
						data-label="<?php echo esc_attr( 'بتوقيت ' . $city_name ); ?>"
						<?php checked( $selected_timezone, $timzone ); ?>
					>
					<span><?php echo esc_html( 'بتوقيت ' . $city_name ); ?></span>
				</label>
			<?php endforeach; ?>
		</div>
	</details>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
	const TZ_KEY = 'vnxsport_timezone';

	const wrap = document.querySelector('.tmz-name.timezone-dropdown');
	if (!wrap) return;

	const select = wrap.querySelector('#change_timezone');
	const summary = wrap.querySelector('.timezone-summary-text');
	const details = wrap.querySelector('.timezone-details');
	const radios = Array.from(wrap.querySelectorAll('input[name="change_timezone_fake"]'));

	const defaultTimezone = '<?php echo esc_js( $selected_timezone ); ?>';

	const getSavedTimezone = () => {
		const saved = localStorage.getItem(TZ_KEY);
		return saved || defaultTimezone;
	};

	const updateSummaryText = (timezoneValue) => {
		if (!summary) return;

		const activeRadio = radios.find(radio => radio.value === timezoneValue);
		if (activeRadio) {
			summary.textContent = activeRadio.dataset.label || activeRadio.nextElementSibling.textContent.trim();
			return;
		}

		if (select) {
			const option = Array.from(select.options).find(opt => opt.value === timezoneValue);
			if (option) {
				summary.textContent = option.getAttribute('rel') || option.textContent.trim();
			}
		}
	};

	const syncUI = (timezoneValue) => {
		if (select) {
			const exists = Array.from(select.options).some(opt => opt.value === timezoneValue);
			if (exists) {
				select.value = timezoneValue;
			}
		}

		radios.forEach(radio => {
			radio.checked = (radio.value === timezoneValue);
		});

		updateSummaryText(timezoneValue);
	};

	const saveTimezone = (timezoneValue) => {
		localStorage.setItem(TZ_KEY, timezoneValue);
		document.cookie = 'vnxsport_timezone=' + encodeURIComponent(timezoneValue) + '; path=/; max-age=' + (60 * 60 * 24 * 30);

		syncUI(timezoneValue);

		if (select) {
			select.value = timezoneValue;
			select.dispatchEvent(new Event('change', { bubbles: true }));
		}

		document.dispatchEvent(new CustomEvent('vnxsport:timezoneChanged', {
			detail: { timezone: timezoneValue }
		}));

		if (details) {
			details.removeAttribute('open');
		}
	};

	radios.forEach(radio => {
		radio.addEventListener('change', function () {
			if (!this.checked) return;
			saveTimezone(this.value);
		});
	});

	if (select) {
		select.addEventListener('change', function () {
			localStorage.setItem(TZ_KEY, this.value);
			document.cookie = 'vnxsport_timezone=' + encodeURIComponent(this.value) + '; path=/; max-age=' + (60 * 60 * 24 * 30);
			syncUI(this.value);
		});
	}

	syncUI(getSavedTimezone());
});
</script>

<div id="<?php echo esc_attr( $instance_id ); ?>" class="home_vnxweb VnxSportFixture asp-font <?php echo esc_attr( $wrapp_class ); ?>">

	<?php if ( $data->show_timezone !== '0' || $data->show_title !== '0' || $is_small ) : ?>
		<div class="AF_Title asp-align-center asp-d-flex asp-font AF_Title_With_Filter">
			<div id="yp-table-nav" class="AF_TableNav">
				<?php if ( $data->show_title !== '0' ) : ?>
					<h2 id="<?php echo esc_attr( $instance_id ); ?>-title" class="asp-title asp-font vnx-btn"><?php echo esc_html( $current_day_title ); ?></h2>
				<?php endif; ?>

				<div class="yp-table-control AF_TableNav_Control">
					<div class="yp-table-days AF_TableNav_Days AF_TableNav_Days_Tabs">
						<?php if ( $data->yesterday !== '0' ) : ?>
							<button
								type="button"
								class="AF_TableNav_DayBtn<?php echo $current_day_slug === 'yesterday' ? ' active' : ''; ?> yesterday"
								data-day-option="yesterday"
							>
								<?php echo esc_html__( 'مباريات الأمس', 'vnx' ); ?>
							</button>
						<?php endif; ?>

						<?php if ( $data->today !== '0' ) : ?>
							<button
								type="button"
								class="AF_TableNav_DayBtn<?php echo $current_day_slug === 'today' ? ' active' : ''; ?> today"
								data-day-option="today"
							>
								<?php echo esc_html__( 'مباريات اليوم', 'vnx' ); ?>
							</button>
						<?php endif; ?>

						<?php if ( $data->tomorrow !== '0' ) : ?>
							<button
								type="button"
								class="AF_TableNav_DayBtn<?php echo $current_day_slug === 'tomorrow' ? ' active' : ''; ?> tomorrow"
								data-day-option="tomorrow"
							>
								<?php echo esc_html__( 'مباريات الغد', 'vnx' ); ?>
							</button>
						<?php endif; ?>
					</div>
				</div>

				<span id="yp-table-day" style="display:none;"><?php echo esc_html( $current_nav_day_title ); ?></span>
			</div>

			<div class="tab AF_Filters asp-d-flex" style="display:none;">
				<?php
				foreach ( $tabs_days as $tab ) :
					if ( ( $data->{$tab['slug']} ?? '1' ) === '0' ) {
						continue;
					}

					$tab_target_id = $instance_id . '-' . $tab['slug'];
					$target        = ( $data->tabs_type === 'links' )
						? 'href="' . esc_url( $tab['url'] ) . '"'
						: 'data-target="#' . esc_attr( $tab_target_id ) . '"';
					$tag           = ( $data->tabs_type === 'links' ) ? 'a' : 'button';
					$active_class  = $tab['curnt'] ? ' active' : '';

					$left_arrow = '
						<svg class="tab-arrow tab-arrow-right" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
							<path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
							<polyline points="9 6 15 12 9 18"></polyline>
						</svg>';

					$right_arrow = '
						<svg class="tab-arrow tab-arrow-left" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
							<path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
							<polyline points="15 6 9 12 15 18"></polyline>
						</svg>';

					$label = '';

					if ( $tab['slug'] === 'yesterday' ) {
						$label = $left_arrow . '<span>' . esc_html( $tab['name'] ) . '</span>';
					} elseif ( $tab['slug'] === 'tomorrow' ) {
						$label = '<span>' . esc_html( $tab['name'] ) . '</span>' . $right_arrow;
					} else {
						$label = '<span>' . esc_html( $tab['name'] ) . '</span>';
					}

					echo '<' . $tag . ' class="asp-flex asp-font tablinks custom-tab-btn' . esc_attr( $active_class ) . '" data-day="' . esc_attr( $tab['slug'] ) . '" ' . $target . '>' . $label . '</' . $tag . '>';
				endforeach;
				?>
			</div>
		</div>
	<?php endif; ?>

	<div class="AF_Contents">
		<?php
		do_action( 'aspwp/tmpl-match/before_table_content' );

		$count       = 0;
		$match_count = ( ! empty( $data->limit ) && $data->limit !== '0' ) ? $data->limit : '-1';

		foreach ( $tabs_days as $content ) :
			$count++;

			if ( ( $data->{$content['slug']} ?? '1' ) === '0' && ! $content['curnt'] ) {
				continue;
			}

			$selected_day   = ( $data->tabs_type === 'links' ) ? $data->matches_day : $content['slug'];
			$active         = ( $content['curnt'] || $data->tabs_type === 'links' ) ? ' active' : '';
			$tab_content_id = $instance_id . '-' . $content['slug'];
			?>
			<div id="<?php echo esc_attr( $tab_content_id ); ?>" class="AF_TabCon<?php echo esc_attr( $active ); ?>">
				<?php
				$matches = Vnx_Sport_Plugin()->match->get_matches_by_day( $selected_day, $match_count );

				if ( empty( $matches ) ) :
					?>
					<div class="AF_matches_Row">
						<div class="AF_EvItem">
							<div class="AF_NoData">
								<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50">
									<path d="M-119.131,20h-41.249a1.376,1.376,0,0,0-1.375,1.375h0V51.625A1.376,1.376,0,0,0-160.381,53h41.249a1.376,1.376,0,0,0,1.375-1.375h0V21.375A1.376,1.376,0,0,0-119.131,20Zm-19.249,11.2a5.473,5.473,0,0,1,3.959,6.651,5.473,5.473,0,0,1-3.959,3.959Zm-20.625,0a5.473,5.473,0,0,1,3.959,6.651,5.473,5.473,0,0,1-3.959,3.959Zm17.875,10.61a5.473,5.473,0,0,1-3.959-6.651A5.473,5.473,0,0,1-141.13,31.2Zm0-13.431a8.241,8.241,0,0,0-6.759,9.494,8.24,8.24,0,0,0,6.759,6.759v5.623h-17.877V44.626a8.241,8.241,0,0,0,6.759-9.494,8.242,8.242,0,0,0-6.759-6.759V22.751h17.875Zm20.625,13.431a5.473,5.473,0,0,1-3.959-6.651,5.472,5.472,0,0,1,3.959-3.959Zm0-13.431a8.241,8.241,0,0,0-6.759,9.494,8.24,8.24,0,0,0,6.759,6.759v5.623h-17.875V44.626a8.241,8.241,0,0,0,6.759-9.494,8.242,8.242,0,0,0-6.759-6.759V22.751h17.874Z" transform="translate(163.877 -10.379)" fill="#64748b"></path>
									<line x2="44.5" y2="44" transform="translate(2.121 4.121)" fill="none" stroke="#64748b" stroke-linecap="round" stroke-width="3"></line>
								</svg>
								<p class="AF_Msg"><?php echo esc_html__( 'لا توجد مباريات لهذا اليوم', VNXSPORT_TEXTDOMAIN ); ?></p>
							</div>
						</div>
					</div>
<?php
				else :
					$flat_matches = [];

					foreach ( $matches as $match ) :
						ob_start();
						Vnx_Sport_Plugin()->load_partial( $match, 'loops/loop-match-' . $item_layout );
						$match_html = (string) ob_get_clean();

						if ( strpos( $match_html, 'AF_EvItem' ) === false && strpos( $match_html, 'AspMatchItem' ) !== false ) {
							$match_html = (string) preg_replace(
								'/class=(["\'])([^"\']*\bAspMatchItem\b[^"\']*)\1/',
								'class=$1$2 AF_EvItem$1',
								$match_html,
								1
							);
						}

						ob_start();
						Vnx_Sport_Plugin()->load_partial( $match, 'loops/loop-match-table' );
						$helper_html = (string) ob_get_clean();

						$match_data = (object) wp_parse_args(
							is_object( $match ) ? get_object_vars( $match ) : (array) $match,
							[
								'competition'  => '',
								'status_class' => '',
								'status_meta'  => '',
								'status_title' => '',
							]
						);

						$league_name = ! empty( $match_data->competition )
							? trim( wp_strip_all_tags( (string) $match_data->competition ) )
							: $get_league_name_from_html( $helper_html );

						if ( $league_name === '' ) {
							$league_name = __( 'بطولة غير معروفة', VNXSPORT_TEXTDOMAIN );
						}

						$match_html = (string) preg_replace(
							'/<span[^>]*class=(["\'])[^"\']*\bcup\b[^"\']*\1[^>]*>.*?<\/span>/is',
							'',
							$match_html,
							1
						);

						$match_important = $get_data_attr_from_html( $match_html, 'important', 'all' );
						$match_start     = $get_data_attr_from_html( $match_html, 'start', '' );
						$match_timestamp = $match_start !== '' ? strtotime( $match_start ) : 0;
						$group_key       = sanitize_title( $league_name );

						if ( $group_key === '' ) {
							$group_key = md5( $league_name );
						}

						$raw_status_class = strtolower( trim( (string) $match_data->status_class ) );
						$raw_status_meta  = strtolower( trim( (string) $match_data->status_meta ) );
						$raw_status_title = strtolower( trim( wp_strip_all_tags( (string) $match_data->status_title ) ) );
						$plain_match_html = strtolower( trim( wp_strip_all_tags( (string) $match_html ) ) );

						$match_status = 'unknown';

						if (
							in_array( $raw_status_class, [ 'live', 'inplay', 'playing' ], true ) ||
							in_array( $raw_status_meta, [ 'live', 'inplay', 'playing' ], true ) ||
							mb_strpos( $plain_match_html, 'مباش' ) !== false
						) {
							$match_status = 'live';
						} elseif (
							in_array( $raw_status_class, [ 'soon', 'starting_soon', 'comming-soon', 'coming-soon' ], true ) ||
							in_array( $raw_status_meta, [ 'soon', 'starting_soon', 'comming-soon', 'coming-soon' ], true ) ||
							mb_strpos( $raw_status_title, 'بعد قليل' ) !== false ||
							mb_strpos( $plain_match_html, 'بعد قليل' ) !== false
						) {
							$match_status = 'soon';
						} elseif (
							in_array( $raw_status_class, [ 'not_started', 'not-started', 'ns', 'scheduled', 'fixture', 'upcoming', 'comming' ], true ) ||
							in_array( $raw_status_meta, [ 'not_started', 'not-started', 'ns', 'scheduled', 'fixture', 'upcoming', 'comming' ], true )
						) {
							$match_status = 'not_started';
						} elseif (
							in_array( $raw_status_class, [ 'ended', 'finish', 'finished', 'ft', 'aft', 'fulltime' ], true ) ||
							in_array( $raw_status_meta, [ 'ended', 'ended_penalty', 'finished', 'ft', 'aft', 'fulltime' ], true ) ||
							mb_strpos( $plain_match_html, 'انته' ) !== false
						) {
							$match_status = 'ended';
						} elseif ( $match_timestamp > 0 ) {
							$now_ts = current_time( 'timestamp' );
							$diff   = $match_timestamp - $now_ts;

							if ( $diff > 0 && $diff <= 3600 ) {
								$match_status = 'soon';
							} elseif ( $diff > 3600 ) {
								$match_status = 'not_started';
							}
						}

						$status_order_map = [
							'live'        => 1,
							'soon'        => 2,
							'not_started' => 2,
							'ended'       => 3,
							'unknown'     => 4,
						];

						$status_order = $status_order_map[ $match_status ] ?? 4;

						$wrapped_match_html  = '<div class="AF_Filter_Match"';
						$wrapped_match_html .= ' data-league="' . esc_attr( $league_name ) . '"';
						$wrapped_match_html .= ' data-league-key="' . esc_attr( $group_key ) . '"';
						$wrapped_match_html .= ' data-important="' . esc_attr( $match_important ) . '"';
						$wrapped_match_html .= ' data-start="' . esc_attr( $match_start ) . '"';
						$wrapped_match_html .= ' data-ts="' . esc_attr( (string) ( $match_timestamp ?: 0 ) ) . '"';
						$wrapped_match_html .= ' data-status="' . esc_attr( $match_status ) . '"';
						$wrapped_match_html .= '>';
						$wrapped_match_html .= $match_html;
						$wrapped_match_html .= '</div>';

						$flat_matches[] = [
							'html'         => $wrapped_match_html,
							'ts'           => (int) ( $match_timestamp ?: 0 ),
							'league'       => $league_name,
							'match_status' => $match_status,
							'status_order' => $status_order,
						];
					endforeach;

					usort(
						$flat_matches,
						static function ( $a, $b ) {
							$status_compare = (int) $a['status_order'] <=> (int) $b['status_order'];

							if ( 0 !== $status_compare ) {
								return $status_compare;
							}

							return (int) $a['ts'] <=> (int) $b['ts'];
						}
					);
					?>

					<div class="AF_ListViewWrap">
						<div class="AF_matches_Row AF_Time_Matches">
							<?php
							foreach ( $flat_matches as $flat_match ) {
								echo $flat_match['html'];
							}
							?>
						</div>

						<div class="AF_Filter_Empty" style="display:none;">
							<div class="AF_EvItem">
								<div class="AF_NoData">
									<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50">
										<path d="M-119.131,20h-41.249a1.376,1.376,0,0,0-1.375,1.375h0V51.625A1.376,1.376,0,0,0-160.381,53h41.249a1.376,1.376,0,0,0,1.375-1.375h0V21.375A1.376,1.376,0,0,0-119.131,20Zm-19.249,11.2a5.473,5.473,0,0,1,3.959,6.651,5.473,5.473,0,0,1-3.959,3.959Zm-20.625,0a5.473,5.473,0,0,1,3.959,6.651,5.473,5.473,0,0,1-3.959,3.959Zm17.875,10.61a5.473,5.473,0,0,1-3.959-6.651A5.473,5.473,0,0,1-141.13,31.2Zm0-13.431a8.241,8.241,0,0,0-6.759,9.494,8.24,8.24,0,0,0,6.759,6.759v5.623h-17.877V44.626a8.241,8.241,0,0,0,6.759-9.494,8.242,8.242,0,0,0-6.759-6.759V22.751h17.875Zm20.625,13.431a5.473,5.473,0,0,1-3.959-6.651,5.472,5.472,0,0,1,3.959-3.959Zm0-13.431a8.241,8.241,0,0,0-6.759,9.494,8.24,8.24,0,0,0,6.759,6.759v5.623h-17.875V44.626a8.241,8.241,0,0,0,6.759-9.494,8.242,8.242,0,0,0-6.759-6.759V22.751h17.874Z" transform="translate(163.877 -10.379)" fill="#64748b"></path>
										<line x2="44.5" y2="44" transform="translate(2.121 4.121)" fill="none" stroke="#64748b" stroke-linecap="round" stroke-width="3"></line>
									</svg>
									<p class="AF_Msg"><?php echo esc_html__( 'لا توجد مباريات', VNXSPORT_TEXTDOMAIN ); ?></p>
								</div>
							</div>
						</div>
					</div>

				<?php endif; ?>
			</div>
			<?php
			if ( $data->tabs_type === 'links' && $count === 1 ) {
				break;
			}
		endforeach;

		do_action( 'aspwp/tmpl-match/after_table_content' );
		?>
	</div>
</div>

<script>
(function(){
var root=document.getElementById('<?php echo esc_js( $instance_id ); ?>');
if(!root)return;

var titleEl=document.getElementById('<?php echo esc_js( $instance_id ); ?>-title'),
	navDayEl=root.querySelector('#yp-table-day');

var dayTitles={
		yesterday:'<?php echo esc_js( $day_titles['yesterday'] ); ?>',
		today:'<?php echo esc_js( $day_titles['today'] ); ?>',
		tomorrow:'<?php echo esc_js( $day_titles['tomorrow'] ); ?>'
	},
	dayOrder=['yesterday','today','tomorrow'].filter(function(day){
		return !!root.querySelector('.AF_TableNav_DayBtn[data-day-option="'+day+'"]') || !!root.querySelector('.tablinks[data-day="'+day+'"]') || !!root.querySelector('#<?php echo esc_js( $instance_id ); ?>-'+day);
	}),
	state={status:'all',important:'all'},
	TOP_TEAM_KEYWORDS=['real madrid','ريال مدريد','barcelona','fc barcelona','برشلونة','liverpool','ليفربول','arsenal','أرسنال','chelsea','تشيلسي','manchester city','مانشستر سيتي','manchester united','مانشستر يونايتد','psg','باريس سان جيرمان','juventus','يوفنتوس','inter','إنتر','milan','ميلان','bayern munich','بايرن ميونخ','borussia dortmund','بوروسيا دورتموند','al hilal','الهلال','al nassr','النصر','al ittihad','الاتحاد','al ahli','الأهلي'],
	TOP_COUNTRY_KEYWORDS=['egypt','مصر','spain','إسبانيا','france','فرنسا','england','إنجلترا','brazil','البرازيل','argentina','الأرجنتين','germany','ألمانيا','italy','إيطاليا','portugal','البرتغال','morocco','المغرب'];

function updateMainTitle(day){
	if(titleEl){
		var customTitle='<?php echo esc_js( ! empty( $data->title ) ? $data->title : '' ); ?>';
		titleEl.textContent=customTitle || dayTitles[day] || dayTitles.today;
	}
}
function updateNavTitle(day){
	if(navDayEl){
		navDayEl.textContent=dayTitles[day]||dayTitles.today;
	}
}
function normalizeText(text){return(text||'').toString().toLowerCase().replace(/[\u064B-\u065F\u0670]/g,'').replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي').replace(/[^\w\u0600-\u06FF\s\/&-]+/g,' ').replace(/\s+/g,' ').trim()}
function textContainsAny(text,keywords){for(var i=0;i<keywords.length;i++){var keyword=normalizeText(keywords[i]);if(keyword&&text.indexOf(keyword)!==-1)return true}return false}
function getClassesArray(el){return!el||!el.classList?[]:Array.prototype.slice.call(el.classList).map(function(cls){return(cls||'').toLowerCase()})}
function arrayHasAny(list,values){return values.some(function(value){return list.indexOf(value)!==-1})}
function getStatusFromClass(item){var statusEl=item.querySelector('.asps-status.AF_Timer')||item.querySelector('.asps-status')||item.querySelector('.AF_Timer');if(!statusEl)return'';var classes=getClassesArray(statusEl);if(arrayHasAny(classes,['live','inplay','in_play','playing','1h','2h','ht','et','aet','pen']))return'live';if(arrayHasAny(classes,['soon','starting_soon','starting-soon']))return'soon';if(arrayHasAny(classes,['not_started','not-started','ns','scheduled','fixture','upcoming']))return'not_started';if(arrayHasAny(classes,['ended','finish','finished','ft','aft','fulltime']))return'ended';return''}
function getStatusFromTime(item){var tsValue=parseInt(item.getAttribute('data-ts')||'0',10),nowTs=Math.floor(Date.now()/1000);if(!tsValue||isNaN(tsValue))return'';var diff=tsValue-nowTs;if(diff>0&&diff<=3600)return'soon';if(diff>3600)return'not_started';return''}
function getMatchStatus(item){return getStatusFromClass(item)||getStatusFromTime(item)||'unknown'}
function isImportantMatch(item){var leagueText=normalizeText(item.getAttribute('data-league')||''),itemText=normalizeText(item.textContent||''),fullText=(leagueText+' '+itemText).trim();return textContainsAny(fullText,TOP_TEAM_KEYWORDS)||textContainsAny(fullText,TOP_COUNTRY_KEYWORDS)}
function isMatchVisible(item){var status=getMatchStatus(item),important=isImportantMatch(item),statusOk=state.status==='all'||status===state.status,importantOk=state.important==='all'||state.important==='important'&&important||state.important==='not_important'&&!important;return statusOk&&importantOk}
function applyFilters(){root.querySelectorAll('.AF_TabCon').forEach(function(tab){var list=tab.querySelector('.AF_Time_Matches'),emptyBox=tab.querySelector('.AF_Filter_Empty');if(!list)return;var visibleCount=0;list.querySelectorAll('.AF_Filter_Match').forEach(function(item){var show=isMatchVisible(item);item.style.display=show?'':'none';if(show)visibleCount++});if(emptyBox)emptyBox.style.display=visibleCount>0?'none':''})}

function activateTargetTab(day){
	root.querySelectorAll('.AF_TabCon').forEach(function(tab){
		tab.classList.remove('active');
	});
	var targetTab=root.querySelector('#<?php echo esc_js( $instance_id ); ?>-'+day);
	if(targetTab){
		targetTab.classList.add('active');
		return true;
	}
	return false;
}

function switchToDay(day){
	if(dayOrder.indexOf(day)===-1)return;

	if('<?php echo esc_js( $data->tabs_type ); ?>'==='links'){
		var linkBtn=root.querySelector('.tablinks[data-day="'+day+'"]');
		if(linkBtn){
			var href=linkBtn.getAttribute('href');
			if(href){
				window.location.href=href;
				return;
			}
		}
	}

	activateTargetTab(day);

	root.querySelectorAll('.AF_TableNav_DayBtn').forEach(function(btn){
		btn.classList.remove('active');
	});

	var activeNavBtn=root.querySelector('.AF_TableNav_DayBtn[data-day-option="'+day+'"]');
	if(activeNavBtn){
		activeNavBtn.classList.add('active');
	}

	root.querySelectorAll('.tablinks[data-day]').forEach(function(btn){
		btn.classList.remove('active');
		btn.setAttribute('aria-selected','false');
	});

	var targetBtn=root.querySelector('.tablinks[data-day="'+day+'"]');
	if(targetBtn){
		targetBtn.classList.add('active');
		targetBtn.setAttribute('aria-selected','true');
	}

	updateMainTitle(day);
	updateNavTitle(day);
	applyFilters();
}

updateMainTitle('<?php echo esc_js( $current_day_slug ); ?>');
updateNavTitle('<?php echo esc_js( $current_day_slug ); ?>');

root.querySelectorAll('.AF_TableNav_DayBtn[data-day-option]').forEach(function(btn){
	btn.addEventListener('click', function(e){
		e.preventDefault();
		var day=btn.getAttribute('data-day-option')||'today';
		switchToDay(day);
	});
});

root.querySelectorAll('.tablinks[data-day]').forEach(function(tabBtn){
	tabBtn.addEventListener('click',function(e){
		var day=tabBtn.getAttribute('data-day')||'today';
		if('<?php echo esc_js( $data->tabs_type ); ?>'!=='links'){
			e.preventDefault();
			switchToDay(day);
		}
	});
});

applyFilters();
})();
</script>

<?php
/**
 * Hook: aspwp/tmpl-match/after_table
 */
do_action( 'aspwp/tmpl-match/after_table' );