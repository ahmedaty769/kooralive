<?php
/**
 * The Template for displaying Match content.
 * Content only (without comments).
 *
 * This template can be overridden by copying it to yourtheme/vnxsport-template/content-matches.php.
 *
 * @author        VNX Web <vnxweb.com>
 * @package       VnxSport/Templates
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
// phpcs:disable WordPress.NamingConventions

$match_post = get_post();
/**
 * Hook: aspwp/tmpl-match/before_wrapper
 *
 * @since 0.0.1
 *
 * @param WP_Post $match_post
 */
do_action( 'aspwp/tmpl-match/before_wrapper', $match_post );
?>
<div class="asp-match-inner">
	<?php

	// Get match data to render
	$data = Vnx_Sport_Plugin()->match->prepare_match_data_to_render($match_post->ID,(array) $match_post, true );
	
	/**
	 * Filter: aspwp/tmpl-match/render_header
	 *
	 * @param WP_Post $match_post
	 */

	$match_card =  AspwpOption('MatchCard') ? true : false ;
	if ( apply_filters( 'aspwp/tmpl-match/render_match_card', $match_card)  ) {
	
		$card_style 	  =  in_array(AspwpOption('MatchCardType'),['simple','dark']) ? '-simple' : '' ;
		Vnx_Sport_Plugin()->load_partial( $data, 'match/match-card'.$card_style );

	}
	$match_sections = [
		'content',
		'info',
	];

	?>
	
	<div class="asp-match-content">

	<?php 
	
	/**
	 * Filter: aspwp/tmpl-match/sections
	 *
	 * @since 0.0.1
	 *
	 * @param array   $match_sections
	 * @param array   $data
	 * @param WP_Post $match_post
	 */
	$match_sections = apply_filters( 'aspwp/tmpl-match/sections', $match_sections, $data, $match_post );
	
	foreach ( $match_sections as $section ) {

		switch ( $section ) {
				case 'content':
					$data->post_content  = $match_post->post_content;
					Vnx_Sport_Plugin()->load_partial($data, 'match/match-content' );
				break;
			default:
				Vnx_Sport_Plugin()->load_partial( $data, 'match/match-' . sanitize_key( $section ) );
		}
	}
	?>
	</div>
</div>
<?php
/**
 * Hook: aspwp/tmpl-match/after_wrapper
 *
 * @since 0.0.1
 *
 * @param WP_Post $match_post
 */
do_action( 'aspwp/tmpl-match/after_wrapper', $match_post );

