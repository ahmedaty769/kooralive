<?php
/**
 * The Template for displaying Match card simple.
 *
 * This template can be overridden by copying it to yourtheme/vnxsport-template/match/match-card-simple.php.
 *
 * @var object $data - Object with args.
 *
 * @author        VNX Web <vnxweb.com>
 * @package       VnxSport/Templates
 *
 * @version       0.0.1
 */

 if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$data  = (object) wp_parse_args(
    $data,[
        'match_id'          => '',
        'kickoff'           => '',
        'match_time'    	=> '',
        'home_name'         => '',
        'away_name'         => '',
        'home_logo'         => '',
        'away_logo'         => '',
        'home_goals'        => '',
        'away_goals'        => '',
        'home_penalty'  	=> '',
        'away_penalty'  	=> '',
        'status_meta'       => '',
        'status_id'         => '',
        'competition'      	=> '',
        'commentator'      	=> '',
        'channel_name'      => '',
    
    ]
);


$wrapp_class  =  ' aspwp_'.AspwpOption('MatchCardType').'_style'; ;

/**
 * Hook: aspwp/tmpl-match/before_match_card
 *
 */
do_action( 'aspwp/tmpl-match/before_match_card');
?>
<div class="VnxSportCard AspSimpleCard match-status__<?php echo esc_attr( $data->status_meta.$wrapp_class ); ?>">
<?php $bg = get_template_directory_uri() . '/img/champ-light-bg.svg'; ?>

<style>
.asp-scoreboard {
    background: url('<?php echo esc_url($bg); ?>') no-repeat center center #e3e5f0;
}

html.dark .asp-scoreboard {
    background: url('<?php echo esc_url($bg); ?>') no-repeat center center #191c2a;
}
</style>

<div class="asp-scoreboard">	
     <div class="AC_Inner">
		<div class="AC_FTeam card_AF_FTeam">
			<div class="AC_TeamImg">
				<?php if ( $data->home_logo ) : ?>
					<img loading="lazy" width="80" height="80" src="<?php echo esc_url( $data->home_logo ); ?>" alt="<?php echo esc_attr( $data->home_name ); ?>">
				<?php endif; ?>
			</div>
			<span class="AC_TeamTitle asp-font">
				<?php echo esc_html( $data->home_name ); ?>
			</span>
		</div>
		<div class="AC_Data">
			<div class="AC_Result">
				<div class="asp-flex">
				<span class="AC_Score">
						<?php echo esc_html( $data->home_goals ); ?>
					</span>
				<span class="AC_Separator">:
				</span>
				<span class="AC_Score">
					<?php echo esc_html( $data->away_goals ); ?>
				</span>
				</div>
				<?php  if ($data->status_meta  == 'ended_penalty') : ?>
					<div class="AF_EvPenalty">
						<div class="AF_PenResult">
							<span class="score"><?php echo $data->home_penalty;?></span>
							<span class="name"><?php  echo __( 'Penalties', VNXSPORT_TEXTDOMAIN );?></span>
							<span class="score"><?php echo $data->away_penalty;?></span>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<div class="AC_FTeam AC_Team">
			<div class="AC_TeamImg">
				<?php if ( $data->away_logo ) : ?>
					<img loading="lazy" width="80" height="80" src="<?php echo esc_url( $data->away_logo ); ?>" alt="<?php echo esc_attr( $data->away_name ); ?>">
				<?php endif; ?>
			</div>         
			<div class="AC_TeamTitle asp-font">
				<?php echo esc_html( $data->away_name ); ?> 
			</div>
		</div>
		</div>

   </div>
   <?php do_action( 'aspwp/match/match-header-bottom', $data->match_id, $data );?>
</div>
<?php 
/**
 * Hook: aspwp/tmpl-match/after_match_card
 *
 */
do_action( 'aspwp/tmpl-match/after_match_card');