<?php
  get_header();
  ?>
<div class="vnx-archive row">
  <section id="primary" class="content-area col">
    <main id="main" class="site-main box">
      <?php if ( have_posts() ) : ?>
      <h1 class="pasge-title mb-2">
        <?php
          printf( esc_html__( 'نتائج البحث عن: %s','vnx'), '<span>' . get_search_query() . '</span>' );
          ?>
      </h1>
<div id="ap-articles-wrap" class="ap-news-list">
               <?php while (have_posts()): the_post();?>
        <article id="post-<?php the_ID();?>" class="ap-news-card">
        
           <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
        
        <div class="ap-thumb">
            <?php if ( has_post_thumbnail() ) : ?>
                <img 
                    width="800" 
                    height="450" 
                    src="<?php the_post_thumbnail_url('medium');?>" 
                    alt="<?php the_title_attribute(); ?>" 
                    class="attachment-large size-large wp-post-image"
                    decoding="async"
                >
            <?php endif; ?>
        </div>

        <div class="ap-card-content">
            <h3 class="ap-title">
                <?php the_title(); ?>
            </h3>

            <p class="ap-excerpt">
                <?php echo wp_trim_words( get_the_excerpt(), 12, '…' ); ?>
            </p>

            <div class="ap-time">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="9"></circle>
                    <polyline points="12 7 12 12 15 15"></polyline>
                </svg>
                <span><?php echo get_the_date('Y-m-d'); ?></span>
            </div>
        </div>
    </a>
    
        </article>
        
        
        <?php endwhile;?>
        <?php
          if (function_exists("VnxSport_pagination")) { VnxSport_pagination(); } ;
          
          else :
          
          get_template_part( 'content', 'none' );
          
          endif;
          ?>
      </div>
    </main>
  </section>
</div>
<?php
get_footer();