<!DOCTYPE html>
<html <?php language_attributes(); ?>>
   <head>
      <meta charset="<?php bloginfo( 'charset' ); ?>">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="profile" href="https://gmpg.org/xfn/11">
<style>
    @font-face {
    font-family: 'VnxWebFonts';
    src: url('<?php echo get_template_directory_uri(); ?>/fonts/NeoSansArabic.woff2') format('woff2');
    font-weight: 400;
    font-style: normal;
    font-display: swap;
}
</style>
      <?php if ( AspwpOption('VnxSportStyle') === 'dark_style' ) : ?>
      <script>
         document.documentElement.classList.add("dark");
      </script>
      <?php endif; ?>

      <?php wp_head(); ?>
   </head>

   <?php
   $bdclss = is_rtl() ? 'Vnx-rtl' : 'Vnx-ltr';

   $hide_header_search   = function_exists( 'AspwpOption' ) ? AspwpOption( 'hide_header_search' ) : '0';
   $hide_header_settings = function_exists( 'AspwpOption' ) ? AspwpOption( 'hide_header_settings' ) : '0';
   ?>

   <body <?php body_class( $bdclss ); ?>>

      <header id="VnxSport_header">
         <div class="container">
            <div class="header_inn d-flex align-items-center">
<button 
    class="navbar-toggler ml-0 order-lg-3"
    onclick="document.getElementById('site-navigation').classList.add('open')"
    type="button"
    id="toggle-menu"
    aria-label="فتح القائمة">
    
    <span class="navbar-toggler-icon">
        <i class="mobmnicon"></i>
    </span>
</button>

<?php
$logo_type  = function_exists('AspwpOption') ? AspwpOption('logo_type') : 'image';
$site_title = function_exists('AspwpOption') && AspwpOption('site_title') ? AspwpOption('site_title') : get_bloginfo('name');
$site_url   = function_exists('AspwpOption') && AspwpOption('site_url') ? AspwpOption('site_url') : parse_url(home_url('/'), PHP_URL_HOST);

$light_logo_url = '';
$dark_logo_url  = '';

if ( function_exists( 'AspwpOption' ) ) {
    $light_logo = AspwpOption( 'header_logo_light' );
    $dark_logo  = AspwpOption( 'header_logo_dark' );

    $light_logo_url = is_array( $light_logo ) && isset( $light_logo['url'] ) ? $light_logo['url'] : $light_logo;
    $dark_logo_url  = is_array( $dark_logo ) && isset( $dark_logo['url'] ) ? $dark_logo['url'] : $dark_logo;
}

$show_text_logo = false;

if ( $logo_type === 'text' ) {
    $show_text_logo = true;
} elseif ( empty( $light_logo_url ) && empty( $dark_logo_url ) ) {
    $show_text_logo = true;
}
?>

<?php if ( $show_text_logo ) : ?>
    <div class="YSLogo textlogo" id="YSLogo">
        <a href="<?php echo esc_url( home_url('/') ); ?>" title="<?php echo esc_attr( $site_title ); ?>">
            <span class="SiteName"><?php echo esc_html( $site_title ); ?></span>
            <span class="SiteUrl"><?php echo esc_html( $site_url ); ?></span>
        </a>
    </div>
<?php else : ?>
    <div class="YSLogo " id="YSLogo">
        <a href="<?php echo esc_url( home_url('/') ); ?>" rel="home" class="custom-logo-link d-inline-flex align-items-center">
            <?php if ( ! empty( $light_logo_url ) ) : ?>
                <img src="<?php echo esc_url( $light_logo_url ); ?>" class="custom-logo logo-light" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="200" height="54">
            <?php else : ?>
                <img src="<?php echo esc_url( get_template_directory_uri() . '/img/logo.svg' ); ?>" class="custom-logo logo-light" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="200" height="54">
            <?php endif; ?>

            <?php if ( ! empty( $dark_logo_url ) ) : ?>
                <img src="<?php echo esc_url( $dark_logo_url ); ?>" class="custom-logo logo-dark" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="200" height="54">
            <?php endif; ?>
        </a>
    </div>
<?php endif; ?>

<?php 
$show_social  = function_exists('AspwpOption') ? AspwpOption('show_social_buttons') : '0';
$telegram_url = function_exists('AspwpOption') ? AspwpOption('telegram_url') : '#';
$facebook_url = function_exists('AspwpOption') ? AspwpOption('facebook_url') : '#';
$youtube_url  = function_exists('AspwpOption') ? AspwpOption('youtube_url') : '#';
$twitter_url  = function_exists('AspwpOption') ? AspwpOption('twitter_url') : '#';
?>
               <nav id="site-navigation" class="VnxSport_menu d-flex justify-content-end flex-fill">
                  <span 
    class="fa fa-close" 
    id="menu-close" 
    onclick="document.getElementById('site-navigation').classList.remove('open')">
</span>
                  <div id="mainmenu" class="menu-header-container">
                  <?php
                     wp_nav_menu( array(
                     	'theme_location' => 'header',
                     	'menu_id'        => 'primary-menu',
                     	'container' => false
                     ) );
                     ?>
                                       
<ul class="social-media mob" aria-label="روابط التواصل الاجتماعي">

    <?php if ($show_social === '1') : ?>

        <?php if (!empty($twitter_url) && $twitter_url !== '#') : ?>
            <li class="twitter">
                <a href="<?php echo esc_url($twitter_url); ?>" target="_blank" rel="noopener noreferrer" class="social-icon twitter" aria-label="Twitter">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" image-rendering="optimizeQuality" fill-rule="evenodd" clip-rule="evenodd" viewBox="0 0 512 462.799" aria-hidden="true" focusable="false">
                        <path d="M403.229 0h78.506L310.219 196.04 512 462.799H354.002L230.261 301.007 88.669 462.799h-78.56l183.455-209.683L0 0h161.999l111.856 147.88L403.229 0zm-27.556 415.805h43.505L138.363 44.527h-46.68l283.99 371.278z" fill="#707488"></path>
                    </svg>
                </a>
            </li>
        <?php endif; ?>

        <?php if (!empty($facebook_url) && $facebook_url !== '#') : ?>
            <li class="facebook">
                <a href="<?php echo esc_url($facebook_url); ?>" target="_blank" rel="noopener noreferrer" class="social-icon facebook" aria-label="Facebook">
                    <svg width="28.525" height="22.218" viewBox="-5 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g transform="translate(-385.000000, -7399.000000)" fill="#ffffff">
                                <g transform="translate(56.000000, 160.000000)">
                                    <path d="M335.821282,7259 L335.821282,7250 L338.553693,7250 L339,7246 L335.821282,7246 L335.821282,7244.052 C335.821282,7243.022 335.847593,7242 337.286884,7242 L338.744689,7242 L338.744689,7239.14 C338.744689,7239.097 337.492497,7239 336.225687,7239 C333.580004,7239 331.923407,7240.657 331.923407,7243.7 L331.923407,7246 L329,7246 L329,7250 L331.923407,7250 L331.923407,7259 L335.821282,7259 Z"></path>
                                </g>
                            </g>
                        </g>
                    </svg>
                </a>
            </li>
        <?php endif; ?>

        <?php if (!empty($youtube_url) && $youtube_url !== '#') : ?>
            <li class="youtube">
                <a href="<?php echo esc_url($youtube_url); ?>" target="_blank" rel="noopener noreferrer" class="social-icon youtube" aria-label="Youtube">
                    <svg width="28.525" height="20.218" viewBox="0 -3 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g transform="translate(-300.000000, -7442.000000)" fill="#ffffff">
                                <g transform="translate(56.000000, 160.000000)">
                                    <path d="M251.988432,7291.58588 L251.988432,7285.97425 C253.980638,7286.91168 255.523602,7287.8172 257.348463,7288.79353 C255.843351,7289.62824 253.980638,7290.56468 251.988432,7291.58588 M263.090998,7283.18289 C262.747343,7282.73013 262.161634,7282.37809 261.538073,7282.26141 C259.705243,7281.91336 248.270974,7281.91237 246.439141,7282.26141 C245.939097,7282.35515 245.493839,7282.58153 245.111335,7282.93357 C243.49964,7284.42947 244.004664,7292.45151 244.393145,7293.75096 C244.556505,7294.31342 244.767679,7294.71931 245.033639,7294.98558 C245.376298,7295.33761 245.845463,7295.57995 246.384355,7295.68865 C247.893451,7296.0008 255.668037,7296.17532 261.506198,7295.73552 C262.044094,7295.64178 262.520231,7295.39147 262.895762,7295.02447 C264.385932,7293.53455 264.28433,7285.06174 263.090998,7283.18289"></path>
                                </g>
                            </g>
                        </g>
                    </svg>
                </a>
            </li>
        <?php endif; ?>

        <?php if (!empty($telegram_url) && $telegram_url !== '#') : ?>
            <li class="telegram">
                <a href="<?php echo esc_url($telegram_url); ?>" target="_blank" rel="noopener noreferrer" class="social-icon telegram" aria-label="Telegram">
                    <svg width="28.525" height="22.218" viewBox="0 0 496 512" xmlns="http://www.w3.org/2000/svg" fill="white" aria-hidden="true" focusable="false">
                        <path d="M248 8C111 8 0 119 0 256S111 504 248 504 496 393 496 256 385 8 248 8zM363 176.7c-3.7 39.2-19.9 134.4-28.1 178.3-3.5 18.6-10.3 24.8-16.9 25.4-14.4 1.3-25.3-9.5-39.3-18.7-21.8-14.3-34.2-23.2-55.3-37.2-24.5-16.1-8.6-25 5.3-39.5 3.7-3.8 67.1-61.5 68.3-66.7 .2-.7 .3-3.1-1.2-4.4s-3.6-.8-5.1-.5q-3.3 .7-104.6 69.1-14.8 10.2-26.9 9.9c-8.9-.2-25.9-5-38.6-9.1-15.5-5-27.9-7.7-26.8-16.3q.8-6.7 18.5-13.7 108.4-47.2 144.6-62.3c68.9-28.6 83.2-33.6 92.5-33.8 2.1 0 6.6 .5 9.6 2.9a10.5 10.5 0 0 1 3.5 6.7A43.8 43.8 0 0 1 363 176.7z"></path>
                    </svg>
                </a>
            </li>
        <?php endif; ?>

    <?php endif; ?>


</ul>
    
                  </div>

               </nav>

               <div class="header-items-wrap">



<ul class="social-media" aria-label="روابط التواصل الاجتماعي">

    <?php if ($show_social === '1') : ?>

        <?php if (!empty($twitter_url) && $twitter_url !== '#') : ?>
            <li class="twitter">
                <a href="<?php echo esc_url($twitter_url); ?>" target="_blank" rel="noopener noreferrer" class="social-icon twitter" aria-label="Twitter">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" image-rendering="optimizeQuality" fill-rule="evenodd" clip-rule="evenodd" viewBox="0 0 512 462.799" aria-hidden="true" focusable="false">
                        <path d="M403.229 0h78.506L310.219 196.04 512 462.799H354.002L230.261 301.007 88.669 462.799h-78.56l183.455-209.683L0 0h161.999l111.856 147.88L403.229 0zm-27.556 415.805h43.505L138.363 44.527h-46.68l283.99 371.278z" fill="#707488"></path>
                    </svg>
                </a>
            </li>
        <?php endif; ?>

        <?php if (!empty($facebook_url) && $facebook_url !== '#') : ?>
            <li class="facebook">
                <a href="<?php echo esc_url($facebook_url); ?>" target="_blank" rel="noopener noreferrer" class="social-icon facebook" aria-label="Facebook">
                    <svg width="28.525" height="22.218" viewBox="-5 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g transform="translate(-385.000000, -7399.000000)" fill="#ffffff">
                                <g transform="translate(56.000000, 160.000000)">
                                    <path d="M335.821282,7259 L335.821282,7250 L338.553693,7250 L339,7246 L335.821282,7246 L335.821282,7244.052 C335.821282,7243.022 335.847593,7242 337.286884,7242 L338.744689,7242 L338.744689,7239.14 C338.744689,7239.097 337.492497,7239 336.225687,7239 C333.580004,7239 331.923407,7240.657 331.923407,7243.7 L331.923407,7246 L329,7246 L329,7250 L331.923407,7250 L331.923407,7259 L335.821282,7259 Z"></path>
                                </g>
                            </g>
                        </g>
                    </svg>
                </a>
            </li>
        <?php endif; ?>

        <?php if (!empty($youtube_url) && $youtube_url !== '#') : ?>
            <li class="youtube">
                <a href="<?php echo esc_url($youtube_url); ?>" target="_blank" rel="noopener noreferrer" class="social-icon youtube" aria-label="Youtube">
                    <svg width="28.525" height="20.218" viewBox="0 -3 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <g transform="translate(-300.000000, -7442.000000)" fill="#ffffff">
                                <g transform="translate(56.000000, 160.000000)">
                                    <path d="M251.988432,7291.58588 L251.988432,7285.97425 C253.980638,7286.91168 255.523602,7287.8172 257.348463,7288.79353 C255.843351,7289.62824 253.980638,7290.56468 251.988432,7291.58588 M263.090998,7283.18289 C262.747343,7282.73013 262.161634,7282.37809 261.538073,7282.26141 C259.705243,7281.91336 248.270974,7281.91237 246.439141,7282.26141 C245.939097,7282.35515 245.493839,7282.58153 245.111335,7282.93357 C243.49964,7284.42947 244.004664,7292.45151 244.393145,7293.75096 C244.556505,7294.31342 244.767679,7294.71931 245.033639,7294.98558 C245.376298,7295.33761 245.845463,7295.57995 246.384355,7295.68865 C247.893451,7296.0008 255.668037,7296.17532 261.506198,7295.73552 C262.044094,7295.64178 262.520231,7295.39147 262.895762,7295.02447 C264.385932,7293.53455 264.28433,7285.06174 263.090998,7283.18289"></path>
                                </g>
                            </g>
                        </g>
                    </svg>
                </a>
            </li>
        <?php endif; ?>

        <?php if (!empty($telegram_url) && $telegram_url !== '#') : ?>
            <li class="telegram">
                <a href="<?php echo esc_url($telegram_url); ?>" target="_blank" rel="noopener noreferrer" class="social-icon telegram" aria-label="Telegram">
                    <svg width="28.525" height="22.218" viewBox="0 0 496 512" xmlns="http://www.w3.org/2000/svg" fill="white" aria-hidden="true" focusable="false">
                        <path d="M248 8C111 8 0 119 0 256S111 504 248 504 496 393 496 256 385 8 248 8zM363 176.7c-3.7 39.2-19.9 134.4-28.1 178.3-3.5 18.6-10.3 24.8-16.9 25.4-14.4 1.3-25.3-9.5-39.3-18.7-21.8-14.3-34.2-23.2-55.3-37.2-24.5-16.1-8.6-25 5.3-39.5 3.7-3.8 67.1-61.5 68.3-66.7 .2-.7 .3-3.1-1.2-4.4s-3.6-.8-5.1-.5q-3.3 .7-104.6 69.1-14.8 10.2-26.9 9.9c-8.9-.2-25.9-5-38.6-9.1-15.5-5-27.9-7.7-26.8-16.3q.8-6.7 18.5-13.7 108.4-47.2 144.6-62.3c68.9-28.6 83.2-33.6 92.5-33.8 2.1 0 6.6 .5 9.6 2.9a10.5 10.5 0 0 1 3.5 6.7A43.8 43.8 0 0 1 363 176.7z"></path>
                    </svg>
                </a>
            </li>
        <?php endif; ?>

    <?php endif; ?>

    <li class="moon">
        <input type="checkbox" name="dark_theme" id="dark_theme" style="display:none;">

        <label for="dark_theme" class="hed-btn" aria-label="تبديل الوضع الليلي">
            <span id="theme-toggle-icon" aria-hidden="true">
                <svg width="25" height="25" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" focusable="false">
                    <path d="M12.0557 3.59974C12.2752 3.2813 12.2913 2.86484 12.0972 2.53033C11.9031 2.19582 11.5335 2.00324 11.1481 2.03579C6.02351 2.46868 2 6.76392 2 12C2 17.5228 6.47715 22 12 22C17.236 22 21.5313 17.9764 21.9642 12.8518C21.9967 12.4664 21.8041 12.0968 21.4696 11.9027C21.1351 11.7086 20.7187 11.7248 20.4002 11.9443C19.4341 12.6102 18.2641 13 17 13C13.6863 13 11 10.3137 11 6.99996C11 5.73589 11.3898 4.56587 12.0557 3.59974Z" fill="#ffffff"></path>
                </svg>
            </span>

            <span class="screen-reader">تبديل الوضع الليلي</span>
        </label>
    </li>

</ul>
        
    
               </div>
            </div>
         </div>
      </header>

      <div id="content" class="container">
         <div class="wrapper clearfix mb-4">
            <?php if ( get_theme_mod('VnxHeaderAds') != '' ) { ?>
            <div class="AspThemeAds mb-2">
               <?php echo get_theme_mod('VnxHeaderAds'); ?>
            </div>
            <?php } ?>