<?php
/**
 * VnxSport  :: Widget >> Matches.
 *
 * @since   0.4.3
 * @package VnxSport_Plugin
 */

class VnxSport_Widget_Matches extends VnxSport_Widget {

	/**
	 * Get unique identifier for this widget.
	 *
	 * @return string
	 */
	protected function get_widget_slug() {
		return 'aspwp_widget_matches_table';
	}

	/**
	 * Get widget name, displayed in Widgets dashboard.
	 *
	 * @return string
	 */
	protected function get_widget_name() {
		return esc_html__('VnxSport | Matches Center', VNXSPORT_TEXTDOMAIN);
	}

	/**
	 * Get widget description.
	 *
	 * @return string
	 */
	protected function get_widget_description() {
		return esc_html__( 'Show Matches Table.', VNXSPORT_TEXTDOMAIN);
	}

	/**
	 * Get widget CSS classes.
	 *
	 * @return string
	 */
	protected function get_widget_css_classes() {
		return 'aspwp_widget_matches';
	}

	/**
	 * Front-end display of widget.
	 *
	 * @param  array $args     The widget arguments set up when a sidebar is registered.
	 * @param  array $instance The widget settings as set by user.
	 *
	 * @since  0.4.3 (2018-02-18)
	 */
	public function widget( $args, $instance ) {

		// Prevent errors with new params
		$data =  wp_parse_args(
			$instance,
			[
				'before_widget' 	=> $args['before_widget'],
				'after_widget'  	=> $args['after_widget'],
				'widget_pos'   		=> $args['id'],
				'title' 			=> 'مباريات اليوم',
				'style' 			=> '',
				'type' 				=> '',
				'show_timezone' 	=> '1',
				'show_title' 		=> '1',
				'matches_day' 		=> 'today',
				'tabs_type' 		=> '',
				'yesterday_url' 	=> '',
				'today_url' 		=> '',
				'tomorrow_url'  	=> '',
				'yesterday'  		=> '1', 
				'today'  			=> '1', 
				'tomorrow'  		=> '1',
				'dark_style' 		=> '',
				'limit' 			=> '',
			]
		);

			// Validate shortcode attr
		$data['style'] 				= esc_attr( $data['style'] );
		$data['type'] 				= esc_attr( $data['type'] );
		$data['tabs_type']      	= in_array( $data['tabs_type'], ['tabs','links'] ) ? $data['tabs_type'] : 'tabs';
		$data['matches_day']    	= in_array( $data['matches_day'] , ['yesterday', 'today', 'tomorrow' ] ) ?  $data['matches_day'] : '';
		$data['type'] 				= empty($data['type']) ? '' : 'small';

		$data['show_title'] 		= empty($data['show_title']) 	? '0' : '1';
		$data['show_timezone'] 		= empty($data['show_timezone']) ? '0' : '1';
		$data['yesterday'] 			= empty($data['yesterday']) 	? '0' : '1';
		$data['today'] 				= empty($data['today']) 		? '0' : '1';
		$data['tomorrow'] 			= empty($data['tomorrow']) 		? '0' : '1';

		if (function_exists('str_contains')) {
			if (str_contains($args['before_widget'], 'col-lg-4') || str_contains($args['before_widget'], 'col-lg-3')) {
				$data['widget_pos'] = 'sidebar';
			}
		}
		
		// Start widget markup.
		echo $data['before_widget'];

		Vnx_Sport_Plugin()->load_partial( $data, 'shortcode-matches-table' );

		// End the widget markup.
		echo $data['after_widget'];
		

	
	}
	/**
	 * Get widget options fields.
	 *
	 * @return array
	 */
	protected function get_widget_fields() {
		return VnxSport_Data_Helper::widget_match_fields();
	}
}
