<?php

function AkbaSport_get_customizer_css()
{
    ob_start();
    $background_color = get_theme_mod('background_color', '');
    $header_bd = get_theme_mod('header_bd', '');
    $header_color = get_theme_mod('header_color', '');
    $footer_bd = get_theme_mod('footer_bd', '');
    $footer_color = get_theme_mod('footer_color', '');

    if(get_theme_mod('vnxhsocial')){ ?>
    #hdsocial{display:flex;align-items:center;float:left;height:50px}#hdsocial a{height:35px;width:35px;padding:0;display:grid;background:#474747;margin-right:5px;border-radius:8px;float:left;cursor:pointer;line-height:35px!important;color:#fff;text-align:center;justify-content:center}@media only screen and (min-width:769px){#mainmenu{align-items:center;width:100%}#primary-menu{float:right}}#hdsocial svg{width:20px;height:20px}@media only screen and (max-width:768px){#hdsocial{width:100%;margin-top:12px;border:0}#hdsocial li{border:0}}#hdsocial .telegram a{background:#389ce9}#hdsocial .twitter a{background:#55acee}#hdsocial .facebook a{background:#4267b2}#hdsocial .whatsapp a{background:#47e363}#hdsocial .youtube a{background:#ff0000}
    <?php
    }
    if (!empty($background_color)) {
        ?>body{background: #<?php echo $background_color; ?>;}<?php
    }
    if (!empty($header_bd)) {
        ?>
        #VnxSport_header{background-color: <?php echo $header_bd; ?>;}
        .VnxSport_menu a{color: <?php echo $header_color; ?>;}
        .navbar-toggler-icon i::before, .navbar-toggler-icon i::after,.navbar-toggler-icon i{background-color: <?php echo $header_color; ?>;}
        .vnx-footer ,.vnx-footer a{background: <?php echo $footer_bd; ?>;color: <?php echo $footer_color; ?>;}
        <?php
    }
    $css = ob_get_clean();
    return $css;
}

// Modify our styles registration like so:

function AkbaSport_enqueue_styles()
{
    $custom_css = AkbaSport_get_customizer_css();
    wp_add_inline_style('theme-styles', $custom_css);
}

add_action('wp_enqueue_scripts', 'AkbaSport_enqueue_styles');

add_action('customize_register', 'AkbaSport_register_theme_customizer');
/*
 * Register Our Customizer Stuff Here
 */
function AkbaSport_register_theme_customizer($wp_customize)
{

    


  





    // Sanitize text
    function sanitize_text($text)
    {
        return sanitize_text_field($text);
    }
    function wpforge_sanitize_text($input)
    {
        return wp_kses_post(force_balance_tags($input));
    }
}



function vnx_customize_register_soc($wp_customize){


}


add_action('customize_register', 'vnx_customize_register_soc');

function vnx_theme_sanitize_checkbox($input) {
if ($input == 1) {
    return 1;
} else {
    return '';
}
}
/**
* Sanitize the settings with textareas
*/
function vnx_theme_sanitize_text( $value ) {
return $value;
}
