<?php
/*
 * Plugin Name: VnxSport البث المباشر وجدول المباريات
 * Plugin URI:  https://vnxweb.com/vnxsport
 * Description: اضافة لعرض جدول المباريات والبث المباشر بسهوله وبطريقة مناسبة لمواقع البث | الكود المختصر [VnxSportTable]
 * Version:     14.2
 * Author:      VNX Web
 * Author URI:  https://vnxweb.com
 * License:     Premium Multi-purpose Plugins
 * License URI: https://vnxweb.com/vnxsport
 * Text Domain: vnxsport
 * Domain Path: /lang
 * Requires at least: 4.9
 * Requires PHP: 7.2
 *
 */
defined('ABSPATH') or die("No script kiddies please!");
define('VNXSPORT_VER',         '1.0');
define('VNXSPORT_AUTHOR',      'VNX Web');
define('VNXSPORT_TEXTDOMAIN',  'vnxsport');
define('VNXSPORT_PATH',        plugin_dir_path(__FILE__));
define('VNXSPORT_URL',         plugin_dir_url(__FILE__));
load_textdomain(VNXSPORT_TEXTDOMAIN, VNXSPORT_PATH . '/languages/asp-' . get_locale() . '.mo');
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'VnxSport_settings_link' );
function VnxSport_settings_link( $links ){
    $links[]  = '<span class="settings"><a href="'.admin_url().'admin.php?page=VnxSport" style="color: #d63638;font-weight: 700;">' . __( 'Settings',VNXSPORT_TEXTDOMAIN ) . '</a> | </span>';
    $links[]  = '<span class="add-ons"><a href="https://vnxweb.com/item/vnxsportapi/" target="_blank">' . __( 'Add-ons',VNXSPORT_TEXTDOMAIN ) . '</a> | </span>';
    $links[]  = '<span class="support"><a href="https://vnxweb.com" target="_blank" style="color: green;font-weight: 700;">' . __( 'Support ',VNXSPORT_TEXTDOMAIN ) . '</a></span>';
    return $links;
}
include VNXSPORT_PATH . "/includes/vendor/base.php";