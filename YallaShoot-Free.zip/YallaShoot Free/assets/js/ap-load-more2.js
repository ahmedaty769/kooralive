jQuery(function ($) {
    $(document).off('click', '.ap-load-more').on('click', '.ap-load-more', function (e) {
        e.preventDefault();

        var button = $(this);

        if (button.hasClass('loading')) {
            return;
        }

        var currentPage = parseInt(button.attr('data-page'), 10) || 1;
        var maxPages = parseInt(button.attr('data-max'), 10) || 1;
        var nextPage = currentPage + 1;

        button
            .addClass('loading')
            .prop('disabled', true)
            .text('جاري التحميل...');

        $.ajax({
            url: ap_ajax_obj.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'ap_load_more_posts',
                nonce: ap_ajax_obj.nonce,
                page: nextPage
            },
            success: function (response) {
                if (response.success && response.data.html) {
                    $('#ap-articles-wrap').append(response.data.html);

                    if (typeof window.lazyLoadImages === 'function') {
                        window.lazyLoadImages();
                    }

                    button.attr('data-page', nextPage);

                    if (!response.data.has_more || nextPage >= maxPages) {
                        button.remove();
                    } else {
                        button
                            .removeClass('loading')
                            .prop('disabled', false)
                            .text('تحميل المزيد');
                    }
                } else {
                    button.remove();
                }
            },
            error: function () {
                button
                    .removeClass('loading')
                    .prop('disabled', false)
                    .text('تحميل المزيد');
            }
        });
    });
});