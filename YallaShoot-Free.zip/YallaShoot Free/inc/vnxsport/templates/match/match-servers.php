<?php
/**
 * The Template for displaying Match >> Servers Section.
 *
 * This template can be overridden by copying it to yourtheme/VnxSport/match/match-servers.php.
 *
 * @var $data - with args.
 *
 * @author        VNX Web <vnxweb.com>
 * @package       VnxSport/Templates
 * @since         0.0.1
 *
 * @version       0.14.14
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$data = wp_parse_args(
	$data,
	[
		'match_id'       		=> '',
		'servers'       		=> [],
	]
);
if(empty($data['servers']) || empty($data['match_id']) || !AspwpOption('event_servers')){
   return;
}
?>
<div class="aspwp-match-servers">
   <?php 
      /**
       * Hook: aspwp/tmpl-match/before_match_server
      */
      do_action( 'aspwp/tmpl-match/before_match_server');
   ?>
   <div class="asp-server-name aspwp-server-ajax">
      <?php 
         $num = 0;
         foreach ($data['servers'] as $server) {
            $active = $num == 0 ? ' active' : ''; 
            ?>
            <a class="asp-font<?php echo $active;?>" href="#/" data-asp-live="<?php echo $num;?>" data-asp-id="<?php echo $data['match_id'];?>">
               <?php echo $server['channel-name'];?>
            </a>
            <?php 
            $num++;
         }
      ?>
   </div>
   <div class="asp-server-body">

      <?php echo $data['servers'][0]['channel-code'];?>

   </div>
   <?php 
      /**
       * Hook: aspwp/tmpl-match/after_match_server
      *
      */
      do_action( 'aspwp/tmpl-match/after_match_server');
   ?>
</div>
