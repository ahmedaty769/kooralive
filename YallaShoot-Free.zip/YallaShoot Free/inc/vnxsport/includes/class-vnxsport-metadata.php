<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * VnxSport  :: MetaData.
 *
 * @since   0.1.0
 * @package VnxSport Plugin
 */

class VnxSport_MetaData {

	private $match_fields     = [];
	private $servers_field    = [];
	public $taxonomies 		  = ['teams','championship'];
	public $taxonomy 		  = '';

	public function __construct() {
		$this->hooks();
	}	
	/**
	 * Initiate our hooks.
	*/
	public function hooks() {
		$this->taxonomy   = ( ! empty( $_REQUEST[ 'taxonomy' ] ) ) ? sanitize_text_field( wp_unslash( $_REQUEST[ 'taxonomy' ] ) ) : '';
		if ( ! empty( $this->taxonomies ) && in_array( $this->taxonomy, $this->taxonomies ) ) {
			add_action( 'admin_init', array( $this, 'add_taxonomy_options' ) );
		}
		add_action('edit_form_after_title', [ $this , 'edit_form_after_title'] );
		add_action('add_meta_boxes', 		[ $this , 'add_meta_boxes' ] );
		add_action( 'save_post', 			[ $this , 'save_meta_box' ] );
	}
	
	public function edit_form_after_title() {
		global $post, $wp_meta_boxes;
		do_meta_boxes(get_current_screen(), 'aspwp_after_title', $post);
		unset($wp_meta_boxes[get_post_type($post)]['aspwp_after_title']);
	}

	/**
	 * add taxonomy add/edit fields	
	 *
	 * @return void
	 */
	public function add_taxonomy_options() {

		add_action( $this->taxonomy .'_add_form_fields', array( $this, 'render_taxonomy_form_fields' ) );
		add_action( $this->taxonomy .'_edit_form', array( $this, 'render_taxonomy_form_fields' ) );

		add_action( 'created_'. $this->taxonomy, array( $this, 'save_taxonomy' ) );
		add_action( 'edited_'. $this->taxonomy, array( $this, 'save_taxonomy' ) );

	}
		
	/**
	 * add meta boxes
	 *
	 * @return void
	 */
	public function add_meta_boxes() {

		add_meta_box( 
			"aspwp_match_fields",
			esc_html__("Match", VNXSPORT_TEXTDOMAIN),
			[$this, 'render_match_metabox'], 
			'vnx-matches',
			'aspwp_after_title',
			'high'
		);

		add_meta_box( 
			"vnxsport_servers",
			esc_html__("Live Streaming Servers", VNXSPORT_TEXTDOMAIN),
			[$this, 'render_servers_metabox'], 
			'vnx-matches',
			'normal',
			'high'
		);

		add_meta_box( 
			'VnxCardId', 
			__( 'Match Card', VNXSPORT_TEXTDOMAIN), 
			[$this, 'render_post_metabox'], 
			'post', 
			'side', 
			'high' 
		);
		
	}
	
	/**
	 * render match metabox
	 *
	 * @param $post wp post data
	 *
	 * @return void
	 */
	public function render_match_metabox( $post) {
		$fields = $this->match_fields();
		wp_nonce_field( 'aspwp_metabox_nonce', 'aspwp_metabox_nonce_aspwp_match_fields');
		$this->render_fields($fields,"aspwp_match_fields");
	}

	public function render_servers_metabox( $post ) {
		$fields = $this->servers_fields();
		$this->render_fields($fields,"vnxsport_servers");
		
	}

	public function render_post_metabox( $post) {

		echo '<p class="description" style="font-size: 12px;">';
        	echo  __( 'Paste Match ID to Display Match Card', VNXSPORT_TEXTDOMAIN);
    	echo '</p>';
    	echo '<input type="number" class="widefat" style="text-align: center;font-size: 30px;padding: 0;margin: 0 auto;height: 42px;color: #5b7b00;" name="VnxCardIdField" value="'.get_post_meta( $post->ID,'VnxCardIdField' ,true).'"/>';

	}
	
	/**
	 * render taxonomy add/edit fields	
	 *
	 * @param $term
	 *
	 * @return void
	 */
	public function render_taxonomy_form_fields( $term ) {

		$is_term   = ( is_object( $term ) && isset( $term->taxonomy ) ) ? true : false;
		$term_id   = ( $is_term ) ? $term->term_id : 0;
		$taxonomy  = ( $is_term ) ? $term->taxonomy : $term;
		$classname = ( $is_term ) ? 'edit' : 'add';
		wp_nonce_field( 'aspwp_taxonomy_nonce', 'aspwp_taxonomy_nonce_brand_image' );
		if ( !in_array($taxonomy ,['teams','championship'])) {
			return ;
		}
		echo '<div class="aspwp-taxonomy aspwp-onload aspwp-taxonomy-'. esc_attr( $classname ) .'-fields postbox">';
			echo '<div class="postbox-header"><h2 style="margin: 0;padding: 8px 12px;" class="hndle">'.esc_html__('Logo', VNXSPORT_TEXTDOMAIN).'</h2></div>';
			$field = ["id"=>"brand_image","type"=>"upload","library"=>"image","preview"=>1,"hidden"=>1,];
			$term_meta  = get_term_meta( $term_id, $field['id'], true );
			$term_meta  = $term_meta ? $term_meta : '';
			VnxSport_Admin::field( $field, $term_meta, 'brand_image', 'taxonomy' );
		echo '</div>';

	}
	/**
	 * Method render_fields
	 *
	 * @param $fields [meta fields array]
	 * @param $unique [metabox id]
	 * @param $cpt [custom post type]
	 *
	 * @return html
	 */
	public function render_fields($fields = [],$unique = '',$cpt = 'vnx-matches') {

		global $post;

		if(empty($fields)){
			return;
		}
		$unique  	= !empty($unique) ? $unique : "aspwp_match_fields";
		$post_type = ( is_object ( $post ) ) ? $post->post_type : '';
		$errors    = ( is_object ( $post ) ) ? get_post_meta( $post->ID, '_vnxsport_errors_'. $unique, true ) : array();
		$errors    = ( ! empty( $errors ) ) ? $errors : array();
  
		if ( is_object ( $post ) && ! empty( $errors ) ) {
		  delete_post_meta( $post->ID, '_vnxsport_errors_'. $unique );
		}

		if ( $post_type != $cpt) {
			return;
		}
		echo '<div class="aspwp-metabox">';
			echo '<div class="aspwp-wrapper">';
			echo '<div class="aspwp-section aspwp-onload">';
				foreach ($fields as $field) {
					$field_id 	  = (isset($field['id']) && !empty($field['id'])) ? $field['id'] : '';
					$field_value  = get_post_meta(get_the_ID(),$field_id,true);

					if ( ! empty( $field_id) && ! empty( $errors['fields'][$field['id']] ) ) {
						$field['_error'] = $errors['fields'][$field['id']];
					  }

					  VnxSport_Admin::field( $field,$field_value, $unique, 'metabox' );

				}

			echo '</div>';

			echo '</div>';

		echo '</div>';

	}

	/**
	 * get meta value
	 *
	 * @param $field 
	 *
	 * @return void
	 */
	public function get_value( $field ) {

		global $post;
		$value = null;
		if ( is_object( $post ) && ! empty( $field['id'] ) ) {
			$value  = get_post_meta( $post->ID, $field['id'],true );
		}
		$default = ( isset( $field['default'] ) ) ? $field['default'] : '';
		$value   = ( isset( $value ) ) ? $value : $default;
		return $value;
	}  
    /**
     * Method save_taxonomy
     *
     * @param $term_id $term_id [explicite description]
     *
     * @return void
     */
	
    public function save_taxonomy( $term_id ) {
		$unique   = 'brand_image';
		$noncekey = 'aspwp_taxonomy_nonce_'. $unique;
		$nonce    = ( ! empty( $_POST[ $noncekey ] ) ) ? sanitize_text_field( wp_unslash( $_POST[ $noncekey ] ) ) : '';
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! wp_verify_nonce( $nonce, 'aspwp_taxonomy_nonce' ) ) {
		  return $term_id;
		}
		$request 	= ( ! empty( $_POST[$unique] ) ) ? $_POST[$unique] : array();
		if ( ! empty( $request ) ) {
			$field_value = isset( $request[$unique] ) ? $request[$unique] : '';
			if ( empty( $field_value ) ) {
				delete_term_meta( $term_id, $unique );
			}else{
				update_term_meta( $term_id, $unique, $field_value );
			}
		}
	}  
		
	/**
	 * Method save_meta_box
	 *
	 * @param $this_id $this_id [explicite description]
	 *
	 * @return void
	 */
	public function save_meta_box( $this_id ) {
		
		$count    = 1;
		$data     = array();
		$errors   = array();
		$unique   = 'aspwp_match_fields';
		$nonce    = ( ! empty( $_POST['aspwp_metabox_nonce_aspwp_match_fields'] ) ) ? sanitize_text_field( wp_unslash( $_POST['aspwp_metabox_nonce_aspwp_match_fields'] ) ) : '';
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! wp_verify_nonce( $nonce, 'aspwp_metabox_nonce' ) ) {
			if(isset($_POST['VnxCardIdField'])){
				update_post_meta( $this_id, 'VnxCardIdField',$_POST['VnxCardIdField']);
			}
			return $this_id;
		}
		$request 	= ( ! empty( $_POST[$unique] ) ) ? $_POST[$unique] : array();
		if ( ! empty( $request ) ) {
				foreach ( $this->match_fields() as $field ) {
					if ( ! empty( $field['id'] ) ) {
						$field_id    = $field['id'];
						$field_value = isset( $request[$field_id] ) ? $request[$field_id] : '';
						$data[$field_id] = $field_value;
						if ( isset( $field['validate'] ) && is_callable( $field['validate'] ) ) {
							$has_validated = call_user_func( $field['validate'], ['value'=> $field_value, 'title'=> $field['title']]);
							if ( ! empty( $has_validated ) ) {
								$errors['sections'][$count] = true;
								$errors['fields'][$field_id] = $has_validated;
								$data[$field_id] = $this->get_value( $field );
							}
						}
					}
				}
		}

		$req_serv 	= ( ! empty(  $_POST['vnxsport_servers'] ) ) ?  $_POST['vnxsport_servers'] : array();
		if(empty( $req_serv)){
			delete_post_meta( $this_id,'channels');
		}else{
			foreach ( $this->servers_fields() as $field ) {
				if ( ! empty( $field['id'] ) ) {
					$field_id    		= $field['id'];
					$field_value 		= isset( $req_serv[$field_id] ) ? $req_serv[$field_id] : '';
					$data[$field_id] 	= $field_value;
				}
			}
		}
		
		if ( empty( $data )) {
			foreach ( $data as $key => $value ) {
				delete_post_meta( $this_id, $key );
			}
		} else {
			foreach ( $data as $key => $value ) {
				update_post_meta( $this_id, $key, $value );
			}
			if ( ! empty( $errors ) ) {
				update_post_meta( $this_id,'_vnxsport_errors_'. $unique, $errors );
			}
		}
	
	}
	/**
	 * Method servers_fields
	 *
	 * @return array
	 */
	public function servers_fields() {
		
		$servers_fields = [
            [
                'id' => 'channels',
                "type" => "repeater",
                "title" => "dddd",
                "fields" => [
                    [
                        "title" => esc_html__("Server Name", VNXSPORT_TEXTDOMAIN),
                        "id" => "channel-name",
                        "type" => "text",
                        "td_width" => "20",
                        "sanitize" => 'vnxsport_save_server_code',

                    ],
                    [
                        "title" => esc_html__("Code", VNXSPORT_TEXTDOMAIN),
                        "id" => "channel-code",
                        "type" => "textarea",
                        "td_width" => "80",
                        "attributes" => ["dir" => "ltr", "rows" => "8"],
                        "default" => "",
                        "sanitize" => 'vnxsport_save_server_code',
                    ],
                ],
				'button_title' => esc_html__('Add Chanel', VNXSPORT_TEXTDOMAIN) ,

            ],
        ];
		
		return apply_filters('aspwp_match_servers_field_filter', $servers_fields, $servers_fields );
	}
	/**
	 * Method match_fields
	 *
	 * @return array
	 */
	public function match_fields() {
		return VnxSport_Data_Helper::match_fields();
	}
}
$VnxSport_MetaData = new VnxSport_MetaData;